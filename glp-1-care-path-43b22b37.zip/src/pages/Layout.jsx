

import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Users, 
  BarChart3, 
  FileText, 
  Settings, 
  Activity,
  LogOut,
  Stethoscope,
  DollarSign,
  CalendarClock,
  Brain // Added Brain icon import
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { User } from "@/api/entities";

const navigationItems = [
  {
    title: "Patient Dashboard",
    url: createPageUrl("Dashboard"),
    icon: Users,
  },
  {
    title: "Custom Health Plan", // Added Custom Health Plan item
    url: createPageUrl("CustomHealthPlan"),
    icon: Brain,
  },
  {
    title: "Appointments", // Renamed from "Scheduler"
    url: createPageUrl("Appointments"), // Renamed from "Scheduler"
    icon: CalendarClock,
  },
  {
    title: "Analytics",
    url: createPageUrl("Analytics"),
    icon: BarChart3,
  },
  {
    title: "Clinical Change Queue",
    url: createPageUrl("Notes"),
    icon: FileText,
  },
  {
    title: "Reimbursements",
    url: createPageUrl("Billing"),
    icon: DollarSign,
  }
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [user, setUser] = React.useState(null);

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await User.me();
        setUser(userData);
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();
  }, []);

  const handleLogout = async () => {
    await User.logout();
  };

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-slate-50">
        <Sidebar className="border-r border-slate-200 bg-white">
          <SidebarHeader className="border-b border-slate-100 p-4">
            <div className="flex flex-col items-center justify-center">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/517303104_careplix-logo784ea9f51.png" 
                alt="CarePlix Logo"
                className="h-8 w-auto mb-2"
              />
              <p className="text-xs font-medium text-slate-600 text-center">
                Clinical Workflow Application
              </p>
            </div>
          </SidebarHeader>
          
          <SidebarContent className="p-4">
            <SidebarGroup>
              <SidebarGroupLabel className="text-xs font-medium text-slate-500 uppercase tracking-wider px-3 py-2 mb-2">
                Clinical Tools
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu className="space-y-1">
                  {navigationItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton 
                        asChild 
                        className={`hover:bg-blue-50 hover:text-blue-700 transition-all duration-200 rounded-lg ${
                          location.pathname === item.url ? 'bg-blue-50 text-blue-700 border-r-2 border-blue-600' : 'text-slate-600'
                        }`}
                      >
                        <Link to={item.url} className="flex items-center gap-3 px-3 py-2.5">
                          <item.icon className="w-5 h-5" />
                          <span className="font-medium">{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            <SidebarGroup className="mt-8">
              <SidebarGroupLabel className="text-xs font-medium text-slate-500 uppercase tracking-wider px-3 py-2 mb-2">
                Quick Stats
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <div className="px-3 py-2 space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-600">Active Patients</span>
                    <span className="font-semibold text-slate-900">24</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-600">This Week's Visits</span>
                    <span className="font-semibold text-green-600">12</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-600">Alerts</span>
                    <span className="font-semibold text-amber-600">3</span>
                  </div>
                </div>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>

          <SidebarFooter className="border-t border-slate-100 p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <span className="text-blue-700 font-semibold text-sm">
                    {user?.full_name?.charAt(0) || 'D'}
                  </span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-slate-900 text-sm truncate">
                    Dr. {user?.full_name || 'Clinical User'}
                  </p>
                  <p className="text-xs text-slate-500 truncate">Endocrinologist</p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleLogout}
                className="text-slate-400 hover:text-slate-600"
              >
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 flex flex-col">
          <header className="bg-white border-b border-slate-200 px-6 py-4 md:hidden">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="hover:bg-slate-100 p-2 rounded-lg transition-colors duration-200" />
              <h1 className="text-xl font-semibold text-slate-900">GLP-1 Clinical</h1>
            </div>
          </header>

          <div className="flex-1 overflow-auto">
            {children}
          </div>
        </main>
      </div>
      
      <style>
        {`
          :root {
            --clinical-primary: #2563eb;
            --clinical-primary-light: #dbeafe;
            --clinical-success: #059669;
            --clinical-warning: #d97706;
            --clinical-danger: #dc2626;
            --clinical-text: #0f172a;
            --clinical-text-muted: #64748b;
            --clinical-border: #e2e8f0;
            --clinical-bg: #f8fafc;
          }
        `}
      </style>
    </SidebarProvider>
  );
}

