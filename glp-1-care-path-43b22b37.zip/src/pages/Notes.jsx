
import React, { useState, useEffect } from "react";
import { ClinicalNote, Patient } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Search, 
  Filter, 
  FileText, 
  Calendar, 
  User,
  AlertTriangle
} from "lucide-react";
import { format } from "date-fns";

export default function Notes() {
  const [notes, setNotes] = useState([]);
  const [patients, setPatients] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filter, setFilter] = useState("all");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadNotesData();
  }, []);

  const loadNotesData = async () => {
    try {
      const [notesData, patientsData] = await Promise.all([
        ClinicalNote.list("-created_date"),
        Patient.list()
      ]);
      
      // Create patient lookup for note display
      const patientLookup = {};
      patientsData.forEach(patient => {
        patientLookup[patient.id] = `${patient.first_name} ${patient.last_name}`;
      });

      // Add patient names to notes
      const notesWithPatientNames = notesData.map(note => ({
        ...note,
        patientName: patientLookup[note.patient_id] || 'Unknown Patient'
      }));

      setNotes(notesWithPatientNames);
      setPatients(patientsData);
    } catch (error) {
      console.error("Error loading notes data:", error);
      // Generate sample data
      const sampleNotes = generateSampleNotes();
      setNotes(sampleNotes);
    }
    setLoading(false);
  };

  const generateSampleNotes = () => {
    return [
      {
        id: '1',
        patient_id: 'p1',
        patientName: 'Sarah Johnson',
        note_type: 'Follow-up',
        content: 'Patient reports excellent tolerance to Semaglutide 1.0mg. Weight loss of 3.2kg since last visit. No GI side effects. Continue current regimen.',
        priority: 'Normal',
        clinician: 'dr.smith@clinic.com',
        created_date: '2024-02-15T10:30:00Z',
        tags: ['weight-loss', 'tolerance']
      },
      {
        id: '2',
        patient_id: 'p2',
        patientName: 'Michael Chen',
        note_type: 'Side effect management',
        content: 'Patient experiencing mild nausea with current Liraglutide dose. Recommend dosing with food and slower titration. Monitor for 2 weeks.',
        priority: 'High',
        clinician: 'dr.smith@clinic.com',
        created_date: '2024-02-14T14:15:00Z',
        tags: ['nausea', 'titration']
      },
      {
        id: '3',
        patient_id: 'p3',
        patientName: 'Emma Williams',
        note_type: 'Initial consultation',
        content: 'New patient with T2DM, HbA1c 8.7%. BMI 33.2. Good candidate for GLP-1 therapy. Started Semaglutide 0.25mg weekly. Education provided on injection technique.',
        priority: 'Normal',
        clinician: 'dr.johnson@clinic.com',
        created_date: '2024-02-13T09:45:00Z',
        tags: ['initiation', 'education', 'T2DM']
      },
      {
        id: '4',
        patient_id: 'p4',
        patientName: 'Robert Davis',
        note_type: 'Medication adjustment',
        content: 'Titrating Tirzepatide from 5mg to 7.5mg due to plateau in weight loss. Patient tolerating current dose well. F/U in 4 weeks.',
        priority: 'Normal',
        clinician: 'dr.brown@clinic.com',
        created_date: '2024-02-12T16:20:00Z',
        tags: ['titration', 'plateau']
      }
    ];
  };

  const filteredNotes = notes.filter(note => {
    const matchesSearch = searchTerm === "" || 
      note.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
      note.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      note.note_type.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFilter = filter === "all" || 
      note.note_type === filter || 
      note.priority === filter;
    
    return matchesSearch && matchesFilter;
  });

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'Low':
        return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'Normal':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'High':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'Urgent':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getTypeColor = (type) => {
    const colors = {
      'Initial consultation': 'bg-green-100 text-green-800',
      'Follow-up': 'bg-blue-100 text-blue-800',
      'Medication adjustment': 'bg-purple-100 text-purple-800',
      'Side effect management': 'bg-orange-100 text-orange-800',
      'General note': 'bg-gray-100 text-gray-800'
    };
    return colors[type] || 'bg-gray-100 text-gray-800';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 p-6">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold text-slate-900 mb-8">Loading Clinical Notes...</h1>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Clinical Change Queue</h1>
          <p className="text-slate-600 mt-1">
            View and manage all clinical notes across your patient panel
          </p>
        </div>

        {/* Search and Filters */}
        <Card className="shadow-sm border-slate-200">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                <Input
                  placeholder="Search notes, patients, or content..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <div className="flex items-center gap-2 flex-wrap">
                <Filter className="w-4 h-4 text-slate-500" />
                {['all', 'High', 'Urgent', 'Follow-up', 'Initial consultation'].map((filterOption) => (
                  <Button
                    key={filterOption}
                    variant={filter === filterOption ? "default" : "outline"}
                    size="sm"
                    onClick={() => setFilter(filterOption)}
                    className={filter === filterOption 
                      ? "bg-blue-600 hover:bg-blue-700" 
                      : "hover:bg-slate-50"
                    }
                  >
                    {filterOption === 'all' ? 'All Notes' : filterOption}
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Notes List */}
        <div className="space-y-4">
          {filteredNotes.length > 0 ? (
            filteredNotes.map((note) => (
              <Card key={note.id} className="border-slate-200 hover:shadow-md transition-shadow duration-200">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <FileText className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <CardTitle className="text-lg font-semibold text-slate-900">
                          {note.patientName}
                        </CardTitle>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge 
                            variant="secondary" 
                            className={`${getTypeColor(note.note_type)} text-xs`}
                          >
                            {note.note_type}
                          </Badge>
                          <Badge 
                            variant="outline" 
                            className={`${getPriorityColor(note.priority)} border text-xs`}
                          >
                            {note.priority === 'High' || note.priority === 'Urgent' ? (
                              <AlertTriangle className="w-3 h-3 mr-1" />
                            ) : null}
                            {note.priority}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <div className="text-right text-sm text-slate-500">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {format(new Date(note.created_date), "MMM d, yyyy 'at' h:mm a")}
                      </div>
                      <div className="flex items-center gap-1 mt-1">
                        <User className="w-3 h-3" />
                        {note.clinician}
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <p className="text-slate-700 leading-relaxed mb-4">
                    {note.content}
                  </p>
                  
                  {note.tags && note.tags.length > 0 && (
                    <div className="flex gap-2">
                      {note.tags.map((tag, index) => (
                        <Badge 
                          key={index}
                          variant="outline" 
                          className="text-xs bg-slate-100 text-slate-600"
                        >
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))
          ) : (
            <Card className="border-slate-200">
              <CardContent className="p-8 text-center">
                <FileText className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-500">No clinical notes found matching your search criteria.</p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="border-slate-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Total Notes</p>
                  <p className="text-2xl font-bold text-slate-900">{filteredNotes.length}</p>
                </div>
                <FileText className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">High Priority</p>
                  <p className="text-2xl font-bold text-orange-600">
                    {filteredNotes.filter(n => n.priority === 'High' || n.priority === 'Urgent').length}
                  </p>
                </div>
                <AlertTriangle className="w-8 h-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">This Week</p>
                  <p className="text-2xl font-bold text-green-600">
                    {filteredNotes.filter(n => {
                      const noteDate = new Date(n.created_date);
                      const weekAgo = new Date();
                      weekAgo.setDate(weekAgo.getDate() - 7);
                      return noteDate >= weekAgo;
                    }).length}
                  </p>
                </div>
                <Calendar className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Follow-ups</p>
                  <p className="text-2xl font-bold text-purple-600">
                    {filteredNotes.filter(n => n.note_type === 'Follow-up').length}
                  </p>
                </div>
                <User className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
