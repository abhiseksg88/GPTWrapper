import React, { useState, useEffect } from "react";
import { Patient, VitalRecord, LabResult, Prescription, AdherenceRecord, SideEffect } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Search, 
  Filter, 
  Plus, 
  AlertTriangle, 
  TrendingDown, 
  TrendingUp,
  User,
  Calendar,
  Activity
} from "lucide-react";
import { format } from "date-fns";

import PatientOverviewTable from "../components/dashboard/PatientOverviewTable";
import PatientDetailView from "../components/dashboard/PatientDetailView";
import NewPatientModal from "../components/dashboard/NewPatientModal";
import StatsCards from "../components/dashboard/StatsCards";
import QuickFilters from "../components/dashboard/QuickFilters";

export default function Dashboard() {
  const [patients, setPatients] = useState([]);
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCondition, setFilterCondition] = useState("all");
  const [showNewPatientModal, setShowNewPatientModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [dashboardStats, setDashboardStats] = useState({
    totalPatients: 0,
    highAdherence: 0,
    needsAttention: 0,
    newThisWeek: 0
  });

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    setLoading(true);
    try {
      const patientsData = await Patient.list("-created_date");
      
      // Calculate dashboard statistics
      const stats = {
        totalPatients: patientsData.length,
        highAdherence: Math.floor(patientsData.length * 0.75), // Simulated
        needsAttention: Math.floor(patientsData.length * 0.15), // Simulated
        newThisWeek: Math.floor(patientsData.length * 0.1) // Simulated
      };
      
      setPatients(patientsData);
      setDashboardStats(stats);
    } catch (error) {
      console.error("Error loading dashboard data:", error);
    }
    setLoading(false);
  };

  const filteredPatients = patients.filter(patient => {
    const matchesSearch = searchTerm === "" || 
      `${patient.first_name} ${patient.last_name}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.patient_id.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCondition = filterCondition === "all" || patient.primary_condition === filterCondition;
    
    return matchesSearch && matchesCondition;
  });

  const handleNewPatient = async (patientData) => {
    try {
      await Patient.create(patientData);
      setShowNewPatientModal(false);
      loadDashboardData();
    } catch (error) {
      console.error("Error creating patient:", error);
    }
  };

  if (selectedPatient) {
    return (
      <PatientDetailView 
        patient={selectedPatient}
        onBack={() => setSelectedPatient(null)}
        onUpdate={() => {
          loadDashboardData();
          setSelectedPatient(null);
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Patient Dashboard</h1>
            <p className="text-slate-600 mt-1">
              Manage your GLP-1 therapy patients and track their progress
            </p>
          </div>
          <Button 
            onClick={() => setShowNewPatientModal(true)}
            className="bg-blue-600 hover:bg-blue-700 shadow-sm"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add New Patient
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatsCards 
            title="Total Patients" 
            value={dashboardStats.totalPatients}
            icon={User}
            bgColor="bg-blue-500"
            trend={`+${dashboardStats.newThisWeek} this week`}
          />
          <StatsCards 
            title="High Adherence" 
            value={`${dashboardStats.highAdherence}`}
            icon={TrendingUp}
            bgColor="bg-green-500"
            trend="≥80% compliance"
          />
          <StatsCards 
            title="Needs Attention" 
            value={dashboardStats.needsAttention}
            icon={AlertTriangle}
            bgColor="bg-amber-500"
            trend="Missed doses/alerts"
          />
          <StatsCards 
            title="This Week" 
            value={`${dashboardStats.newThisWeek}`}
            icon={Calendar}
            bgColor="bg-purple-500"
            trend="New consultations"
          />
        </div>

        {/* Search and Filters */}
        <Card className="shadow-sm border-slate-200">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                <Input
                  placeholder="Search by patient name or ID..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <QuickFilters 
                selectedCondition={filterCondition}
                onConditionChange={setFilterCondition}
              />
            </div>
          </CardContent>
        </Card>

        {/* Patient Overview Table */}
        <Card className="shadow-sm border-slate-200">
          <CardHeader className="border-b border-slate-100">
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-blue-600" />
              Patient Overview
              <Badge variant="secondary" className="ml-auto">
                {filteredPatients.length} patients
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <PatientOverviewTable 
              patients={filteredPatients}
              onSelectPatient={setSelectedPatient}
              loading={loading}
            />
          </CardContent>
        </Card>

        {/* New Patient Modal */}
        {showNewPatientModal && (
          <NewPatientModal 
            onSave={handleNewPatient}
            onCancel={() => setShowNewPatientModal(false)}
          />
        )}
      </div>
    </div>
  );
}