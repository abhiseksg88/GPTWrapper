
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Patient, ClinicalNote, VitalRecord, LabResult, Prescription, ReimbursementAnalysis } from "@/api/entities";
import { User } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { DollarSign, Brain, Loader2, AlertCircle, Save, History } from 'lucide-react';
import { format, subDays } from 'date-fns';
import BillingAnalysisReport from '../components/billing/BillingAnalysisReport';
import SavedAnalysesList from '../components/billing/SavedAnalysesList';

export default function Billing() {
  const [patients, setPatients] = useState([]);
  const [selectedPatientId, setSelectedPatientId] = useState('');
  const [dateRange, setDateRange] = useState({
    from: format(subDays(new Date(), 30), 'yyyy-MM-dd'),
    to: format(new Date(), 'yyyy-MM-dd')
  });
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [analysis, setAnalysis] = useState(null);
  const [selectedIcdCodes, setSelectedIcdCodes] = useState([]); // State for selected codes
  const [error, setError] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [showSavedAnalyses, setShowSavedAnalyses] = useState(false);
  const [savedAnalyses, setSavedAnalyses] = useState([]);

  useEffect(() => {
    const loadInitialData = async () => {
      try {
        const [patientData, userData] = await Promise.all([
          Patient.list(),
          User.me()
        ]);
        setPatients(patientData);
        setCurrentUser(userData);
      } catch (err) {
        console.error("Failed to load initial data", err);
        setError("Failed to load initial data. Please try again later.");
      }
    };
    loadInitialData();
  }, []);

  useEffect(() => {
    if (selectedPatientId) {
      loadSavedAnalyses();
      setShowSavedAnalyses(true); // Auto-show saved analyses when patient is selected
    } else {
      setSavedAnalyses([]);
      setShowSavedAnalyses(false);
    }
  }, [selectedPatientId]);

  const loadSavedAnalyses = async () => {
    try {
      const analyses = await ReimbursementAnalysis.filter({ patient_id: selectedPatientId }, "-analysis_date");
      setSavedAnalyses(analyses);
    } catch (error) {
      console.error("Error loading saved analyses:", error);
    }
  };

  const handleDateChange = (field, value) => {
    setDateRange(prev => ({ ...prev, [field]: value }));
  };

  const handleAnalyzeBilling = async () => {
    if (!selectedPatientId || !dateRange.from || !dateRange.to) {
      setError("Please select a patient and a valid date range.");
      return;
    }
    setLoading(true);
    setError(null);
    setAnalysis(null);
    setSelectedIcdCodes([]); // Reset selections

    try {
      const patient = patients.find(p => p.id === selectedPatientId);
      
      const [notes, vitals, labs, prescriptions] = await Promise.all([
        ClinicalNote.filter({ patient_id: selectedPatientId }),
        VitalRecord.filter({ patient_id: selectedPatientId }),
        LabResult.filter({ patient_id: selectedPatientId }),
        Prescription.filter({ patient_id: selectedPatientId }),
      ]);

      const filterByDate = (records, dateField) => 
        records.filter(r => {
          const recordDate = new Date(r[dateField]);
          return recordDate >= new Date(dateRange.from) && recordDate <= new Date(dateRange.to);
        });

      const relevantData = {
        patient_info: `Patient: ${patient.first_name} ${patient.last_name}, Condition: ${patient.primary_condition}`,
        notes: filterByDate(notes, 'created_date').map(n => `On ${n.created_date}: [${n.note_type}] ${n.content}`).join('\\n'),
        vitals: filterByDate(vitals, 'recorded_date').map(v => `On ${v.recorded_date}: Weight ${v.weight_kg}kg, BP ${v.systolic_bp}/${v.diastolic_bp}`).join('\\n'),
        labs: filterByDate(labs, 'test_date').map(l => `On ${l.test_date}: HbA1c ${l.hba1c}%`).join('\\n'),
        prescriptions: filterByDate(prescriptions, 'start_date').map(p => `Prescribed ${p.medication_name} on ${p.start_date}`).join('\\n'),
      };

      const prompt = `
        You are an expert medical billing and coding specialist for US healthcare. Analyze the following clinical data for a patient on GLP-1 therapy from ${dateRange.from} to ${dateRange.to}.
        
        Clinical Data:
        - Patient Info: ${relevantData.patient_info}
        - Clinical Notes: ${relevantData.notes || 'None'}
        - Vitals Recorded: ${relevantData.vitals || 'None'}
        - Labs Recorded: ${relevantData.labs || 'None'}
        - Prescriptions: ${relevantData.prescriptions || 'None'}

        Based on this data, provide a billing analysis. Suggest appropriate ICD-10 and CPT codes. For CPT codes, suggest units and estimate reimbursement based on typical Medicare/Medicaid rates. Provide a clear rationale.
      `;

      const response_json_schema = {
        type: "object",
        properties: {
          suggested_icd10: {
            type: "array",
            items: {
              type: "object", properties: { code: { type: "string" }, description: { type: "string" } }
            }
          },
          suggested_cpt: {
            type: "array",
            items: {
              type: "object", properties: { 
                code: { type: "string" }, 
                description: { type: "string" },
                units: { type: "number" }, 
                estimated_reimbursement: { type: "string" },
                rationale: { type: "string" }
              }
            }
          },
          total_estimated_earnings: { type: "string" },
          summary_notes: { type: "string" }
        }
      };

      const result = await InvokeLLM({ prompt, response_json_schema });
      setAnalysis(result);
      setSelectedIcdCodes(result.suggested_icd10 || []); // Pre-select all suggested codes

    } catch (err) {
      console.error("Billing analysis failed:", err);
      setError("The AI analysis failed. This could be due to a network issue or a problem with the AI service. Please try again.");
    }

    setLoading(false);
  };
  
  const handleLoadSavedAnalysis = (savedAnalysis) => {
    // This function will be passed to SavedAnalysesList to load a past analysis
    const analysisReport = {
      suggested_icd10: savedAnalysis.suggested_icd10,
      suggested_cpt: savedAnalysis.suggested_cpt,
      total_estimated_earnings: savedAnalysis.total_estimated_earnings,
      summary_notes: savedAnalysis.summary_notes
    };
    setAnalysis(analysisReport);
    // Load confirmed codes if they exist, otherwise default to suggested codes
    setSelectedIcdCodes(savedAnalysis.confirmed_icd10 || savedAnalysis.suggested_icd10 || []);
  };

  const handleSaveAnalysis = async () => {
    if (!analysis || !currentUser || !selectedPatientId) return;

    setSaving(true);
    try {
      const analysisData = {
        patient_id: selectedPatientId,
        analysis_date: new Date().toISOString().split('T')[0],
        date_range_from: dateRange.from,
        date_range_to: dateRange.to,
        suggested_icd10: analysis.suggested_icd10,
        confirmed_icd10: selectedIcdCodes, // Save the selected codes
        suggested_cpt: analysis.suggested_cpt,
        total_estimated_earnings: analysis.total_estimated_earnings,
        summary_notes: analysis.summary_notes,
        analyzed_by: currentUser.email,
        status: 'Draft'
      };

      await ReimbursementAnalysis.create(analysisData);
      await loadSavedAnalyses(); // Refresh saved analyses list
      
      alert("Analysis saved successfully!");
    } catch (error) {
      console.error("Error saving analysis:", error);
      setError("Failed to save analysis. Please try again.");
    }
    setSaving(false);
  };

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Reimbursements</h1>
            <p className="text-slate-600 mt-1">
              Use CarePlix AI to analyze clinical activities and estimate potential reimbursements.
            </p>
          </div>
        </div>

        <Card className="shadow-sm border-slate-200">
          <CardHeader>
            <CardTitle>Reimbursement Analysis Setup</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-2">
                <Label htmlFor="patient-select">Select Patient</Label>
                <Select value={selectedPatientId} onValueChange={setSelectedPatientId}>
                  <SelectTrigger id="patient-select">
                    <SelectValue placeholder="Select a patient..." />
                  </SelectTrigger>
                  <SelectContent>
                    {patients.map(p => (
                      <SelectItem key={p.id} value={p.id}>
                        {p.first_name} {p.last_name} (ID: {p.patient_id})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="date-from">From</Label>
                <Input
                  id="date-from"
                  type="date"
                  value={dateRange.from}
                  onChange={e => handleDateChange('from', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="date-to">To</Label>
                <Input
                  id="date-to"
                  type="date"
                  value={dateRange.to}
                  onChange={e => handleDateChange('to', e.target.value)}
                />
              </div>
            </div>
            <div className="flex justify-end gap-3 pt-4">
              <Button onClick={handleAnalyzeBilling} disabled={loading || !selectedPatientId}>
                {loading ? (
                  <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Analyzing...</>
                ) : (
                  <><Brain className="w-4 h-4 mr-2" /> Analyze Reimbursements</>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {error && (
          <Card className="bg-red-50 border-red-200">
            <CardContent className="p-4 flex items-center gap-4">
              <AlertCircle className="w-6 h-6 text-red-600" />
              <div>
                <h4 className="font-semibold text-red-800">Analysis Error</h4>
                <p className="text-red-700">{error}</p>
              </div>
            </CardContent>
          </Card>
        )}

        {showSavedAnalyses && selectedPatientId && (
          <SavedAnalysesList 
            analyses={savedAnalyses}
            patient={patients.find(p => p.id === selectedPatientId)}
            onLoadAnalysis={handleLoadSavedAnalysis} // Pass new handler
          />
        )}

        {analysis && (
          <div className="space-y-4">
            <div className="flex justify-end">
              <Button 
                onClick={handleSaveAnalysis}
                disabled={saving}
                className="bg-green-600 hover:bg-green-700"
              >
                {saving ? (
                  <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saving...</>
                ) : (
                  <><Save className="w-4 h-4 mr-2" /> Save Analysis</>
                )}
              </Button>
            </div>
            <BillingAnalysisReport 
              analysis={analysis} 
              patient={patients.find(p => p.id === selectedPatientId)}
              selectedIcdCodes={selectedIcdCodes}
              onSelectionChange={setSelectedIcdCodes}
            />
          </div>
        )}

      </div>
    </div>
  );
}
