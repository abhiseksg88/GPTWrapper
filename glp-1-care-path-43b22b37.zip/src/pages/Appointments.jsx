import React, { useState, useEffect } from 'react';
import { Appointment, Patient } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Plus, Calendar, ListFilter } from 'lucide-react';
import { format } from 'date-fns';
import AppointmentFormModal from '../components/appointments/AppointmentFormModal';
import AppointmentsList from '../components/appointments/AppointmentsList';

export default function AppointmentsPage() {
  const [appointments, setAppointments] = useState([]);
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showFormModal, setShowFormModal] = useState(false);
  const [selectedAppointment, setSelectedAppointment] = useState(null);
  const [filter, setFilter] = useState('upcoming');
  const [patientMap, setPatientMap] = useState({});

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [appointmentsData, patientsData] = await Promise.all([
        Appointment.list('-appointment_date'),
        Patient.list()
      ]);
      
      const pMap = patientsData.reduce((acc, patient) => {
        acc[patient.id] = patient;
        return acc;
      }, {});
      setPatientMap(pMap);

      const sortedAppointments = appointmentsData.sort((a, b) => 
        new Date(a.appointment_date + 'T' + a.appointment_time) - new Date(b.appointment_date + 'T' + b.appointment_time)
      );
      setAppointments(sortedAppointments);
      setPatients(patientsData);
    } catch (error) {
      console.error("Error loading appointments data:", error);
    }
    setLoading(false);
  };
  
  const handleOpenForm = (appointment = null) => {
    setSelectedAppointment(appointment);
    setShowFormModal(true);
  };

  const handleCloseForm = () => {
    setSelectedAppointment(null);
    setShowFormModal(false);
  };

  const handleSave = async () => {
    await loadData();
    handleCloseForm();
  };

  const filteredAppointments = appointments.filter(app => {
    const appDate = new Date(app.appointment_date);
    const today = new Date();
    today.setHours(0,0,0,0);

    if (filter === 'upcoming') {
      return appDate >= today && app.status !== 'Completed' && app.status !== 'Cancelled';
    }
    if (filter === 'past') {
      return appDate < today || app.status === 'Completed' || app.status === 'Cancelled';
    }
    return true; // for 'all'
  });

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Appointments</h1>
            <p className="text-slate-600 mt-1">
              Manage patient appointments and reminders
            </p>
          </div>
          <Button 
            onClick={() => handleOpenForm()}
            className="bg-blue-600 hover:bg-blue-700 shadow-sm"
          >
            <Plus className="w-4 h-4 mr-2" />
            Schedule Appointment
          </Button>
        </div>

        <Card className="shadow-sm border-slate-200">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-blue-600" />
                  Appointments
              </CardTitle>
              <div className="flex items-center gap-2">
                <ListFilter className="w-4 h-4 text-slate-500" />
                  {['upcoming', 'past', 'all'].map((f) => (
                    <Button
                      key={f}
                      variant={filter === f ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setFilter(f)}
                      className="capitalize"
                    >
                      {f}
                    </Button>
                  ))}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <AppointmentsList
              appointments={filteredAppointments}
              patientMap={patientMap}
              onEdit={handleOpenForm}
              onUpdate={loadData}
              loading={loading}
            />
          </CardContent>
        </Card>

        {showFormModal && (
          <AppointmentFormModal
            appointment={selectedAppointment}
            patients={patients}
            onSave={handleSave}
            onCancel={handleCloseForm}
          />
        )}
      </div>
    </div>
  );
}