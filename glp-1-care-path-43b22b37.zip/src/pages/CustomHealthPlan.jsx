import React, { useState, useEffect } from 'react';
import { Patient, ConditionPlan } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Brain, 
  Search, 
  Filter, 
  Plus, 
  Calendar, 
  User, 
  FileText, 
  Activity,
  Target,
  TrendingUp
} from 'lucide-react';
import { format } from 'date-fns';
import ConditionPlanBuilder from '../components/planning/ConditionPlanBuilder';

export default function CustomHealthPlan() {
  const [patients, setPatients] = useState([]);
  const [plans, setPlans] = useState([]);
  const [filteredPlans, setFilteredPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [showPlanBuilder, setShowPlanBuilder] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    filterPlans();
  }, [plans, searchTerm, statusFilter]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [patientsData, plansData] = await Promise.all([
        Patient.list(),
        ConditionPlan.list('-created_date')
      ]);
      
      setPatients(patientsData);
      setPlans(plansData);
    } catch (error) {
      console.error('Error loading data:', error);
    }
    setLoading(false);
  };

  const filterPlans = () => {
    let filtered = [...plans];

    // Filter by search term
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase();
      filtered = filtered.filter(plan => {
        const patient = patients.find(p => p.id === plan.patient_id);
        const patientName = patient ? `${patient.first_name} ${patient.last_name}` : '';
        
        return (
          plan.plan_name.toLowerCase().includes(searchLower) ||
          plan.condition_description.toLowerCase().includes(searchLower) ||
          patientName.toLowerCase().includes(searchLower) ||
          plan.condition_icd10_code.toLowerCase().includes(searchLower)
        );
      });
    }

    // Filter by status
    if (statusFilter !== 'all') {
      filtered = filtered.filter(plan => plan.status === statusFilter);
    }

    setFilteredPlans(filtered);
  };

  const handleCreatePlan = (patient = null) => {
    setSelectedPatient(patient);
    setSelectedPlan(null);
    setShowPlanBuilder(true);
  };

  const handleEditPlan = (plan) => {
    const patient = patients.find(p => p.id === plan.patient_id);
    setSelectedPatient(patient);
    setSelectedPlan(plan);
    setShowPlanBuilder(true);
  };

  const handleSavePlan = async () => {
    await loadData();
    setShowPlanBuilder(false);
    setSelectedPatient(null);
    setSelectedPlan(null);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Active':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Draft':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Completed':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Paused':
        return 'bg-gray-100 text-gray-800 border-gray-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getPatientName = (patientId) => {
    const patient = patients.find(p => p.id === patientId);
    return patient ? `${patient.first_name} ${patient.last_name}` : 'Unknown Patient';
  };

  const statsData = {
    total: plans.length,
    active: plans.filter(p => p.status === 'Active').length,
    draft: plans.filter(p => p.status === 'Draft').length,
    completed: plans.filter(p => p.status === 'Completed').length
  };

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Custom Health Plans</h1>
            <p className="text-slate-600 mt-1">
              AI-powered condition management plans for personalized patient care
            </p>
          </div>
          <Button 
            onClick={() => handleCreatePlan()}
            className="bg-blue-600 hover:bg-blue-700 shadow-sm"
          >
            <Brain className="w-4 h-4 mr-2" />
            Create New Plan
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="border-slate-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Total Plans</p>
                  <p className="text-2xl font-bold text-slate-900">{statsData.total}</p>
                </div>
                <FileText className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Active Plans</p>
                  <p className="text-2xl font-bold text-green-600">{statsData.active}</p>
                </div>
                <Activity className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Draft Plans</p>
                  <p className="text-2xl font-bold text-yellow-600">{statsData.draft}</p>
                </div>
                <Target className="w-8 h-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Completed</p>
                  <p className="text-2xl font-bold text-purple-600">{statsData.completed}</p>
                </div>
                <TrendingUp className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <Card className="shadow-sm border-slate-200">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                <Input
                  placeholder="Search plans, patients, or conditions..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-slate-500" />
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="Active">Active</SelectItem>
                    <SelectItem value="Draft">Draft</SelectItem>
                    <SelectItem value="Completed">Completed</SelectItem>
                    <SelectItem value="Paused">Paused</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Plans List */}
        <Card className="shadow-sm border-slate-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="w-5 h-5 text-blue-600" />
              Health Management Plans
              <Badge variant="secondary" className="ml-auto">
                {filteredPlans.length} plans
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <div className="text-center">
                  <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-4"></div>
                  <p className="text-slate-600">Loading health plans...</p>
                </div>
              </div>
            ) : filteredPlans.length > 0 ? (
              <div className="space-y-4">
                {filteredPlans.map((plan) => (
                  <Card key={plan.id} className="border-slate-200 hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="text-lg font-semibold text-slate-900">
                              {plan.plan_name}
                            </h3>
                            <Badge variant="outline" className={getStatusColor(plan.status)}>
                              {plan.status}
                            </Badge>
                          </div>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
                            <div className="flex items-center gap-2">
                              <User className="w-4 h-4 text-slate-400" />
                              <span className="text-slate-600">Patient:</span>
                              <span className="font-medium">{getPatientName(plan.patient_id)}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <FileText className="w-4 h-4 text-slate-400" />
                              <span className="text-slate-600">Condition:</span>
                              <span className="font-medium">{plan.condition_icd10_code}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Calendar className="w-4 h-4 text-slate-400" />
                              <span className="text-slate-600">Created:</span>
                              <span className="font-medium">
                                {format(new Date(plan.created_date), 'MMM d, yyyy')}
                              </span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Target className="w-4 h-4 text-slate-400" />
                              <span className="text-slate-600">Components:</span>
                              <span className="font-medium">{plan.generated_components?.length || 0}</span>
                            </div>
                          </div>

                          <p className="text-slate-700 mt-2">{plan.condition_description}</p>
                        </div>
                        
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEditPlan(plan)}
                          className="ml-4"
                        >
                          View Details
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Brain className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-slate-900 mb-2">
                  {searchTerm || statusFilter !== 'all' ? 'No Plans Found' : 'No Health Plans Yet'}
                </h3>
                <p className="text-slate-600 mb-4">
                  {searchTerm || statusFilter !== 'all' 
                    ? 'Try adjusting your search criteria or filters.'
                    : 'Create your first AI-powered health management plan.'
                  }
                </p>
                <Button 
                  onClick={() => handleCreatePlan()}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Brain className="w-4 h-4 mr-2" />
                  Create Health Plan
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Plan Builder Modal */}
        {showPlanBuilder && (
          <ConditionPlanBuilder
            patient={selectedPatient}
            plan={selectedPlan}
            onSave={handleSavePlan}
            onCancel={() => {
              setShowPlanBuilder(false);
              setSelectedPatient(null);
              setSelectedPlan(null);
            }}
          />
        )}
      </div>
    </div>
  );
}