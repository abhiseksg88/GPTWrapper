import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { User } from "@/api/entities";
import ICD10CodeSelector from '../shared/ICD10CodeSelector';

export default function NewPatientModal({ onSave, onCancel }) {
  const [formData, setFormData] = useState({
    patient_id: '',
    first_name: '',
    last_name: '',
    email: '',
    date_of_birth: '',
    gender: '',
    height_cm: '',
    phone: '',
    emergency_contact: '',
    assigned_clinician: ''
  });
  const [primaryCondition, setPrimaryCondition] = useState(null);
  const [conditionQuery, setConditionQuery] = useState(""); // For AI context
  const [loading, setLoading] = useState(false);

  React.useEffect(() => {
    const setCurrentUser = async () => {
      try {
        const user = await User.me();
        setFormData(prev => ({
          ...prev,
          assigned_clinician: user.email
        }));
      } catch (error) {
        console.error("Error getting current user:", error);
      }
    };
    setCurrentUser();
  }, []);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const patientData = {
        ...formData,
        patient_id: formData.patient_id || `P${Date.now()}`,
        height_cm: formData.height_cm ? parseFloat(formData.height_cm) : undefined,
        primary_condition: primaryCondition
      };
      
      await onSave(patientData);
    } catch (error) {
      console.error("Error saving patient:", error);
    }
    
    setLoading(false);
  };

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="sm:max-w-xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold text-slate-900">
            Add New Patient
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6 mt-6">
          {/* ... other form fields ... */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="first_name">First Name *</Label>
              <Input
                id="first_name"
                value={formData.first_name}
                onChange={(e) => handleInputChange('first_name', e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="last_name">Last Name *</Label>
              <Input
                id="last_name"
                value={formData.last_name}
                onChange={(e) => handleInputChange('last_name', e.target.value)}
                required
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email Address *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                placeholder="patient@email.com"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="patient_id">Patient ID</Label>
              <Input
                id="patient_id"
                value={formData.patient_id}
                onChange={(e) => handleInputChange('patient_id', e.target.value)}
                placeholder="Auto-generated if empty"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="date_of_birth">Date of Birth</Label>
              <Input
                id="date_of_birth"
                type="date"
                value={formData.date_of_birth}
                onChange={(e) => handleInputChange('date_of_birth', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="gender">Gender</Label>
              <Select
                value={formData.gender}
                onValueChange={(value) => handleInputChange('gender', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select gender" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Male">Male</SelectItem>
                  <SelectItem value="Female">Female</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="height_cm">Height (cm)</Label>
            <Input
              id="height_cm"
              type="number"
              value={formData.height_cm}
              onChange={(e) => handleInputChange('height_cm', e.target.value)}
              placeholder="170"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="condition_query">Primary Condition / Diagnosis *</Label>
            <Input
              id="condition_query"
              value={conditionQuery}
              onChange={(e) => setConditionQuery(e.target.value)}
              placeholder="e.g., Type 2 Diabetes, Hypertension"
            />
            <p className="text-xs text-slate-500">Type a condition to get AI-powered ICD-10 suggestions below.</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="primary_condition">Primary Condition Code (ICD-10) *</Label>
            <ICD10CodeSelector
              value={primaryCondition}
              onSelect={setPrimaryCondition}
              contextualText={conditionQuery}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => handleInputChange('phone', e.target.value)}
                placeholder="+1 (555) 123-4567"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="emergency_contact">Emergency Contact</Label>
              <Input
                id="emergency_contact"
                value={formData.emergency_contact}
                onChange={(e) => handleInputChange('emergency_contact', e.target.value)}
                placeholder="Name and phone"
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-6">
            <Button
              type="button"
              variant="outline"
              onClick={onCancel}
              disabled={loading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={loading || !primaryCondition}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {loading ? "Creating..." : "Create Patient"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}