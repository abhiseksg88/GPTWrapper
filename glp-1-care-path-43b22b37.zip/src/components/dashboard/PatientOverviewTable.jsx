
import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertTriangle, CheckCircle2, Clock, ExternalLink } from "lucide-react";
import { format, differenceInYears } from "date-fns";

const getStatusColor = (adherence) => {
  if (adherence >= 80) return "bg-green-100 text-green-800 border-green-200";
  if (adherence >= 60) return "bg-yellow-100 text-yellow-800 border-yellow-200";
  return "bg-red-100 text-red-800 border-red-200";
};

const getStatusIcon = (adherence) => {
  if (adherence >= 80) return <CheckCircle2 className="w-3 h-3" />;
  if (adherence >= 60) return <Clock className="w-3 h-3" />;
  return <AlertTriangle className="w-3 h-3" />;
};

export default function PatientOverviewTable({ patients, onSelectPatient, loading }) {
  // Simulate additional data that would come from joined queries
  const getPatientStats = (patient) => {
    // In a real app, this would come from actual data joins
    const simulatedData = {
      currentWeight: 85.5 + Math.random() * 30,
      bmi: 28.5 + Math.random() * 8,
      lastHbA1c: 6.8 + Math.random() * 2,
      adherence: Math.floor(Math.random() * 40) + 60,
      lastDoseDate: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000),
      hasAlerts: Math.random() > 0.7
    };
    return simulatedData;
  };

  if (loading) {
    return (
      <div className="p-4">
        {Array(5).fill(0).map((_, i) => (
          <div key={i} className="flex items-center space-x-4 py-4">
            <Skeleton className="h-4 w-32" />
            <Skeleton className="h-4 w-16" />
            <Skeleton className="h-4 w-20" />
            <Skeleton className="h-4 w-24" />
            <Skeleton className="h-6 w-16 rounded-full" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="bg-slate-50">
            <TableHead className="font-semibold text-slate-700">Patient</TableHead>
            <TableHead className="font-semibold text-slate-700">Age</TableHead>
            <TableHead className="font-semibold text-slate-700">Condition</TableHead>
            <TableHead className="font-semibold text-slate-700">Weight / BMI</TableHead>
            <TableHead className="font-semibold text-slate-700">Latest HbA1c</TableHead>
            <TableHead className="font-semibold text-slate-700">Adherence</TableHead>
            <TableHead className="font-semibold text-slate-700">Last Dose</TableHead>
            <TableHead className="font-semibold text-slate-700">Status</TableHead>
            <TableHead className="font-semibold text-slate-700">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {patients.map((patient) => {
            const stats = getPatientStats(patient);
            const age = patient.date_of_birth 
              ? differenceInYears(new Date(), new Date(patient.date_of_birth))
              : 'N/A';

            return (
              <TableRow 
                key={patient.id} 
                className="cursor-pointer hover:bg-slate-50 transition-colors duration-150"
                onClick={() => onSelectPatient(patient)}
              >
                <TableCell>
                  <div>
                    <p className="font-medium text-slate-900">
                      {patient.first_name} {patient.last_name}
                    </p>
                    <p className="text-sm text-slate-500">ID: {patient.patient_id}</p>
                  </div>
                </TableCell>
                <TableCell className="text-slate-700">{age}</TableCell>
                <TableCell>
                  <Badge variant="secondary" className="text-xs text-wrap max-w-40">
                    {patient.primary_condition?.description || 'N/A'}
                  </Badge>
                </TableCell>
                <TableCell>
                  <div className="text-sm">
                    <p className="font-medium text-slate-900">{stats.currentWeight.toFixed(1)} kg</p>
                    <p className="text-slate-500">BMI: {stats.bmi.toFixed(1)}</p>
                  </div>
                </TableCell>
                <TableCell>
                  <span className={`font-medium ${
                    stats.lastHbA1c > 7 ? 'text-red-600' : 
                    stats.lastHbA1c > 6.5 ? 'text-yellow-600' : 'text-green-600'
                  }`}>
                    {stats.lastHbA1c.toFixed(1)}%
                  </span>
                </TableCell>
                <TableCell>
                  <Badge 
                    variant="outline" 
                    className={`${getStatusColor(stats.adherence)} border flex items-center gap-1 w-fit`}
                  >
                    {getStatusIcon(stats.adherence)}
                    {stats.adherence}%
                  </Badge>
                </TableCell>
                <TableCell className="text-sm text-slate-600">
                  {format(stats.lastDoseDate, "MMM d, yyyy")}
                </TableCell>
                <TableCell>
                  {stats.hasAlerts ? (
                    <Badge variant="destructive" className="text-xs">
                      <AlertTriangle className="w-3 h-3 mr-1" />
                      Alert
                    </Badge>
                  ) : (
                    <Badge variant="secondary" className="text-xs bg-green-100 text-green-800">
                      Normal
                    </Badge>
                  )}
                </TableCell>
                <TableCell>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectPatient(patient);
                    }}
                    className="text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </Button>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
      
      {patients.length === 0 && (
        <div className="p-8 text-center">
          <p className="text-slate-500">No patients found matching your criteria.</p>
        </div>
      )}
    </div>
  );
}
