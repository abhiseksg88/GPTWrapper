
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  ArrowLeft,
  User,
  Activity,
  Pill,
  FileText,
  AlertTriangle,
  TrendingDown,
  TrendingUp,
  Calendar,
  Phone,
  Mail,
  FlaskConical,
  Stethoscope
} from "lucide-react";
import { format, differenceInYears } from "date-fns";

import VitalsChart from "../patient/VitalsChart";
import MedicationHistory from "../patient/MedicationHistory";
import AdherenceChart from "../patient/AdherenceChart";
import SideEffectsLog from "../patient/SideEffectsLog";
import ClinicalNotesPanel from "../patient/ClinicalNotesPanel";
import LifestylePlanPanel from "../patient/LifestylePlanPanel";
import DiagnosticTestPanel from "../patient/DiagnosticTestPanel";
import ProcedurePanel from "../patient/ProcedurePanel";
import PrescriptionModal from "../patient/PrescriptionModal";
import VitalsEntryModal from "../patient/VitalsEntryModal";
import LabEntryModal from "../patient/LabEntryModal";
import DiagnosticTestModal from "../patient/DiagnosticTestModal";
import ProcedureModal from "../patient/ProcedureModal";
import PatientPlanDownload from "../patient/PatientPlanDownload";
import PatientPlanGeneration from "../patient/PatientPlanGeneration";
import EditPatientModal from "./EditPatientModal"; // Fixed import path
import PatientPlansView from "../planning/PatientPlansView"; // Fixed import path

// --- MOCK API FOR DEMONSTRATION PURPOSES ---
// In a real application, these would be actual API calls or ORM interactions
// from a service layer or backend integration.
const mockApi = {
  VitalRecord: {
    filter: async ({ patient_id }, sortBy) => {
      console.log(`[Mock API] Fetching vitals for patient ${patient_id}, sorted by ${sortBy}`);
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 100));
      return [
        { type: 'weight', value: 87.3, unit: 'kg', recorded_date: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000) },
        { type: 'blood_pressure', value: '125/85', recorded_date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000) },
        { type: 'hba1c', value: 6.9, unit: '%', recorded_date: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) },
        { type: 'hba1c', value: 8.2, unit: '%', recorded_date: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000) },
        { type: 'weight', value: 89.7, unit: 'kg', recorded_date: new Date(Date.now() - 40 * 24 * 60 * 60 * 1000) },
      ].sort((a, b) => {
        if (sortBy === "-recorded_date") return new Date(b.recorded_date) - new Date(a.recorded_date);
        return 0;
      });
    }
  },
  Prescription: {
    filter: async ({ patient_id }, sortBy) => {
      console.log(`[Mock API] Fetching prescriptions for patient ${patient_id}, sorted by ${sortBy}`);
      await new Promise(resolve => setTimeout(resolve, 100));
      return [
        { id: 'rx1', medication: 'Metformin', dosage: '500mg', frequency: 'Twice daily', status: 'Active', start_date: new Date(2023, 0, 1), end_date: null },
        { id: 'rx2', medication: 'Lisinopril', dosage: '10mg', frequency: 'Once daily', status: 'Active', start_date: new Date(2022, 5, 15), end_date: null },
        { id: 'rx3', medication: 'Vitamin D', dosage: '1000IU', frequency: 'Once daily', status: 'Inactive', start_date: new Date(2023, 1, 1), end_date: new Date(2023, 2, 1) },
      ].sort((a, b) => {
        if (sortBy === "-start_date") return new Date(b.start_date) - new Date(a.start_date);
        return 0;
      });
    }
  },
  LifestylePlan: {
    filter: async ({ patient_id }, sortBy) => {
      console.log(`[Mock API] Fetching lifestyle plans for patient ${patient_id}, sorted by ${sortBy}`);
      await new Promise(resolve => setTimeout(resolve, 100));
      return [
        { id: 'lp1', type: 'Diet', description: 'Low carb, high protein. Focus on whole foods and portion control.', start_date: new Date(2023, 3, 1), end_date: null },
        { id: 'lp2', type: 'Exercise', description: '30 minutes moderate intensity walk daily. Incorporate strength training 2x/week.', start_date: new Date(2023, 3, 1), end_date: null },
        { id: 'lp3', type: 'Stress Management', description: 'Practice 15 minutes of mindfulness meditation daily.', start_date: new Date(2023, 6, 1), end_date: null },
      ].sort((a, b) => {
        if (sortBy === "-start_date") return new Date(b.start_date) - new Date(a.start_date);
        return 0;
      });
    }
  },
  // --- NEW MOCK DATA ---
  AdherenceRecord: {
    filter: async ({ patient_id }, sortBy) => {
      console.log(`[Mock API] Fetching adherence for patient ${patient_id}`);
      await new Promise(resolve => setTimeout(resolve, 50));
      return [
        { id: 'ad1', dose_date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000), dose_taken: true },
        { id: 'ad2', dose_date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), dose_taken: true },
        { id: 'ad3', dose_date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), dose_taken: false },
        { id: 'ad4', dose_date: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000), dose_taken: true },
      ].sort((a, b) => new Date(b.dose_date) - new Date(a.dose_date));
    }
  },
  SideEffect: {
    filter: async ({ patient_id }, sortBy) => {
      console.log(`[Mock API] Fetching side effects for patient ${patient_id}`);
      await new Promise(resolve => setTimeout(resolve, 50));
      return [
        { id: 'se1', effect_type: 'Nausea', severity: 'Mild', onset_date: new Date(2023, 5, 10), notes: 'Occurs shortly after injection, resolves within a few hours.'},
        { id: 'se2', effect_type: 'Headache', severity: 'Moderate', onset_date: new Date(2023, 6, 2), notes: 'Reported on the day after injection.'},
      ].sort((a, b) => new Date(b.onset_date) - new Date(a.onset_date));
    }
  },
  ClinicalNote: {
    filter: async ({ patient_id }, sortBy) => {
      console.log(`[Mock API] Fetching clinical notes for patient ${patient_id}`);
      await new Promise(resolve => setTimeout(resolve, 50));
      return [
        { id: 'cn1', note_type: 'Follow-up', content: 'Patient is responding well to the increased dosage. Weight is trending down, and patient reports higher energy levels. Continue current plan.', clinician: 'Dr. Evelyn Reed', created_date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000) },
        { id: 'cn2', note_type: 'Medication adjustment', content: 'Titrated Semaglutide from 0.5mg to 1.0mg. Patient counseled on potential for increased GI side effects and management strategies.', clinician: 'Dr. Evelyn Reed', created_date: new Date(Date.now() - 35 * 24 * 60 * 60 * 1000) },
      ].sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
    }
  },
  DiagnosticTest: {
    filter: async ({ patient_id }) => {
      console.log(`[Mock API] Fetching diagnostic tests for patient ${patient_id}`);
      await new Promise(resolve => setTimeout(resolve, 50));
      return [
        { id: 'dt1', test_name: 'Lipid Panel', category: 'Lab Work', status: 'Results Received', order_date: new Date(2023, 5, 1), results_summary: 'LDL slightly elevated.' },
        { id: 'dt2', test_name: 'A1c Check', category: 'Lab Work', status: 'Completed', order_date: new Date(2023, 8, 15) },
      ].sort((a, b) => new Date(b.order_date) - new Date(a.order_date));
    }
  },
  Procedure: {
    filter: async ({ patient_id }) => {
      console.log(`[Mock API] Fetching procedures for patient ${patient_id}`);
      await new Promise(resolve => setTimeout(resolve, 50));
      return [
        { id: 'proc1', procedure_name: 'Annual Eye Exam', category: 'Diagnostic', status: 'Completed', scheduled_date: new Date(2023, 7, 20), notes: 'No signs of retinopathy.' },
      ].sort((a, b) => new Date(b.scheduled_date) - new Date(a.scheduled_date));
    }
  }
};

// Assign mock API functions (or real API functions if available in the project context)
const VitalRecord = mockApi.VitalRecord;
const Prescription = mockApi.Prescription;
const LifestylePlan = mockApi.LifestylePlan;
const AdherenceRecord = mockApi.AdherenceRecord;
const SideEffect = mockApi.SideEffect;
const ClinicalNote = mockApi.ClinicalNote;
const DiagnosticTest = mockApi.DiagnosticTest;
const Procedure = mockApi.Procedure;
// --- END MOCK API ---


export default function PatientDetailView({ patient, onBack, onUpdate }) {
  const [activeTab, setActiveTab] = useState("overview");
  const [showPrescriptionModal, setShowPrescriptionModal] = useState(false);
  const [showVitalsModal, setShowVitalsModal] = useState(false);
  const [showLabModal, setShowLabModal] = useState(false);
  const [showTestModal, setShowTestModal] = useState(false);
  const [showProcedureModal, setShowProcedureModal] = useState(false);
  const [showPlanGeneration, setShowPlanGeneration] = useState(false);
  const [showEditPatient, setShowEditPatient] = useState(false); // New state
  const [patientStats, setPatientStats] = useState(null);
  const [patientData, setPatientData] = useState({
    vitals: [],
    prescriptions: [],
    lifestylePlans: [],
    adherenceRecords: [],
    sideEffects: [],
    clinicalNotes: [],
    diagnosticTests: [],
    procedures: []
  });

  useEffect(() => {
    loadPatientData();
  }, [patient]); // Reload data when the patient prop changes

  const loadPatientData = async () => {
    try {
      // Load comprehensive patient data for plan generation and stats calculation
      const [vitals, prescriptions, lifestylePlans, adherenceRecords, sideEffects, clinicalNotes, diagnosticTests, procedures] = await Promise.all([
        VitalRecord.filter({ patient_id: patient.id }, "-recorded_date"),
        Prescription.filter({ patient_id: patient.id }, "-start_date"),
        LifestylePlan.filter({ patient_id: patient.id }, "-start_date"),
        AdherenceRecord.filter({ patient_id: patient.id }, "-dose_date"),
        SideEffect.filter({ patient_id: patient.id }, "-onset_date"),
        ClinicalNote.filter({ patient_id: patient.id }, "-created_date"),
        DiagnosticTest.filter({ patient_id: patient.id }, "-order_date"),
        Procedure.filter({ patient_id: patient.id }, "-scheduled_date")
      ]);

      setPatientData({ vitals, prescriptions, lifestylePlans, adherenceRecords, sideEffects, clinicalNotes, diagnosticTests, procedures });

      // Calculate stats based on fetched data
      const currentWeightRecord = vitals.find(v => v.type === 'weight');
      const lastHbA1cRecord = vitals.find(v => v.type === 'hba1c');
      const previousHbA1cRecord = vitals.filter(v => v.type === 'hba1c').length > 1 ? vitals.filter(v => v.type === 'hba1c')[1] : null;

      const totalAdherenceRecords = adherenceRecords.length;
      const takenDoses = adherenceRecords.filter(r => r.dose_taken).length;
      const adherenceRate = totalAdherenceRecords > 0 ? Math.round((takenDoses / totalAdherenceRecords) * 100) : 100;

      const stats = {
        currentWeight: currentWeightRecord?.value || null,
        // For weightChange, you'd need initial weight or a comparison point, mocking for now
        weightChange: currentWeightRecord?.value ? (currentWeightRecord.value - 99.7).toFixed(1) : null, // Mocking a change from a hypothetical initial weight
        bmi: currentWeightRecord?.value && patient.height_cm ? (currentWeightRecord.value / ((patient.height_cm / 100) ** 2)).toFixed(1) : null,
        lastHbA1c: lastHbA1cRecord?.value || null,
        hba1cChange: lastHbA1cRecord?.value && previousHbA1cRecord?.value ? (lastHbA1cRecord.value - previousHbA1cRecord.value).toFixed(1) : null,
        adherenceRate: adherenceRate, // Dynamic based on fetched data
        activePrescriptions: prescriptions.filter(p => p.status === 'Active').length, // Dynamic based on fetched data
        lastVisit: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000) // Still simulated
      };
      setPatientStats(stats);
    } catch (error) {
      console.error("Error loading patient data:", error);
      // In a production app, you might set an error state or show a toast message
    }
  };

  const age = patient.date_of_birth
    ? differenceInYears(new Date(), new Date(patient.date_of_birth))
    : 'N/A';

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              size="icon"
              onClick={onBack}
              className="hover:bg-slate-100"
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">
                {patient.first_name} {patient.last_name}
              </h1>
              <p className="text-slate-600">
                Patient ID: {patient.patient_id} • {patient.primary_condition?.description} • Age: {age}
              </p>
            </div>
          </div>
          <div className="flex gap-3 flex-wrap justify-end">
            <Button
              onClick={() => setShowEditPatient(true)}
              variant="outline"
              className="hover:bg-slate-50 border-slate-200 text-slate-700"
            >
              <User className="w-4 h-4 mr-2" />
              Edit Patient
            </Button>
            <Button
              onClick={() => setShowPlanGeneration(true)}
              variant="outline"
              className="hover:bg-purple-50 border-purple-200 text-purple-700"
            >
              <FileText className="w-4 h-4 mr-2" />
              Generate Plan
            </Button>
            <PatientPlanDownload
              patient={patient}
              vitals={patientData.vitals}
              prescriptions={patientData.prescriptions}
              lifestylePlans={patientData.lifestylePlans}
              adherenceRecords={patientData.adherenceRecords}
              sideEffects={patientData.sideEffects}
              clinicalNotes={patientData.clinicalNotes}
            />
            <Button
              onClick={() => setShowVitalsModal(true)}
              variant="outline"
              className="hover:bg-blue-50"
            >
              <Activity className="w-4 h-4 mr-2" />
              Log Vitals
            </Button>
            <Button
              onClick={() => setShowLabModal(true)}
              variant="outline"
              className="hover:bg-green-50"
            >
              <FileText className="w-4 h-4 mr-2" />
              Add Lab Results
            </Button>
            <Button
              onClick={() => setShowTestModal(true)}
              variant="outline"
              className="hover:bg-indigo-50"
            >
              <FlaskConical className="w-4 h-4 mr-2" />
              Order Test
            </Button>
             <Button
              onClick={() => setShowProcedureModal(true)}
              variant="outline"
              className="hover:bg-teal-50"
            >
              <Stethoscope className="w-4 h-4 mr-2" />
              Schedule Procedure
            </Button>
            <Button
              onClick={() => setShowPrescriptionModal(true)}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Pill className="w-4 h-4 mr-2" />
              New Prescription
            </Button>
          </div>
        </div>

        {/* Patient Info Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="border-slate-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
                <TrendingDown className="w-4 h-4" />
                Current Weight
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="text-2xl font-bold text-slate-900">
                {patientStats && patientStats.currentWeight !== null ? `${patientStats.currentWeight} kg` : '-- kg'}
              </div>
              <p className="text-sm text-green-600 font-medium">
                {patientStats && patientStats.weightChange !== null ? `${patientStats.weightChange} kg since start` : '-- kg since start'}
              </p>
            </CardContent>
          </Card>

          <Card className="border-slate-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
                <Activity className="w-4 h-4" />
                BMI
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="text-2xl font-bold text-slate-900">
                {patientStats?.bmi || '--'}
              </div>
              <p className="text-sm text-slate-500">
                {patient.height_cm && `Height: ${patient.height_cm}cm`}
              </p>
            </CardContent>
          </Card>

          <Card className="border-slate-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                Latest HbA1c
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="text-2xl font-bold text-slate-900">
                {patientStats && patientStats.lastHbA1c !== null ? `${patientStats.lastHbA1c}%` : '--%'}
              </div>
              <p className="text-sm text-green-600 font-medium">
                {patientStats && patientStats.hba1cChange !== null ? `${patientStats.hba1cChange}% change` : '--% change'}
              </p>
            </CardContent>
          </Card>

          <Card className="border-slate-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
                <Pill className="w-4 h-4" />
                Adherence Rate
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="text-2xl font-bold text-slate-900">
                {patientStats && patientStats.adherenceRate !== null ? `${patientStats.adherenceRate}%` : '--%'}
              </div>
              <p className="text-sm text-slate-500">
                Last 30 days
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Patient Details Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-9 bg-slate-100">
            <TabsTrigger value="overview" className="data-[state=active]:bg-white">
              Overview
            </TabsTrigger>
            <TabsTrigger value="lifestyle" className="data-[state=active]:bg-white">
              Lifestyle Plan
            </TabsTrigger>
            <TabsTrigger value="vitals" className="data-[state=active]:bg-white">
              Vitals
            </TabsTrigger>
            <TabsTrigger value="diagnostics" className="data-[state=active]:bg-white">
              Diagnostics
            </TabsTrigger>
            <TabsTrigger value="procedures" className="data-[state=active]:bg-white">
              Procedures
            </TabsTrigger>
            <TabsTrigger value="medications" className="data-[state=active]:bg-white">
              Medications
            </TabsTrigger>
            <TabsTrigger value="adherence" className="data-[state=active]:bg-white">
              Adherence
            </TabsTrigger>
            <TabsTrigger value="side-effects" className="data-[state=active]:bg-white">
              Side Effects
            </TabsTrigger>
            <TabsTrigger value="notes" className="data-[state=active]:bg-white">
              Notes
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card className="lg:col-span-2 border-slate-200">
                <CardHeader>
                  <CardTitle>Patient Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm font-medium text-slate-600">Full Name</p>
                      <p className="text-slate-900">{patient.first_name} {patient.last_name}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-slate-600">Patient ID</p>
                      <p className="text-slate-900">{patient.patient_id}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-slate-600">Date of Birth</p>
                      <p className="text-slate-900">
                        {patient.date_of_birth
                          ? format(new Date(patient.date_of_birth), "MMM d, yyyy")
                          : 'Not specified'
                        }
                      </p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-slate-600">Gender</p>
                      <p className="text-slate-900">{patient.gender || 'Not specified'}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-slate-600">Primary Condition</p>
                      <Badge variant="secondary">{patient.primary_condition?.description || 'N/A'}</Badge>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-slate-600">Assigned Clinician</p>
                      <p className="text-slate-900">{patient.assigned_clinician}</p>
                    </div>
                  </div>

                  {(patient.phone || patient.emergency_contact) && (
                    <div className="pt-4 border-t border-slate-100">
                      <h4 className="font-medium text-slate-900 mb-3">Contact Information</h4>
                      <div className="space-y-2">
                        {patient.phone && (
                          <div className="flex items-center gap-2 text-sm">
                            <Phone className="w-4 h-4 text-slate-400" />
                            <span className="text-slate-600">Phone:</span>
                            <span className="text-slate-900">{patient.phone}</span>
                          </div>
                        )}
                        {patient.emergency_contact && (
                          <div className="flex items-center gap-2 text-sm">
                            <AlertTriangle className="w-4 h-4 text-slate-400" />
                            <span className="text-slate-600">Emergency:</span>
                            <span className="text-slate-900">{patient.emergency_contact}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="border-slate-200">
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => setShowVitalsModal(true)}
                  >
                    <Activity className="w-4 h-4 mr-2" />
                    Log Patient Vitals
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => setShowLabModal(true)}
                  >
                    <FileText className="w-4 h-4 mr-2" />
                    Add Lab Results
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => setShowTestModal(true)}
                  >
                    <FlaskConical className="w-4 h-4 mr-2" />
                    Order Diagnostic Test
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => setShowProcedureModal(true)}
                  >
                    <Stethoscope className="w-4 h-4 mr-2" />
                    Schedule Procedure
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => setActiveTab("vitals")}
                  >
                    <Activity className="w-4 h-4 mr-2" />
                    View Vitals Chart
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => setActiveTab("medications")}
                  >
                    <Pill className="w-4 h-4 mr-2" />
                    Medication History
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => setActiveTab("notes")}
                  >
                    <FileText className="w-4 h-4 mr-2" />
                    Clinical Notes
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => setShowPrescriptionModal(true)}
                  >
                    <Pill className="w-4 h-4 mr-2" />
                    New Prescription
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="management-plans">
            <PatientPlansView patient={patient} />
          </TabsContent>

          <TabsContent value="lifestyle">
            <LifestylePlanPanel patientId={patient.id} patient={patient} />
          </TabsContent>

          <TabsContent value="vitals">
            <VitalsChart patientId={patient.id} />
          </TabsContent>

          <TabsContent value="diagnostics">
            <DiagnosticTestPanel patientId={patient.id} />
          </TabsContent>

          <TabsContent value="procedures">
            <ProcedurePanel patientId={patient.id} />
          </TabsContent>

          <TabsContent value="medications">
            <MedicationHistory patientId={patient.id} />
          </TabsContent>

          <TabsContent value="adherence">
            <AdherenceChart patientId={patient.id} />
          </TabsContent>

          <TabsContent value="side-effects">
            <SideEffectsLog patientId={patient.id} />
          </TabsContent>

          <TabsContent value="notes">
            <ClinicalNotesPanel patientId={patient.id} />
          </TabsContent>
        </Tabs>

        {/* Modals */}
        {showEditPatient && (
          <EditPatientModal
            patient={patient}
            onSave={() => {
              setShowEditPatient(false);
              onUpdate(); // Triggers re-render of patient list / parent component
            }}
            onCancel={() => setShowEditPatient(false)}
          />
        )}

        {showPrescriptionModal && (
          <PrescriptionModal
            patient={patient}
            onSave={() => {
              setShowPrescriptionModal(false);
              onUpdate();
              loadPatientData(); // Reload data to reflect changes in stats/plan data
            }}
            onCancel={() => setShowPrescriptionModal(false)}
          />
        )}

        {showVitalsModal && (
          <VitalsEntryModal
            patient={patient}
            onSave={() => {
              setShowVitalsModal(false);
              onUpdate();
              loadPatientData(); // Reload data to reflect changes in stats/plan data
            }}
            onCancel={() => setShowVitalsModal(false)}
          />
        )}

        {showLabModal && (
          <LabEntryModal
            patient={patient}
            onSave={() => {
              setShowLabModal(false);
              onUpdate();
              loadPatientData(); // Reload data to reflect changes in stats/plan data
            }}
            onCancel={() => setShowLabModal(false)}
          />
        )}

        {showTestModal && (
          <DiagnosticTestModal
            patient={patient}
            onSave={() => {
              setShowTestModal(false);
              onUpdate();
              loadPatientData();
            }}
            onCancel={() => setShowTestModal(false)}
          />
        )}

        {showProcedureModal && (
          <ProcedureModal
            patient={patient}
            onSave={() => {
              setShowProcedureModal(false);
              onUpdate();
              loadPatientData();
            }}
            onCancel={() => setShowProcedureModal(false)}
          />
        )}

        {showPlanGeneration && (
          <PatientPlanGeneration
            patient={patient}
            patientData={patientData}
            patientStats={patientStats}
            onClose={() => setShowPlanGeneration(false)}
          />
        )}
      </div>
    </div>
  );
}
