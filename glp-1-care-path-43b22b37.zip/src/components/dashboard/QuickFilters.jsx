import React from 'react';
import { Button } from "@/components/ui/button";
import { Filter } from "lucide-react";

const conditions = [
  { value: "all", label: "All Conditions" },
  { value: "Type 2 Diabetes", label: "Type 2 Diabetes" },
  { value: "Obesity", label: "Obesity" },
  { value: "Cardiometabolic Risk", label: "Cardiometabolic" },
  { value: "Pre-diabetes", label: "Pre-diabetes" }
];

export default function QuickFilters({ selectedCondition, onConditionChange }) {
  return (
    <div className="flex items-center gap-2 flex-wrap">
      <Filter className="w-4 h-4 text-slate-500" />
      {conditions.map((condition) => (
        <Button
          key={condition.value}
          variant={selectedCondition === condition.value ? "default" : "outline"}
          size="sm"
          onClick={() => onConditionChange(condition.value)}
          className={selectedCondition === condition.value 
            ? "bg-blue-600 hover:bg-blue-700" 
            : "hover:bg-slate-50"
          }
        >
          {condition.label}
        </Button>
      ))}
    </div>
  );
}