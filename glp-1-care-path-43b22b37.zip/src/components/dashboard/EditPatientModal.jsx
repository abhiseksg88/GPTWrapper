import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Patient } from "@/api/entities";
import { Loader2 } from "lucide-react";
import { format } from "date-fns";

export default function EditPatientModal({ patient, onSave, onCancel }) {
  const [formData, setFormData] = useState({
    patient_id: patient.patient_id || '',
    first_name: patient.first_name || '',
    last_name: patient.last_name || '',
    email: patient.email || '',
    date_of_birth: patient.date_of_birth ? format(new Date(patient.date_of_birth), 'yyyy-MM-dd') : '',
    gender: patient.gender || '',
    height_cm: patient.height_cm ? patient.height_cm.toString() : '',
    primary_condition: patient.primary_condition || '',
    phone: patient.phone || '',
    emergency_contact: patient.emergency_contact || '',
    assigned_clinician: patient.assigned_clinician || ''
  });
  const [loading, setLoading] = useState(false);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const updateData = {
        ...formData,
        height_cm: formData.height_cm ? parseFloat(formData.height_cm) : undefined
      };
      
      await Patient.update(patient.id, updateData);
      onSave();
    } catch (error) {
      console.error("Error updating patient:", error);
    }
    
    setLoading(false);
  };

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="sm:max-w-xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold text-slate-900">
            Edit Patient Information
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="first_name">First Name *</Label>
              <Input
                id="first_name"
                value={formData.first_name}
                onChange={(e) => handleInputChange('first_name', e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="last_name">Last Name *</Label>
              <Input
                id="last_name"
                value={formData.last_name}
                onChange={(e) => handleInputChange('last_name', e.target.value)}
                required
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email Address *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="patient_id">Patient ID *</Label>
              <Input
                id="patient_id"
                value={formData.patient_id}
                onChange={(e) => handleInputChange('patient_id', e.target.value)}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="date_of_birth">Date of Birth</Label>
              <Input
                id="date_of_birth"
                type="date"
                value={formData.date_of_birth}
                onChange={(e) => handleInputChange('date_of_birth', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="gender">Gender</Label>
              <Select
                value={formData.gender}
                onValueChange={(value) => handleInputChange('gender', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select gender" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Male">Male</SelectItem>
                  <SelectItem value="Female">Female</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="height_cm">Height (cm)</Label>
            <Input
              id="height_cm"
              type="number"
              value={formData.height_cm}
              onChange={(e) => handleInputChange('height_cm', e.target.value)}
              placeholder="170"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="primary_condition">Primary Condition *</Label>
            <Select
              value={formData.primary_condition}
              onValueChange={(value) => handleInputChange('primary_condition', value)}
              required
            >
              <SelectTrigger>
                <SelectValue placeholder="Select primary condition" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Type 2 Diabetes">Type 2 Diabetes</SelectItem>
                <SelectItem value="Obesity">Obesity</SelectItem>
                <SelectItem value="Cardiometabolic Risk">Cardiometabolic Risk</SelectItem>
                <SelectItem value="Pre-diabetes">Pre-diabetes</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => handleInputChange('phone', e.target.value)}
                placeholder="+1 (555) 123-4567"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="emergency_contact">Emergency Contact</Label>
              <Input
                id="emergency_contact"
                value={formData.emergency_contact}
                onChange={(e) => handleInputChange('emergency_contact', e.target.value)}
                placeholder="Name and phone"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="assigned_clinician">Assigned Clinician</Label>
            <Input
              id="assigned_clinician"
              value={formData.assigned_clinician}
              onChange={(e) => handleInputChange('assigned_clinician', e.target.value)}
              placeholder="clinician@example.com"
            />
          </div>

          <div className="flex justify-end gap-3 pt-6">
            <Button
              type="button"
              variant="outline"
              onClick={onCancel}
              disabled={loading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={loading}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Updating...
                </>
              ) : (
                'Update Patient'
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}