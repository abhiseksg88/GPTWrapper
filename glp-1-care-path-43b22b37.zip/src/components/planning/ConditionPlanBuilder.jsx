
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ConditionPlan } from "@/api/entities";
import { User } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { 
  Brain, 
  Loader2, 
  Target, 
  Apple, 
  Activity, 
  FlaskConical, 
  Pill, 
  CheckCircle, 
  AlertTriangle, 
  FileText, 
  TrendingUp,
  Sparkles
} from 'lucide-react';
import ICD10CodeSelector from '../shared/ICD10CodeSelector';

const componentIcons = {
  "Goals": Target,
  "Lifestyle": TrendingUp,
  "Diet": Apple,
  "Vitals": Activity,
  "Diagnostic": FlaskConical,
  "Medication": Pill,
  "Adherence": CheckCircle,
  "Side Effects": AlertTriangle,
  "Notes": FileText,
  "Lab Tracking": FlaskConical
};

const componentColors = {
  "Goals": "bg-blue-50 border-blue-200 text-blue-800",
  "Lifestyle": "bg-green-50 border-green-200 text-green-800",
  "Diet": "bg-orange-50 border-orange-200 text-orange-800",
  "Vitals": "bg-purple-50 border-purple-200 text-purple-800",
  "Diagnostic": "bg-indigo-50 border-indigo-200 text-indigo-800",
  "Medication": "bg-pink-50 border-pink-200 text-pink-800",
  "Adherence": "bg-teal-50 border-teal-200 text-teal-800",
  "Side Effects": "bg-red-50 border-red-200 text-red-800",
  "Notes": "bg-slate-50 border-slate-200 text-slate-800",
  "Lab Tracking": "bg-cyan-50 border-cyan-200 text-cyan-800"
};

export default function ConditionPlanBuilder({ patient, plan, onSave, onCancel }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [condition, setCondition] = useState(null);
  const [conditionQuery, setConditionQuery] = useState("");
  const [planName, setPlanName] = useState('');
  const [generatedComponents, setGeneratedComponents] = useState([]);
  const [customizations, setCustomizations] = useState('');
  const [generating, setGenerating] = useState(false);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState('condition');

  useEffect(() => {
    const loadUser = async () => {
      try {
        const user = await User.me();
        setCurrentUser(user);
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();

    if (plan) {
      // Editing existing plan
      const existingCondition = { code: plan.condition_icd10_code, description: plan.condition_description };
      setCondition(existingCondition);
      setConditionQuery(plan.condition_description);
      setPlanName(plan.plan_name);
      setGeneratedComponents(plan.generated_components || []);
      setCustomizations(plan.customizations || '');
      setActiveTab(plan.generated_components?.length > 0 ? 'components' : 'condition');
    } else if (patient && patient.primary_condition) {
      // Creating new plan for a patient with a known condition
      setCondition(patient.primary_condition);
      setConditionQuery(patient.primary_condition.description);
      setPlanName(`${patient.primary_condition.description} Management Plan`);
    }
  }, [patient, plan]);

  const generatePlan = async () => {
    if (!condition || !currentUser) return;
    
    setGenerating(true);
    setGeneratedComponents([]);

    try {
      const patientAge = patient && patient.date_of_birth ? 
        new Date().getFullYear() - new Date(patient.date_of_birth).getFullYear() : 
        'Not specified';
      
      const patientGender = patient?.gender || 'Not specified';

      const prompt = `You are an expert clinical decision support system. Create a comprehensive management plan for a patient with ${condition.description} (ICD-10: ${condition.code}).

      Patient Details:
      - Age: ${patientAge}
      - Gender: ${patientGender}

      Generate a modular management plan with components from these categories: Goals, Lifestyle, Diet, Vitals, Diagnostic, Medication, Adherence, Side Effects, Notes, Lab Tracking.

      For each component, provide: a clear title, detailed content, a priority (High, Medium, or Low), a suggested frequency, and specific target_values where applicable.`;

      const response = await InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            components: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  component_type: { type: "string", enum: ["Goals", "Lifestyle", "Diet", "Vitals", "Diagnostic", "Medication", "Adherence", "Side Effects", "Notes", "Lab Tracking"] },
                  title: { type: "string" },
                  content: { type: "string" },
                  priority: { type: "string", enum: ["High", "Medium", "Low"] },
                  frequency: { type: "string" },
                  target_values: { type: "object" },
                },
                required: ["component_type", "title", "content", "priority"]
              }
            }
          },
          required: ["components"]
        }
      });

      if (response && response.components) {
        const componentsWithSelection = response.components.map(comp => ({
          ...comp,
          selected: true
        }));
        setGeneratedComponents(componentsWithSelection);
        setActiveTab('components');
      }
    } catch (error) {
      console.error("Error generating plan:", error);
      // Display error to user
    }
    setGenerating(false);
  };

  const toggleComponent = (index) => {
    setGeneratedComponents(prev => 
      prev.map((comp, i) => 
        i === index ? { ...comp, selected: !comp.selected } : comp
      )
    );
  };

  const updateComponent = (index, field, value) => {
    setGeneratedComponents(prev => 
      prev.map((comp, i) => 
        i === index ? { ...comp, [field]: value } : comp
      )
    );
  };

  const savePlan = async () => {
    if (!condition || !planName || !currentUser || !patient) return;
    
    setSaving(true);
    try {
      const planData = {
        patient_id: patient.id,
        condition_icd10_code: condition.code,
        condition_description: condition.description,
        plan_name: planName,
        generated_components: generatedComponents.filter(c => c.selected),
        customizations,
        created_by: currentUser.email,
        status: plan ? plan.status : 'Draft',
        // Preserve original dates if editing
        implementation_date: plan?.implementation_date || new Date().toISOString().split('T')[0],
        review_date: plan?.review_date || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      };

      if (plan) {
        await ConditionPlan.update(plan.id, planData);
      } else {
        await ConditionPlan.create(planData);
      }
      onSave();
    } catch (error) {
      console.error("Error saving plan:", error);
      // Show error to user
    }
    setSaving(false);
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'High': return 'bg-red-100 text-red-800 border-red-200';
      case 'Medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const selectedComponentsCount = generatedComponents.filter(c => c.selected).length;

  // Early return if patient is null
  if (!patient) {
    return (
      <Dialog open={true} onOpenChange={onCancel}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-slate-900">Error</DialogTitle>
          </DialogHeader>
          <div className="p-6 text-center">
            <p className="text-slate-600">No patient selected. Please select a patient first.</p>
            <Button onClick={onCancel} className="mt-4">
              Close
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="sm:max-w-5xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-slate-900 flex items-center gap-2">
            <Brain className="w-6 h-6 text-purple-600" />
            {plan ? 'Edit Condition Plan' : 'AI Condition Plan Builder'}
          </DialogTitle>
          <p className="text-slate-600">
            {plan ? `Editing plan for ${patient.first_name} ${patient.last_name}` : `Create a management plan for ${patient.first_name} ${patient.last_name}`}
          </p>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="condition">1. Define Condition</TabsTrigger>
            <TabsTrigger value="components" disabled={!generatedComponents.length}>
              2. Review Components ({selectedComponentsCount})
            </TabsTrigger>
            <TabsTrigger value="finalize" disabled={!generatedComponents.length}>
              3. Finalize Plan
            </TabsTrigger>
          </TabsList>

          <TabsContent value="condition" className="space-y-6 mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Step 1: Define the Condition</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                 <div className="space-y-2">
                  <Label htmlFor="condition_query">Condition / Diagnosis</Label>
                  <Input
                    id="condition_query"
                    value={conditionQuery}
                    onChange={(e) => setConditionQuery(e.target.value)}
                    placeholder="e.g., Type 2 Diabetes, Hypertension"
                  />
                  <p className="text-xs text-slate-500">Type a condition to get AI-powered ICD-10 suggestions below.</p>
                </div>
                <div className="space-y-2">
                  <Label>Condition Code (ICD-10)</Label>
                  <ICD10CodeSelector
                    value={condition}
                    onSelect={setCondition}
                    contextualText={conditionQuery}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Plan Name</Label>
                  <Input
                    value={planName}
                    onChange={(e) => setPlanName(e.target.value)}
                    placeholder="e.g., Type 2 Diabetes Management Plan"
                  />
                </div>

                <Button
                  onClick={generatePlan}
                  disabled={!condition || !planName || generating}
                  className="w-full bg-purple-600 hover:bg-purple-700"
                  size="lg"
                >
                  {generating ? (
                    <><Loader2 className="w-5 h-5 mr-2 animate-spin" /> Generating Plan...</>
                  ) : (
                    <><Sparkles className="w-5 h-5 mr-2" /> Generate AI-Powered Plan</>
                  )}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="components" className="space-y-6 mt-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-slate-900">
                Generated Plan Components
              </h3>
              <Badge variant="outline" className="bg-purple-50 text-purple-700">
                {selectedComponentsCount} of {generatedComponents.length} selected
              </Badge>
            </div>

            <div className="grid gap-4">
              {generatedComponents.map((component, index) => {
                const Icon = componentIcons[component.component_type];
                return (
                  <Card 
                    key={index} 
                    className={`transition-all duration-200 ${
                      component.selected 
                        ? 'ring-2 ring-purple-200 bg-purple-50/30' 
                        : 'opacity-60'
                    }`}
                  >
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3">
                          <Checkbox
                            checked={component.selected}
                            onCheckedChange={() => toggleComponent(index)}
                          />
                          <div className={`p-2 rounded-lg ${componentColors[component.component_type]}`}>
                            {Icon && <Icon className="w-4 h-4" />}
                          </div>
                          <div>
                            <CardTitle className="text-base">{component.title}</CardTitle>
                            <div className="flex items-center gap-2 mt-1">
                              <Badge variant="outline" className={getPriorityColor(component.priority)}>
                                {component.priority}
                              </Badge>
                              {component.frequency && (
                                <Badge variant="secondary" className="text-xs">
                                  {component.frequency}
                                </Badge>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <Textarea
                        value={component.content}
                        onChange={(e) => updateComponent(index, 'content', e.target.value)}
                        className="min-h-[80px]"
                        disabled={!component.selected}
                      />
                      {component.target_values && Object.keys(component.target_values).length > 0 && (
                        <div className="mt-3 p-3 bg-slate-50 rounded-lg">
                          <p className="text-sm font-medium text-slate-700 mb-2">Target Values:</p>
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            {Object.entries(component.target_values).map(([key, value]) => (
                              <div key={key} className="flex justify-between">
                                <span className="text-slate-600">{key}:</span>
                                <span className="font-medium">{String(value)}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {generatedComponents.length > 0 && (
              <div className="flex justify-end">
                <Button
                  onClick={() => setActiveTab('finalize')}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  Continue to Finalize
                </Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="finalize" className="space-y-6 mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Step 3: Finalize Your Plan</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Additional Customizations (Optional)</Label>
                  <Textarea
                    value={customizations}
                    onChange={(e) => setCustomizations(e.target.value)}
                    placeholder="Add any specific notes, modifications, or special considerations for this patient..."
                    rows={4}
                  />
                </div>

                <div className="bg-slate-50 p-4 rounded-lg">
                  <h4 className="font-medium text-slate-900 mb-3">Plan Summary</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-slate-600">Patient:</span>
                      <span className="font-medium ml-2">{patient.first_name} {patient.last_name}</span>
                    </div>
                    <div>
                      <span className="text-slate-600">Condition:</span>
                      <span className="font-medium ml-2">{condition?.description}</span>
                    </div>
                    <div>
                      <span className="text-slate-600">Components:</span>
                      <span className="font-medium ml-2">{selectedComponentsCount} selected</span>
                    </div>
                    <div>
                      <span className="text-slate-600">Plan Name:</span>
                      <span className="font-medium ml-2">{planName}</span>
                    </div>
                  </div>
                </div>

                <div className="flex justify-between pt-6">
                  <Button variant="outline" onClick={onCancel}>
                    Cancel
                  </Button>
                  <Button
                    onClick={savePlan}
                    disabled={saving || selectedComponentsCount === 0}
                    className="bg-purple-600 hover:bg-purple-700"
                  >
                    {saving ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Saving Plan...
                      </>
                    ) : (
                      plan ? 'Update Management Plan' : 'Create Management Plan'
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
