import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ConditionPlan } from "@/api/entities";
import { Plus, Brain, Calendar, User, FileText } from 'lucide-react';
import { format } from 'date-fns';
import ConditionPlanBuilder from './ConditionPlanBuilder';

export default function PatientPlansView({ patient }) {
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showPlanBuilder, setShowPlanBuilder] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState(null);

  useEffect(() => {
    loadPlans();
  }, [patient.id]);

  const loadPlans = async () => {
    setLoading(true);
    try {
      const plansData = await ConditionPlan.filter({ patient_id: patient.id }, "-created_date");
      setPlans(plansData);
    } catch (error) {
      console.error("Error loading patient plans:", error);
    }
    setLoading(false);
  };

  const handleCreatePlan = () => {
    setSelectedPlan(null);
    setShowPlanBuilder(true);
  };

  const handleEditPlan = (plan) => {
    setSelectedPlan(plan);
    setShowPlanBuilder(true);
  };

  const handleSavePlan = async () => {
    await loadPlans();
    setShowPlanBuilder(false);
    setSelectedPlan(null);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Active':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Draft':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Completed':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Paused':
        return 'bg-gray-100 text-gray-800 border-gray-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  if (loading) {
    return (
      <Card className="border-slate-200">
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <div className="text-center">
              <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-4"></div>
              <p className="text-slate-600">Loading management plans...</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold text-slate-900">Condition Management Plans</h3>
          <p className="text-slate-600">AI-powered personalized care plans for {patient.first_name}</p>
        </div>
        <Button onClick={handleCreatePlan} className="bg-blue-600 hover:bg-blue-700">
          <Plus className="w-4 h-4 mr-2" />
          Create New Plan
        </Button>
      </div>

      {plans.length > 0 ? (
        <div className="grid gap-4">
          {plans.map((plan) => (
            <Card key={plan.id} className="border-slate-200 hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-xl font-semibold text-slate-900">
                      {plan.plan_name}
                    </CardTitle>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge variant="outline" className={getStatusColor(plan.status)}>
                        {plan.status}
                      </Badge>
                      <Badge variant="secondary">
                        {plan.condition_icd10_code} - {plan.condition_description}
                      </Badge>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEditPlan(plan)}
                  >
                    View Details
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-slate-400" />
                    <span className="text-slate-600">Created by:</span>
                    <span className="font-medium">{plan.created_by}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-slate-400" />
                    <span className="text-slate-600">Implementation:</span>
                    <span className="font-medium">
                      {plan.implementation_date ? format(new Date(plan.implementation_date), 'MMM d, yyyy') : 'Not set'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-slate-400" />
                    <span className="text-slate-600">Components:</span>
                    <span className="font-medium">{plan.generated_components?.length || 0}</span>
                  </div>
                </div>
                
                {plan.customizations && (
                  <div className="mt-4 p-3 bg-slate-50 rounded-lg">
                    <p className="text-sm text-slate-700">
                      <strong>Customizations:</strong> {plan.customizations}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="border-slate-200">
          <CardContent className="p-8 text-center">
            <Brain className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-slate-900 mb-2">No Management Plans Yet</h3>
            <p className="text-slate-600 mb-4">
              Create an AI-powered condition management plan tailored to {patient.first_name}'s specific needs.
            </p>
            <Button onClick={handleCreatePlan} className="bg-blue-600 hover:bg-blue-700">
              <Brain className="w-4 h-4 mr-2" />
              Create First Plan
            </Button>
          </CardContent>
        </Card>
      )}

      {showPlanBuilder && (
        <ConditionPlanBuilder
          patient={patient}
          plan={selectedPlan}
          onSave={handleSavePlan}
          onCancel={() => {
            setShowPlanBuilder(false);
            setSelectedPlan(null);
          }}
        />
      )}
    </div>
  );
}