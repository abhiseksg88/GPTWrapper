
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Lightbulb, AlertTriangle, FileText, DollarSign } from 'lucide-react';

export default function BillingAnalysisReport({ analysis, patient, selectedIcdCodes, onSelectionChange }) {
  if (!analysis) return null;

  const handleIcdSelection = (code, isChecked) => {
    if (isChecked) {
      onSelectionChange([...selectedIcdCodes, code]);
    } else {
      onSelectionChange(selectedIcdCodes.filter(c => c.code !== code.code));
    }
  };

  const isCodeSelected = (code) => {
    return selectedIcdCodes.some(c => c.code === code.code);
  };

  return (
    <Card className="shadow-lg border-slate-200 animate-in fade-in-50">
      <CardHeader>
        <div className="flex justify-between items-start">
            <div>
                <CardTitle className="text-2xl font-bold text-slate-900">AI-Powered Reimbursement Analysis Report</CardTitle>
                <p className="text-slate-600">For {patient.first_name} {patient.last_name}</p>
            </div>
            <div className="text-right">
                <p className="text-lg font-semibold text-green-600 flex items-center gap-2 justify-end">
                    <DollarSign className="w-5 h-5" />
                    {analysis.total_estimated_earnings}
                </p>
                <p className="text-sm text-slate-500">Total Estimated Earnings</p>
            </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-8">
        <div>
          <h3 className="text-lg font-semibold text-slate-800 mb-3 flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-600" />
            Suggested CPT Codes
          </h3>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>CPT Code</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Units</TableHead>
                  <TableHead>Est. Reimbursement</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {analysis.suggested_cpt.map((cpt, index) => (
                  <React.Fragment key={index}>
                    <TableRow>
                      <TableCell><Badge variant="outline">{cpt.code}</Badge></TableCell>
                      <TableCell className="font-medium text-slate-800">{cpt.description}</TableCell>
                      <TableCell>{cpt.units}</TableCell>
                      <TableCell className="font-semibold text-green-700">{cpt.estimated_reimbursement}</TableCell>
                    </TableRow>
                    <TableRow>
                        <TableCell colSpan={4} className="py-2 px-6 bg-slate-50">
                            <p className="text-xs text-slate-600 flex items-start gap-2">
                                <Lightbulb className="w-3 h-3 mt-0.5 flex-shrink-0" />
                                <strong>Rationale:</strong> {cpt.rationale}
                            </p>
                        </TableCell>
                    </TableRow>
                  </React.Fragment>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
                <h3 className="text-lg font-semibold text-slate-800 mb-3 flex items-center gap-2">
                    <FileText className="w-5 h-5 text-blue-600" />
                    Suggested & Confirmed ICD-10 Codes
                </h3>
                <p className="text-sm text-slate-500 mb-4">Review the AI suggestions and check the codes you want to confirm for this analysis.</p>
                <div className="space-y-2 max-h-60 overflow-y-auto pr-2">
                    {(analysis.suggested_icd10 || []).map((icd, index) => (
                      <div key={index} className="flex items-center gap-3 p-3 bg-slate-50 rounded-md border border-transparent has-[:checked]:bg-blue-50 has-[:checked]:border-blue-200 transition-colors">
                        <Checkbox
                          id={`icd-${icd.code}`}
                          checked={isCodeSelected(icd)}
                          onCheckedChange={(checked) => handleIcdSelection(icd, checked)}
                          className="w-5 h-5"
                        />
                        <label htmlFor={`icd-${icd.code}`} className="flex-1 cursor-pointer">
                          <Badge className="mr-2">{icd.code}</Badge>
                          <span className="text-sm text-slate-700">{icd.description}</span>
                        </label>
                      </div>
                    ))}
                </div>
            </div>
            <div>
                <h3 className="text-lg font-semibold text-slate-800 mb-3">Summary & Notes</h3>
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="text-sm text-blue-800">{analysis.summary_notes}</p>
                </div>
            </div>
        </div>

      </CardContent>
      <CardFooter>
        <div className="w-full p-3 bg-amber-50 border-l-4 border-amber-400 rounded-r-md">
            <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-600 mt-0.5"/>
                <div>
                    <h4 className="font-semibold text-amber-800">Disclaimer</h4>
                    <p className="text-sm text-amber-700">This report is generated by an AI assistant and is intended for estimation and informational purposes only. All codes and reimbursement figures should be verified by a qualified human billing specialist before submission.</p>
                </div>
            </div>
        </div>
      </CardFooter>
    </Card>
  );
}
