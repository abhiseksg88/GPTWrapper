
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Eye, Calendar, DollarSign, FileText, ChevronDown, ChevronRight } from 'lucide-react';
import { format } from 'date-fns';
import { useState } from 'react';

export default function SavedAnalysesList({ analyses, patient, onLoadAnalysis }) {
  const [expandedRows, setExpandedRows] = useState(new Set());

  const getStatusColor = (status) => {
    switch (status) {
      case 'Draft':
        return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'Reviewed':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Submitted':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Processed':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const handleLoadAnalysis = (savedAnalysis) => {
    // The parent component now expects the full saved analysis object
    onLoadAnalysis(savedAnalysis);
  };

  const toggleRowExpansion = (analysisId) => {
    const newExpanded = new Set(expandedRows);
    if (newExpanded.has(analysisId)) {
      newExpanded.delete(analysisId);
    } else {
      newExpanded.add(analysisId);
    }
    setExpandedRows(newExpanded);
  };

  return (
    <Card className="border-slate-200">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="w-5 h-5 text-blue-600" />
          Previously Saved Reimbursement Analysis for {patient.first_name} {patient.last_name}
          <Badge variant="secondary" className="ml-auto">
            {analyses.length} saved
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {analyses.length > 0 ? (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-slate-50">
                  <TableHead className="w-8"></TableHead>
                  <TableHead>Analysis Date</TableHead>
                  <TableHead>Period Analyzed</TableHead>
                  <TableHead>Estimated Earnings</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Analyzed By</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {analyses.map((analysis) => (
                  <React.Fragment key={analysis.id}>
                    <TableRow className="hover:bg-slate-50">
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleRowExpansion(analysis.id)}
                          className="p-1"
                        >
                          {expandedRows.has(analysis.id) ? (
                            <ChevronDown className="w-4 h-4" />
                          ) : (
                            <ChevronRight className="w-4 h-4" />
                          )}
                        </Button>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-slate-400" />
                          {format(new Date(analysis.analysis_date), "MMM d, yyyy")}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <div>{format(new Date(analysis.date_range_from), "MMM d")} - </div>
                          <div>{format(new Date(analysis.date_range_to), "MMM d, yyyy")}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1 font-semibold text-green-600">
                          <DollarSign className="w-4 h-4" />
                          {analysis.total_estimated_earnings}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant="outline" 
                          className={`${getStatusColor(analysis.status)} border`}
                        >
                          {analysis.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-slate-600">
                        {analysis.analyzed_by}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleLoadAnalysis(analysis)} // Updated onClick handler
                          className="flex items-center gap-1"
                        >
                          <Eye className="w-3 h-3" />
                          View Details
                        </Button>
                      </TableCell>
                    </TableRow>
                    
                    {expandedRows.has(analysis.id) && (
                      <TableRow>
                        <TableCell colSpan={7} className="bg-slate-50 border-t">
                          <div className="p-4 space-y-4">
                            {/* Summary Notes */}
                            <div>
                              <h4 className="font-semibold text-slate-900 mb-2">Summary Notes</h4>
                              <p className="text-sm text-slate-700 bg-white p-3 rounded border">
                                {analysis.summary_notes}
                              </p>
                            </div>
                            
                            {/* ICD-10 Codes (showing confirmed vs suggested) */}
                            <div>
                              <h4 className="font-semibold text-slate-900 mb-2">
                                ICD-10 Codes
                              </h4>
                              <div className="flex flex-wrap gap-2">
                                {analysis.confirmed_icd10?.length > 0 ? (
                                  analysis.confirmed_icd10.map((icd, index) => (
                                    <div key={index} className="bg-blue-100 border border-blue-200 rounded px-3 py-2 text-sm text-blue-800">
                                      <Badge variant="default" className="mr-2">{icd.code}</Badge>
                                      {icd.description} (Confirmed)
                                    </div>
                                  ))
                                ) : (
                                  analysis.suggested_icd10?.map((icd, index) => (
                                      <div key={index} className="bg-white border rounded px-3 py-2 text-sm">
                                        <Badge variant="outline" className="mr-2">{icd.code}</Badge>
                                        {icd.description} (Suggested)
                                      </div>
                                  )) || <span className="text-slate-500 text-sm">No ICD-10 codes</span>
                                )}
                              </div>
                            </div>
                            
                            {/* CPT Codes */}
                            <div>
                              <h4 className="font-semibold text-slate-900 mb-2">
                                CPT Codes ({analysis.suggested_cpt?.length || 0})
                              </h4>
                              <div className="space-y-2">
                                {analysis.suggested_cpt?.map((cpt, index) => (
                                  <div key={index} className="bg-white border rounded p-3 text-sm">
                                    <div className="flex items-center justify-between mb-2">
                                      <div className="flex items-center gap-2">
                                        <Badge variant="outline">{cpt.code}</Badge>
                                        <span className="font-medium">{cpt.description}</span>
                                      </div>
                                      <div className="flex items-center gap-3">
                                        <span className="text-slate-600">Units: {cpt.units}</span>
                                        <span className="font-semibold text-green-600">{cpt.estimated_reimbursement}</span>
                                      </div>
                                    </div>
                                    {cpt.rationale && (
                                      <p className="text-slate-600 text-xs mt-1">
                                        <strong>Rationale:</strong> {cpt.rationale}
                                      </p>
                                    )}
                                  </div>
                                )) || <span className="text-slate-500 text-sm">No CPT codes</span>}
                              </div>
                            </div>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </React.Fragment>
                ))}
              </TableBody>
            </Table>
          </div>
        ) : (
          <div className="text-center py-8">
            <FileText className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-500">No saved analyses found for this patient.</p>
            <p className="text-slate-400 text-sm mt-1">
              Run a new analysis to see reimbursement recommendations.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
