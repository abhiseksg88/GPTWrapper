
import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandInput, CommandEmpty, CommandGroup, CommandItem, CommandList } from "@/components/ui/command";
import { Badge } from "@/components/ui/badge";
import { ICD10Code } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Brain, Loader2, Check, Sparkles, AlertCircle } from 'lucide-react';

export default function ICD10CodeSelector({ value, onSelect, contextualText }) {
  const [open, setOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [allCodes, setAllCodes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState(null);
  const [aiNotes, setAiNotes] = useState(null);

  useEffect(() => {
    const loadAllCodes = async () => {
        setLoading(true);
        try {
            const codes = await ICD10Code.list(null, 1000);
            setAllCodes(codes);
        } catch (error) {
            console.error("Failed to load ICD-10 codes:", error);
        }
        setLoading(false);
    };
    loadAllCodes();
  }, []);

  const handleSearchChange = (term) => {
    setSearchTerm(term);
    setAiError(null);
    setAiNotes(null);
    if (!term) {
        setSearchResults([]);
        return;
    }
    const lowercasedTerm = term.toLowerCase();
    const filtered = allCodes.filter(code =>
        (code.code && code.code.toLowerCase().includes(lowercasedTerm)) ||
        (code.description && code.description.toLowerCase().includes(lowercasedTerm))
    );
    setSearchResults(filtered.slice(0, 10));
  };

  const handleAIRequest = async (e) => {
    e.stopPropagation();
    if (!contextualText || contextualText.trim().length < 3) {
      setAiError("Please enter a longer clinical term to get AI suggestions.");
      return;
    }
    
    setAiLoading(true);
    setAiError(null);
    setAiNotes(null);
    setSearchTerm("");
    setSearchResults([]);
    
    try {
      const prompt = `The user has entered the following term for an ICD-10 lookup: '${contextualText}'.

As an intelligent medical coding assistant, your task is to:
1. Search for all ICD-10 codes that are semantically or clinically related to the input keyword.
2. List the top 5 matching ICD-10 codes with their full descriptions.
3. For each code, provide a relevance score as a string: "High", "Medium", or "Low".
4. If the input is ambiguous or could relate to multiple diagnoses, provide a brief explanation in a 'notes' field.

Your response MUST be a valid JSON object with a key "suggestions", which is an array of objects. Each object must have "code", "description", and "relevance" keys. You may optionally include a top-level "notes" key if the term is ambiguous.
Example for 'Low back pain':
{
  "suggestions": [
    { "code": "M54.5", "description": "Low back pain", "relevance": "High" },
    { "code": "S39.012A", "description": "Strain of muscle, fascia and tendon of lower back, initial encounter", "relevance": "Medium" }
  ],
  "notes": "Consider if the pain is due to injury or is chronic."
}`;
      
      const response = await InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            suggestions: {
              type: "array",
              items: {
                type: "object",
                properties: { 
                  code: { type: "string" }, 
                  description: { type: "string" },
                  relevance: { type: "string", enum: ["High", "Medium", "Low"] }
                },
                required: ["code", "description", "relevance"]
              }
            },
            notes: { type: "string" }
          },
          required: ["suggestions"]
        }
      });
      
      if (response && response.suggestions && Array.isArray(response.suggestions)) {
        setSearchResults(response.suggestions);
        setSearchTerm(`AI suggestions for: ${contextualText}`);
        if (response.notes) {
          setAiNotes(response.notes);
        }
      } else {
        setAiError("AI returned an unexpected response format.");
      }
    } catch (error) {
      console.error("Error getting AI suggestions for ICD-10:", error);
      setAiError("AI suggestion request failed. Please check your connection.");
      setSearchResults([]);
    }
    setAiLoading(false);
  };

  const handleSelect = (code) => {
    onSelect(code);
    setOpen(false);
    setSearchTerm("");
    setSearchResults([]);
    setAiError(null);
    setAiNotes(null);
  };

  const getRelevanceClass = (relevance) => {
    switch (relevance) {
      case 'High': return 'bg-red-100 text-red-800 border-red-200';
      case 'Medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Low': return 'bg-slate-100 text-slate-800 border-slate-200';
      default: return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const displayValue = value ? `${value.code} - ${value.description}` : "Select ICD-10 code...";

  return (
    <Popover open={open} onOpenChange={(isOpen) => {
        setOpen(isOpen);
        if (!isOpen) {
            setSearchTerm("");
            setSearchResults([]);
            setAiError(null);
            setAiNotes(null);
        }
    }}>
      <PopoverTrigger asChild>
        <Button variant="outline" role="combobox" aria-expanded={open} className="w-full justify-between">
          <span className="truncate">{displayValue}</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[--radix-popover-trigger-width] p-0" align="start">
        <Command>
          <div className="p-2 border-b">
            <CommandInput
              placeholder="Search by code or description..."
              onValueChange={handleSearchChange}
              value={searchTerm}
            />
          </div>

          {contextualText && (
            <div className="p-2 border-b">
                <Button onClick={handleAIRequest} size="sm" className="w-full" disabled={aiLoading || !contextualText || contextualText.trim().length < 3}>
                  {aiLoading ? (
                      <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Fetching AI Suggestions...</>
                  ) : (
                      <><Sparkles className="w-4 h-4 mr-2" /> Get AI Suggestions for "{contextualText}"</>
                  )}
                </Button>
            </div>
          )}
          
          {aiError && (
            <div className="p-2 text-sm text-red-700 bg-red-50 flex items-center gap-2">
              <AlertCircle className="w-4 h-4" /> {aiError}
            </div>
          )}

          {aiNotes && (
            <div className="p-2 text-sm text-amber-800 bg-amber-50 border-y">
              <strong className="flex items-center gap-1"><Brain className="w-3 h-3"/>AI Note:</strong> {aiNotes}
            </div>
          )}

          <CommandList>
            {loading && <CommandEmpty>Loading codes...</CommandEmpty>}
            {!loading && searchResults.length === 0 && searchTerm !== "" && <CommandEmpty>No results found.</CommandEmpty>}
            <CommandGroup>
              {searchResults.map((result, index) => (
                <CommandItem
                  key={index}
                  onSelect={() => handleSelect(result)}
                  className="flex justify-between items-center"
                >
                  <div className="flex-1 overflow-hidden">
                    <p className="font-semibold">{result.code}</p>
                    <p className="text-xs text-slate-600 truncate">{result.description}</p>
                  </div>
                  {result.relevance && (
                    <Badge variant="outline" className={`ml-2 flex-shrink-0 ${getRelevanceClass(result.relevance)}`}>
                      {result.relevance}
                    </Badge>
                  )}
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}
