import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { NutritionPlan } from "@/api/entities";
import { X } from "lucide-react";

export default function NutritionModal({ patient, lifestylePlanId, onSave, onCancel }) {
  const [formData, setFormData] = useState({
    meal_type: '',
    title: '',
    description: '',
    calories_target: '',
    protein_grams: '',
    carbs_grams: '',
    fat_grams: '',
    portion_guidelines: '',
    timing_notes: ''
  });
  const [foodSuggestions, setFoodSuggestions] = useState([]);
  const [foodsToAvoid, setFoodsToAvoid] = useState([]);
  const [newFoodSuggestion, setNewFoodSuggestion] = useState('');
  const [newFoodToAvoid, setNewFoodToAvoid] = useState('');
  const [loading, setLoading] = useState(false);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const addFoodSuggestion = () => {
    if (newFoodSuggestion.trim()) {
      setFoodSuggestions(prev => [...prev, newFoodSuggestion.trim()]);
      setNewFoodSuggestion('');
    }
  };

  const removeFoodSuggestion = (index) => {
    setFoodSuggestions(prev => prev.filter((_, i) => i !== index));
  };

  const addFoodToAvoid = () => {
    if (newFoodToAvoid.trim()) {
      setFoodsToAvoid(prev => [...prev, newFoodToAvoid.trim()]);
      setNewFoodToAvoid('');
    }
  };

  const removeFoodToAvoid = (index) => {
    setFoodsToAvoid(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!lifestylePlanId) {
      console.error("No lifestyle plan ID provided");
      return;
    }

    setLoading(true);
    
    try {
      const nutritionData = {
        lifestyle_plan_id: lifestylePlanId,
        patient_id: patient.id,
        meal_type: formData.meal_type,
        title: formData.title,
        description: formData.description,
        calories_target: formData.calories_target ? parseFloat(formData.calories_target) : null,
        protein_grams: formData.protein_grams ? parseFloat(formData.protein_grams) : null,
        carbs_grams: formData.carbs_grams ? parseFloat(formData.carbs_grams) : null,
        fat_grams: formData.fat_grams ? parseFloat(formData.fat_grams) : null,
        food_suggestions: foodSuggestions,
        foods_to_avoid: foodsToAvoid,
        portion_guidelines: formData.portion_guidelines,
        timing_notes: formData.timing_notes
      };
      
      await NutritionPlan.create(nutritionData);
      onSave();
    } catch (error) {
      console.error("Error creating nutrition plan:", error);
    }
    
    setLoading(false);
  };

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold text-slate-900">
            Add Nutrition Plan for {patient.first_name} {patient.last_name}
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="meal_type">Meal Type *</Label>
              <Select
                value={formData.meal_type}
                onValueChange={(value) => handleInputChange('meal_type', value)}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select meal type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Breakfast">Breakfast</SelectItem>
                  <SelectItem value="Lunch">Lunch</SelectItem>
                  <SelectItem value="Dinner">Dinner</SelectItem>
                  <SelectItem value="Snack">Snack</SelectItem>
                  <SelectItem value="General Guidelines">General Guidelines</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="title">Plan Title *</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => handleInputChange('title', e.target.value)}
                placeholder="e.g., High Protein Breakfast Plan"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              placeholder="Detailed nutrition guidelines and instructions..."
              rows={3}
            />
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label htmlFor="calories_target">Calories</Label>
              <Input
                id="calories_target"
                type="number"
                value={formData.calories_target}
                onChange={(e) => handleInputChange('calories_target', e.target.value)}
                placeholder="400"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="protein_grams">Protein (g)</Label>
              <Input
                id="protein_grams"
                type="number"
                step="0.1"
                value={formData.protein_grams}
                onChange={(e) => handleInputChange('protein_grams', e.target.value)}
                placeholder="25"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="carbs_grams">Carbs (g)</Label>
              <Input
                id="carbs_grams"
                type="number"
                step="0.1"
                value={formData.carbs_grams}
                onChange={(e) => handleInputChange('carbs_grams', e.target.value)}
                placeholder="30"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="fat_grams">Fat (g)</Label>
              <Input
                id="fat_grams"
                type="number"
                step="0.1"
                value={formData.fat_grams}
                onChange={(e) => handleInputChange('fat_grams', e.target.value)}
                placeholder="15"
              />
            </div>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Food Suggestions</Label>
              <div className="flex gap-2">
                <Input
                  value={newFoodSuggestion}
                  onChange={(e) => setNewFoodSuggestion(e.target.value)}
                  placeholder="Add recommended food..."
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addFoodSuggestion())}
                />
                <Button type="button" onClick={addFoodSuggestion} variant="outline">
                  Add
                </Button>
              </div>
              <div className="flex flex-wrap gap-2 mt-2">
                {foodSuggestions.map((food, index) => (
                  <Badge key={index} variant="secondary" className="bg-green-100 text-green-800">
                    {food}
                    <button
                      type="button"
                      onClick={() => removeFoodSuggestion(index)}
                      className="ml-1 hover:text-green-600"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label>Foods to Avoid</Label>
              <div className="flex gap-2">
                <Input
                  value={newFoodToAvoid}
                  onChange={(e) => setNewFoodToAvoid(e.target.value)}
                  placeholder="Add food to avoid..."
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addFoodToAvoid())}
                />
                <Button type="button" onClick={addFoodToAvoid} variant="outline">
                  Add
                </Button>
              </div>
              <div className="flex flex-wrap gap-2 mt-2">
                {foodsToAvoid.map((food, index) => (
                  <Badge key={index} variant="secondary" className="bg-red-100 text-red-800">
                    {food}
                    <button
                      type="button"
                      onClick={() => removeFoodToAvoid(index)}
                      className="ml-1 hover:text-red-600"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="portion_guidelines">Portion Guidelines</Label>
              <Textarea
                id="portion_guidelines"
                value={formData.portion_guidelines}
                onChange={(e) => handleInputChange('portion_guidelines', e.target.value)}
                placeholder="e.g., 1 palm-sized portion of protein, 1 cup of vegetables..."
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="timing_notes">Timing Notes</Label>
              <Textarea
                id="timing_notes"
                value={formData.timing_notes}
                onChange={(e) => handleInputChange('timing_notes', e.target.value)}
                placeholder="e.g., Eat within 1 hour of waking, avoid eating 3 hours before bed..."
                rows={3}
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-6">
            <Button
              type="button"
              variant="outline"
              onClick={onCancel}
              disabled={loading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={loading || !formData.meal_type || !formData.title}
              className="bg-green-600 hover:bg-green-700"
            >
              {loading ? "Creating..." : "Create Nutrition Plan"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}