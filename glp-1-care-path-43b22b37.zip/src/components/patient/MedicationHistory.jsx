import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Prescription } from "@/api/entities";
import { Pill, Calendar, User, AlertCircle } from "lucide-react";
import { format } from "date-fns";

export default function MedicationHistory({ patientId }) {
  const [prescriptions, setPrescriptions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPrescriptions();
  }, [patientId]);

  const loadPrescriptions = async () => {
    try {
      const data = await Prescription.filter({ patient_id: patientId }, "-start_date");
      setPrescriptions(data);
    } catch (error) {
      console.error("Error loading prescriptions:", error);
      // Generate sample data
      const samplePrescriptions = generateSamplePrescriptions();
      setPrescriptions(samplePrescriptions);
    }
    setLoading(false);
  };

  const generateSamplePrescriptions = () => {
    return [
      {
        id: '1',
        medication_name: 'Semaglutide',
        dosage: '1.0mg',
        frequency: 'Once weekly',
        start_date: '2024-01-15',
        status: 'Active',
        prescribing_clinician: 'dr.smith@clinic.com',
        instructions: 'Inject subcutaneously, rotate injection sites',
        refills_remaining: 3
      },
      {
        id: '2',
        medication_name: 'Semaglutide',
        dosage: '0.5mg',
        frequency: 'Once weekly',
        start_date: '2023-11-01',
        end_date: '2024-01-14',
        status: 'Completed',
        prescribing_clinician: 'dr.smith@clinic.com',
        instructions: 'Initial dosage for titration period',
        refills_remaining: 0
      }
    ];
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Active':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Discontinued':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'Paused':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Completed':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Loading medication history...</CardTitle>
        </CardHeader>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Pill className="w-5 h-5 text-blue-600" />
            Prescription History
          </CardTitle>
        </CardHeader>
        <CardContent>
          {prescriptions.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-slate-50">
                    <TableHead>Medication</TableHead>
                    <TableHead>Dosage & Frequency</TableHead>
                    <TableHead>Start Date</TableHead>
                    <TableHead>End Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Prescriber</TableHead>
                    <TableHead>Refills</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {prescriptions.map((prescription) => (
                    <TableRow key={prescription.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium text-slate-900">{prescription.medication_name}</p>
                          {prescription.instructions && (
                            <p className="text-sm text-slate-500 mt-1">{prescription.instructions}</p>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="font-medium">{prescription.dosage}</p>
                          <p className="text-sm text-slate-500">{prescription.frequency}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        {format(new Date(prescription.start_date), "MMM d, yyyy")}
                      </TableCell>
                      <TableCell>
                        {prescription.end_date 
                          ? format(new Date(prescription.end_date), "MMM d, yyyy")
                          : 'Ongoing'
                        }
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant="outline" 
                          className={`${getStatusColor(prescription.status)} border`}
                        >
                          {prescription.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-slate-600">
                        {prescription.prescribing_clinician}
                      </TableCell>
                      <TableCell>
                        <span className={prescription.refills_remaining === 0 ? 'text-red-600 font-medium' : ''}>
                          {prescription.refills_remaining}
                        </span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8">
              <Pill className="w-12 h-12 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-500">No prescriptions found for this patient.</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Active Prescriptions Summary */}
      {prescriptions.filter(p => p.status === 'Active').length > 0 && (
        <Card className="border-slate-200">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-slate-900">Active Prescriptions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {prescriptions
                .filter(p => p.status === 'Active')
                .map((prescription) => (
                  <div 
                    key={prescription.id}
                    className="flex items-center justify-between p-4 bg-green-50 rounded-lg border border-green-200"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                        <Pill className="w-5 h-5 text-green-600" />
                      </div>
                      <div>
                        <p className="font-medium text-slate-900">
                          {prescription.medication_name} - {prescription.dosage}
                        </p>
                        <p className="text-sm text-slate-600">{prescription.frequency}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-slate-900">
                        {prescription.refills_remaining} refills left
                      </p>
                      <p className="text-sm text-slate-500">
                        Started {format(new Date(prescription.start_date), "MMM d, yyyy")}
                      </p>
                    </div>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}