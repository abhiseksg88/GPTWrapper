
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Procedure } from "@/api/entities";
import { User } from "@/api/entities";
import { Loader2 } from "lucide-react"; // Added this import
import ICD10CodeSelector from '../shared/ICD10CodeSelector';

export default function ProcedureModal({ patient, procedure, onSave, onCancel }) {
  const [formData, setFormData] = useState({
    procedure_name: procedure?.procedure_name || '',
    category: procedure?.category || '',
    reason: procedure?.reason || '',
    status: procedure?.status || 'Planned',
    scheduled_date: procedure?.scheduled_date || '',
    notes: procedure?.notes || ''
  });
  const [selectedIcd10, setSelectedIcd10] = useState(
    procedure?.icd10_code ? { code: procedure.icd10_code, description: procedure.icd10_description } : null
  );
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const loadUser = async () => {
      try {
        const user = await User.me();
        setCurrentUser(user);
      } catch (error) {
        console.error("Error loading current user:", error);
      }
    };
    loadUser();
  }, []); // Run once on mount to load current user

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!currentUser) return;
    setLoading(true);

    const data = {
      ...formData,
      patient_id: patient.id,
      ordered_by: currentUser.email,
      icd10_code: selectedIcd10?.code || null,
      icd10_description: selectedIcd10?.description || null,
    };

    try {
      if (procedure?.id) {
        await Procedure.update(procedure.id, data);
      } else {
        await Procedure.create(data);
      }
      onSave();
    } catch (error) {
      console.error("Error saving procedure:", error);
    }
    setLoading(false);
  };

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>{procedure ? 'Edit' : 'Schedule'} Procedure</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6 mt-6">
          <div className="space-y-2">
            <Label htmlFor="procedure_name">Procedure Name *</Label>
            <Input
              id="procedure_name"
              value={formData.procedure_name}
              onChange={(e) => handleInputChange('procedure_name', e.target.value)}
              required
              placeholder="e.g., Colonoscopy"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="icd10_code">Associated Diagnosis (ICD-10)</Label>
            <ICD10CodeSelector
              value={selectedIcd10}
              onSelect={setSelectedIcd10}
              contextualText={formData.procedure_name}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="category">Category *</Label>
            <Select value={formData.category} onValueChange={(v) => handleInputChange('category', v)} required>
              <SelectTrigger>
                <SelectValue placeholder="Select a category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Surgical">Surgical</SelectItem>
                <SelectItem value="Non-Surgical">Non-Surgical</SelectItem>
                <SelectItem value="Diagnostic">Diagnostic</SelectItem>
                <SelectItem value="Therapeutic">Therapeutic</SelectItem>
                <SelectItem value="Other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="reason">Reason for Procedure *</Label>
            <Textarea id="reason" value={formData.reason} onChange={(e) => handleInputChange('reason', e.target.value)} required placeholder="e.g., Screening, diagnostic evaluation..." />
          </div>

          <div className="space-y-2">
              <Label htmlFor="scheduled_date">Scheduled Date</Label>
              <Input id="scheduled_date" type="date" value={formData.scheduled_date} onChange={(e) => handleInputChange('scheduled_date', e.target.value)} />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="status">Status</Label>
             <Select value={formData.status} onValueChange={(v) => handleInputChange('status', v)}>
              <SelectTrigger>
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Planned">Planned</SelectItem>
                <SelectItem value="Scheduled">Scheduled</SelectItem>
                <SelectItem value="Completed">Completed</SelectItem>
                <SelectItem value="Cancelled">Cancelled</SelectItem>
                <SelectItem value="Postponed">Postponed</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea id="notes" value={formData.notes} onChange={(e) => handleInputChange('notes', e.target.value)} placeholder="Enter any notes about the procedure, outcome, or follow-up..." />
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onCancel} disabled={loading}>Cancel</Button>
            <Button type="submit" disabled={loading} className="bg-blue-600 hover:bg-blue-700">
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                'Save Procedure'
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
