import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Prescription } from "@/api/entities";
import { User } from "@/api/entities";
import { Loader2 } from "lucide-react";
import ICD10CodeSelector from '../shared/ICD10CodeSelector';

export default function PrescriptionModal({ patient, prescription, onSave, onCancel }) {
  const [formData, setFormData] = useState({
    medication_name: prescription?.medication_name || '',
    dosage: prescription?.dosage || '',
    frequency: prescription?.frequency || 'Once weekly',
    start_date: prescription?.start_date || new Date().toISOString().split('T')[0],
    end_date: prescription?.end_date || '',
    status: prescription?.status || 'Active',
    instructions: prescription?.instructions || '',
    refills_remaining: prescription?.refills_remaining || 0,
    diagnosis_icd10_code: prescription?.diagnosis_icd10_code || '',
    diagnosis_icd10_description: prescription?.diagnosis_icd10_description || ''
  });
  const [diagnosisCode, setDiagnosisCode] = useState(null);
  const [loading, setLoading] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    const loadUser = async () => {
      try {
        const user = await User.me();
        setCurrentUser(user);
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();

    if (prescription && prescription.diagnosis_icd10_code) {
      setDiagnosisCode({
        code: prescription.diagnosis_icd10_code,
        description: prescription.diagnosis_icd10_description
      });
    }
  }, [prescription]);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSelectDiagnosis = (selectedCode) => {
    setDiagnosisCode(selectedCode);
    setFormData(prev => ({
      ...prev,
      diagnosis_icd10_code: selectedCode.code,
      diagnosis_icd10_description: selectedCode.description,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!currentUser) return;
    setLoading(true);

    const dataToSave = {
      ...formData,
      patient_id: patient.id,
      prescribing_clinician: currentUser.email,
      refills_remaining: Number(formData.refills_remaining),
    };

    try {
      if (prescription) {
        await Prescription.update(prescription.id, dataToSave);
      } else {
        await Prescription.create(dataToSave);
      }
      onSave();
    } catch (error) {
      console.error("Error saving prescription:", error);
    }

    setLoading(false);
  };

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold text-slate-900">
            {prescription ? 'Edit Prescription' : 'New Prescription'}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 mt-6 max-h-[70vh] overflow-y-auto pr-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="medication_name">Medication Name *</Label>
              <Input
                id="medication_name"
                value={formData.medication_name}
                onChange={(e) => handleInputChange('medication_name', e.target.value)}
                placeholder="e.g., Semaglutide"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dosage">Dosage *</Label>
              <Input
                id="dosage"
                value={formData.dosage}
                onChange={(e) => handleInputChange('dosage', e.target.value)}
                placeholder="e.g., 0.25mg"
                required
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="diagnosis">Associated Diagnosis (ICD-10)</Label>
            <ICD10CodeSelector
              value={diagnosisCode}
              onSelect={handleSelectDiagnosis}
              contextualText={formData.medication_name}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="frequency">Frequency</Label>
              <Select value={formData.frequency} onValueChange={(v) => handleInputChange('frequency', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Once weekly">Once weekly</SelectItem>
                  <SelectItem value="Once daily">Once daily</SelectItem>
                  <SelectItem value="Twice daily">Twice daily</SelectItem>
                  <SelectItem value="As needed">As needed</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select value={formData.status} onValueChange={(v) => handleInputChange('status', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Active">Active</SelectItem>
                  <SelectItem value="Discontinued">Discontinued</SelectItem>
                  <SelectItem value="Paused">Paused</SelectItem>
                  <SelectItem value="Completed">Completed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="start_date">Start Date *</Label>
              <Input
                id="start_date"
                type="date"
                value={formData.start_date}
                onChange={(e) => handleInputChange('start_date', e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="end_date">End Date</Label>
              <Input
                id="end_date"
                type="date"
                value={formData.end_date}
                onChange={(e) => handleInputChange('end_date', e.target.value)}
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="refills_remaining">Refills Remaining</Label>
            <Input
              id="refills_remaining"
              type="number"
              value={formData.refills_remaining}
              onChange={(e) => handleInputChange('refills_remaining', e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="instructions">Instructions</Label>
            <Textarea
              id="instructions"
              value={formData.instructions}
              onChange={(e) => handleInputChange('instructions', e.target.value)}
              placeholder="e.g., Inject subcutaneously in abdomen once weekly."
            />
          </div>

          <div className="flex justify-end gap-3 pt-6 border-t">
            <Button type="button" variant="outline" onClick={onCancel} disabled={loading}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading} className="bg-blue-600 hover:bg-blue-700">
              {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
              {prescription ? 'Update Prescription' : 'Create Prescription'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}