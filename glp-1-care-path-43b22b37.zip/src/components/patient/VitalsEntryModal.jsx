import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { VitalRecord } from "@/api/entities";
import { User } from "@/api/entities";
import { Activity } from "lucide-react";

export default function VitalsEntryModal({ patient, onSave, onCancel }) {
  const [formData, setFormData] = useState({
    weight_kg: '',
    bmi: '',
    systolic_bp: '',
    diastolic_bp: '',
    recorded_date: new Date().toISOString().split('T')[0]
  });
  const [loading, setLoading] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const user = await User.me();
        setCurrentUser(user);
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();
  }, []);

  const handleInputChange = (field, value) => {
    setFormData(prev => {
      const newData = { ...prev, [field]: value };
      
      // Auto-calculate BMI if weight and patient height are available
      if (field === 'weight_kg' && patient.height_cm && value) {
        const heightInMeters = patient.height_cm / 100;
        const bmi = (parseFloat(value) / (heightInMeters * heightInMeters)).toFixed(1);
        newData.bmi = bmi;
      }
      
      return newData;
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!currentUser) return;

    setLoading(true);
    
    try {
      const vitalsData = {
        patient_id: patient.id,
        weight_kg: formData.weight_kg ? parseFloat(formData.weight_kg) : undefined,
        bmi: formData.bmi ? parseFloat(formData.bmi) : undefined,
        systolic_bp: formData.systolic_bp ? parseFloat(formData.systolic_bp) : undefined,
        diastolic_bp: formData.diastolic_bp ? parseFloat(formData.diastolic_bp) : undefined,
        recorded_date: formData.recorded_date,
        recorded_by: currentUser.email
      };
      
      await VitalRecord.create(vitalsData);
      onSave();
    } catch (error) {
      console.error("Error creating vital record:", error);
    }
    
    setLoading(false);
  };

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold text-slate-900 flex items-center gap-2">
            <Activity className="w-5 h-5 text-blue-600" />
            Log Vitals for {patient.first_name} {patient.last_name}
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6 mt-6">
          <div className="space-y-2">
            <Label htmlFor="recorded_date">Date Recorded</Label>
            <Input
              id="recorded_date"
              type="date"
              value={formData.recorded_date}
              onChange={(e) => handleInputChange('recorded_date', e.target.value)}
              required
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="weight_kg">Weight (kg)</Label>
              <Input
                id="weight_kg"
                type="number"
                step="0.1"
                value={formData.weight_kg}
                onChange={(e) => handleInputChange('weight_kg', e.target.value)}
                placeholder="75.5"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="bmi">BMI</Label>
              <Input
                id="bmi"
                type="number"
                step="0.1"
                value={formData.bmi}
                onChange={(e) => handleInputChange('bmi', e.target.value)}
                placeholder="25.3"
                readOnly={patient.height_cm && formData.weight_kg}
              />
              {patient.height_cm && formData.weight_kg && (
                <p className="text-xs text-slate-500">Auto-calculated from height ({patient.height_cm}cm)</p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="systolic_bp">Systolic BP (mmHg)</Label>
              <Input
                id="systolic_bp"
                type="number"
                value={formData.systolic_bp}
                onChange={(e) => handleInputChange('systolic_bp', e.target.value)}
                placeholder="120"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="diastolic_bp">Diastolic BP (mmHg)</Label>
              <Input
                id="diastolic_bp"
                type="number"
                value={formData.diastolic_bp}
                onChange={(e) => handleInputChange('diastolic_bp', e.target.value)}
                placeholder="80"
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-6">
            <Button
              type="button"
              variant="outline"
              onClick={onCancel}
              disabled={loading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={loading}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {loading ? "Saving..." : "Save Vitals"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}