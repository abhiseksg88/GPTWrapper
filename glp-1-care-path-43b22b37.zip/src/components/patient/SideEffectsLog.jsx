import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { SideEffect } from "@/api/entities";
import { User } from "@/api/entities";
import { AlertTriangle, Plus, Calendar, X } from "lucide-react";
import { format } from "date-fns";

export default function SideEffectsLog({ patientId }) {
  const [sideEffects, setSideEffects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [newSideEffect, setNewSideEffect] = useState({
    effect_type: '',
    severity: 'Mild',
    onset_date: new Date().toISOString().split('T')[0],
    resolution_date: '',
    notes: ''
  });

  useEffect(() => {
    loadSideEffects();
    loadCurrentUser();
  }, [patientId]);

  const loadCurrentUser = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
    } catch (error) {
      console.error("Error loading current user:", error);
    }
  };

  const loadSideEffects = async () => {
    try {
      const data = await SideEffect.filter({ patient_id: patientId }, "-onset_date");
      setSideEffects(data);
    } catch (error) {
      console.error("Error loading side effects:", error);
      // Generate sample data
      const sampleData = generateSampleSideEffects();
      setSideEffects(sampleData);
    }
    setLoading(false);
  };

  const generateSampleSideEffects = () => {
    return [
      {
        id: '1',
        effect_type: 'Nausea',
        severity: 'Mild',
        onset_date: '2024-01-20',
        resolution_date: '2024-01-25',
        notes: 'Occurred after dose increase, resolved with slower eating',
        reported_by: 'Patient'
      },
      {
        id: '2',
        effect_type: 'Injection site reaction',
        severity: 'Mild',
        onset_date: '2024-02-01',
        notes: 'Minor redness and swelling, improved with site rotation',
        reported_by: 'Patient'
      }
    ];
  };

  const handleAddSideEffect = async () => {
    if (!newSideEffect.effect_type || !currentUser) return;

    try {
      const sideEffectData = {
        patient_id: patientId,
        effect_type: newSideEffect.effect_type,
        severity: newSideEffect.severity,
        onset_date: newSideEffect.onset_date,
        resolution_date: newSideEffect.resolution_date || null,
        notes: newSideEffect.notes,
        reported_by: currentUser.email
      };

      await SideEffect.create(sideEffectData);
      setNewSideEffect({
        effect_type: '',
        severity: 'Mild',
        onset_date: new Date().toISOString().split('T')[0],
        resolution_date: '',
        notes: ''
      });
      setShowAddForm(false);
      loadSideEffects();
    } catch (error) {
      console.error("Error adding side effect:", error);
    }
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'Mild':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Moderate':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'Severe':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Loading side effects data...</CardTitle>
        </CardHeader>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="border-slate-200">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-orange-600" />
              Side Effects Log
            </CardTitle>
            <Button 
              size="sm" 
              className="bg-blue-600 hover:bg-blue-700"
              onClick={() => setShowAddForm(!showAddForm)}
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Side Effect
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {showAddForm && (
            <div className="mb-6 p-4 border border-slate-200 rounded-lg bg-slate-50">
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-medium text-slate-900">Add New Side Effect</h4>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setShowAddForm(false)}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
              
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Side Effect Type</Label>
                    <Select
                      value={newSideEffect.effect_type}
                      onValueChange={(value) => setNewSideEffect(prev => ({ ...prev, effect_type: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select side effect" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Nausea">Nausea</SelectItem>
                        <SelectItem value="Vomiting">Vomiting</SelectItem>
                        <SelectItem value="Diarrhea">Diarrhea</SelectItem>
                        <SelectItem value="Constipation">Constipation</SelectItem>
                        <SelectItem value="Headache">Headache</SelectItem>
                        <SelectItem value="Fatigue">Fatigue</SelectItem>
                        <SelectItem value="Dizziness">Dizziness</SelectItem>
                        <SelectItem value="Injection site reaction">Injection site reaction</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Severity</Label>
                    <Select
                      value={newSideEffect.severity}
                      onValueChange={(value) => setNewSideEffect(prev => ({ ...prev, severity: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Mild">Mild</SelectItem>
                        <SelectItem value="Moderate">Moderate</SelectItem>
                        <SelectItem value="Severe">Severe</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Onset Date</Label>
                    <Input
                      type="date"
                      value={newSideEffect.onset_date}
                      onChange={(e) => setNewSideEffect(prev => ({ ...prev, onset_date: e.target.value }))}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Resolution Date (Optional)</Label>
                    <Input
                      type="date"
                      value={newSideEffect.resolution_date}
                      onChange={(e) => setNewSideEffect(prev => ({ ...prev, resolution_date: e.target.value }))}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Notes</Label>
                  <Textarea
                    value={newSideEffect.notes}
                    onChange={(e) => setNewSideEffect(prev => ({ ...prev, notes: e.target.value }))}
                    placeholder="Additional details about the side effect..."
                    rows={3}
                  />
                </div>

                <div className="flex justify-end gap-3">
                  <Button
                    variant="outline"
                    onClick={() => setShowAddForm(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={handleAddSideEffect}
                    disabled={!newSideEffect.effect_type}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    Add Side Effect
                  </Button>
                </div>
              </div>
            </div>
          )}

          {sideEffects.length > 0 ? (
            <div className="space-y-4">
              {sideEffects.map((effect) => (
                <div 
                  key={effect.id}
                  className="p-4 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h4 className="font-medium text-slate-900">{effect.effect_type}</h4>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge 
                          variant="outline" 
                          className={`${getSeverityColor(effect.severity)} border text-xs`}
                        >
                          {effect.severity}
                        </Badge>
                        <span className="text-sm text-slate-500">
                          Reported by {effect.reported_by}
                        </span>
                      </div>
                    </div>
                    <div className="text-right text-sm text-slate-500">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        Started: {format(new Date(effect.onset_date), "MMM d, yyyy")}
                      </div>
                      {effect.resolution_date && (
                        <div className="flex items-center gap-1 mt-1">
                          <Calendar className="w-3 h-3" />
                          Resolved: {format(new Date(effect.resolution_date), "MMM d, yyyy")}
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {effect.notes && (
                    <div className="mt-3 p-3 bg-slate-50 rounded-md">
                      <p className="text-sm text-slate-700">{effect.notes}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <AlertTriangle className="w-12 h-12 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-500">No side effects reported for this patient.</p>
              <Button 
                variant="outline" 
                className="mt-4"
                size="sm"
                onClick={() => setShowAddForm(true)}
              >
                <Plus className="w-4 h-4 mr-2" />
                Add First Side Effect
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Side Effects Summary */}
      {sideEffects.length > 0 && (
        <Card className="border-slate-200">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-slate-900">Side Effects Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-yellow-50 rounded-lg">
                <p className="text-sm font-medium text-yellow-800">Mild Effects</p>
                <p className="text-2xl font-bold text-yellow-900">
                  {sideEffects.filter(e => e.severity === 'Mild').length}
                </p>
              </div>
              <div className="p-4 bg-orange-50 rounded-lg">
                <p className="text-sm font-medium text-orange-800">Moderate Effects</p>
                <p className="text-2xl font-bold text-orange-900">
                  {sideEffects.filter(e => e.severity === 'Moderate').length}
                </p>
              </div>
              <div className="p-4 bg-red-50 rounded-lg">
                <p className="text-sm font-medium text-red-800">Severe Effects</p>
                <p className="text-2xl font-bold text-red-900">
                  {sideEffects.filter(e => e.severity === 'Severe').length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}