import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LifestylePlan } from "@/api/entities";
import { User } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Sparkles, Brain, Loader2, AlertCircle, CheckCircle, Copy } from "lucide-react";

export default function LifestylePlanModal({ patient, plan, onSave, onCancel }) {
  const [activeTab, setActiveTab] = useState("manual");
  const [formData, setFormData] = useState({
    plan_name: plan?.plan_name || '',
    description: plan?.description || '',
    status: plan?.status || 'Active',
    start_date: plan?.start_date || new Date().toISOString().split('T')[0],
    end_date: plan?.end_date || '',
    target_weight_kg: plan?.target_weight_kg || '',
    target_hba1c: plan?.target_hba1c || '',
    notes: plan?.notes || ''
  });
  
  const [aiGenerated, setAiGenerated] = useState({
    plan_name: '',
    description: '',
    target_weight_kg: '',
    target_hba1c: '',
    notes: ''
  });
  
  const [loading, setLoading] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [aiError, setAiError] = useState(null);

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const user = await User.me();
        setCurrentUser(user);
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();
  }, []);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const generateAIPlan = async () => {
    if (!patient || !currentUser) return;
    
    setAiLoading(true);
    setAiError(null);
    
    try {
      const patientInfo = `
Patient: ${patient.first_name} ${patient.last_name}
Age: ${patient.date_of_birth ? new Date().getFullYear() - new Date(patient.date_of_birth).getFullYear() : 'Unknown'}
Gender: ${patient.gender || 'Not specified'}
Height: ${patient.height_cm ? `${patient.height_cm}cm` : 'Not specified'}
Primary Condition: ${patient.primary_condition}
Phone: ${patient.phone || 'Not provided'}
Emergency Contact: ${patient.emergency_contact || 'Not provided'}
      `.trim();

      const prompt = `
As CarePlix AI, a specialized clinical assistant for GLP-1 therapy management, create a comprehensive lifestyle plan for this patient.

${patientInfo}

Please generate a detailed lifestyle plan with the following components:

1. **Plan Name**: A clear, descriptive name for this patient's lifestyle plan
2. **Description**: Comprehensive plan description including objectives and approach
3. **Target Weight**: Realistic weight loss target in kg (if applicable for this condition)
4. **Target HbA1c**: Appropriate HbA1c target based on condition and current status
5. **Clinical Notes**: Important considerations, monitoring requirements, and safety notes

Consider:
- Patient's primary condition and typical treatment protocols
- Age-appropriate recommendations
- Evidence-based GLP-1 therapy support strategies
- Realistic and achievable goals
- Safety considerations and contraindications
- Integration with medication therapy

Provide practical, evidence-based recommendations that a clinician can implement immediately.
      `;

      const response = await InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: "object",
          properties: {
            plan_name: {
              type: "string",
              description: "Clear, descriptive name for the lifestyle plan"
            },
            description: {
              type: "string",
              description: "Comprehensive plan description with objectives and approach"
            },
            target_weight_kg: {
              type: "number",
              description: "Realistic target weight in kilograms"
            },
            target_hba1c: {
              type: "number",
              description: "Target HbA1c percentage"
            },
            notes: {
              type: "string",
              description: "Clinical notes, monitoring requirements, and safety considerations"
            }
          }
        }
      });

      setAiGenerated(response);
      
    } catch (error) {
      console.error("Error generating AI plan:", error);
      setAiError("Failed to generate AI plan. Please try again or create manually.");
    }
    
    setAiLoading(false);
  };

  const copyAIToForm = (field) => {
    if (aiGenerated[field]) {
      setFormData(prev => ({
        ...prev,
        [field]: aiGenerated[field]
      }));
    }
  };

  const copyAllAIToForm = () => {
    setFormData(prev => ({
      ...prev,
      plan_name: aiGenerated.plan_name || prev.plan_name,
      description: aiGenerated.description || prev.description,
      target_weight_kg: aiGenerated.target_weight_kg || prev.target_weight_kg,
      target_hba1c: aiGenerated.target_hba1c || prev.target_hba1c,
      notes: aiGenerated.notes || prev.notes
    }));
    setActiveTab("manual");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!currentUser) return;
    
    setLoading(true);
    
    try {
      const planData = {
        patient_id: patient.id,
        plan_name: formData.plan_name,
        description: formData.description,
        status: formData.status,
        start_date: formData.start_date,
        end_date: formData.end_date || null,
        created_by: currentUser.email,
        target_weight_kg: formData.target_weight_kg ? parseFloat(formData.target_weight_kg) : null,
        target_hba1c: formData.target_hba1c ? parseFloat(formData.target_hba1c) : null,
        notes: formData.notes
      };
      
      if (plan) {
        await LifestylePlan.update(plan.id, planData);
      } else {
        await LifestylePlan.create(planData);
      }
      
      onSave();
    } catch (error) {
      console.error("Error saving lifestyle plan:", error);
    }
    
    setLoading(false);
  };

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold text-slate-900 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-blue-600" />
            {plan ? 'Edit' : 'Create'} Lifestyle Plan for {patient.first_name} {patient.last_name}
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="ai" className="flex items-center gap-2">
              <Brain className="w-4 h-4" />
              CarePlix AI Assistant
            </TabsTrigger>
            <TabsTrigger value="manual">Manual Creation</TabsTrigger>
          </TabsList>

          <TabsContent value="ai" className="space-y-6">
            <Card className="border-blue-200 bg-gradient-to-r from-blue-50 to-indigo-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-blue-800">
                  <Brain className="w-5 h-5" />
                  CarePlix AI Plan Generator
                </CardTitle>
                <p className="text-sm text-blue-700">
                  Let AI create a personalized lifestyle plan based on this patient's profile and condition.
                </p>
              </CardHeader>
              <CardContent>
                <Button 
                  onClick={generateAIPlan}
                  disabled={aiLoading}
                  className="bg-blue-600 hover:bg-blue-700 mb-4"
                >
                  {aiLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      CarePlix AI is generating plan...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Generate AI Plan
                    </>
                  )}
                </Button>

                {aiError && (
                  <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
                    <AlertCircle className="w-4 h-4" />
                    {aiError}
                  </div>
                )}

                {aiGenerated.plan_name && (
                  <div className="space-y-4">
                    <div className="flex items-center gap-2 mb-4">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      <span className="font-medium text-green-800">AI Plan Generated Successfully!</span>
                      <Button 
                        onClick={copyAllAIToForm}
                        size="sm"
                        className="ml-auto bg-green-600 hover:bg-green-700"
                      >
                        Use This Plan
                      </Button>
                    </div>

                    <div className="grid gap-4">
                      <div className="bg-white p-4 rounded-lg border border-slate-200">
                        <div className="flex items-center justify-between mb-2">
                          <Label className="font-medium text-slate-700">Plan Name</Label>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => copyAIToForm('plan_name')}
                          >
                            <Copy className="w-4 h-4" />
                          </Button>
                        </div>
                        <p className="text-slate-900">{aiGenerated.plan_name}</p>
                      </div>

                      <div className="bg-white p-4 rounded-lg border border-slate-200">
                        <div className="flex items-center justify-between mb-2">
                          <Label className="font-medium text-slate-700">Description</Label>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => copyAIToForm('description')}
                          >
                            <Copy className="w-4 h-4" />
                          </Button>
                        </div>
                        <p className="text-slate-900 whitespace-pre-wrap">{aiGenerated.description}</p>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {aiGenerated.target_weight_kg && (
                          <div className="bg-white p-4 rounded-lg border border-slate-200">
                            <div className="flex items-center justify-between mb-2">
                              <Label className="font-medium text-slate-700">Target Weight</Label>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => copyAIToForm('target_weight_kg')}
                              >
                                <Copy className="w-4 h-4" />
                              </Button>
                            </div>
                            <p className="text-slate-900">{aiGenerated.target_weight_kg} kg</p>
                          </div>
                        )}

                        {aiGenerated.target_hba1c && (
                          <div className="bg-white p-4 rounded-lg border border-slate-200">
                            <div className="flex items-center justify-between mb-2">
                              <Label className="font-medium text-slate-700">Target HbA1c</Label>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => copyAIToForm('target_hba1c')}
                              >
                                <Copy className="w-4 h-4" />
                              </Button>
                            </div>
                            <p className="text-slate-900">{aiGenerated.target_hba1c}%</p>
                          </div>
                        )}
                      </div>

                      {aiGenerated.notes && (
                        <div className="bg-white p-4 rounded-lg border border-slate-200">
                          <div className="flex items-center justify-between mb-2">
                            <Label className="font-medium text-slate-700">Clinical Notes</Label>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => copyAIToForm('notes')}
                            >
                              <Copy className="w-4 h-4" />
                            </Button>
                          </div>
                          <p className="text-slate-900 whitespace-pre-wrap">{aiGenerated.notes}</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="manual">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="plan_name">Plan Name *</Label>
                  <Input
                    id="plan_name"
                    value={formData.plan_name}
                    onChange={(e) => handleInputChange('plan_name', e.target.value)}
                    placeholder="e.g., GLP-1 Weight Management Plan"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select
                    value={formData.status}
                    onValueChange={(value) => handleInputChange('status', value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Active">Active</SelectItem>
                      <SelectItem value="Draft">Draft</SelectItem>
                      <SelectItem value="Paused">Paused</SelectItem>
                      <SelectItem value="Completed">Completed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Plan Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  placeholder="Describe the overall goals and approach for this lifestyle plan..."
                  rows={4}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="start_date">Start Date</Label>
                  <Input
                    id="start_date"
                    type="date"
                    value={formData.start_date}
                    onChange={(e) => handleInputChange('start_date', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="end_date">End Date (Optional)</Label>
                  <Input
                    id="end_date"
                    type="date"
                    value={formData.end_date}
                    onChange={(e) => handleInputChange('end_date', e.target.value)}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="target_weight_kg">Target Weight (kg)</Label>
                  <Input
                    id="target_weight_kg"
                    type="number"
                    step="0.1"
                    value={formData.target_weight_kg}
                    onChange={(e) => handleInputChange('target_weight_kg', e.target.value)}
                    placeholder="e.g., 75"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="target_hba1c">Target HbA1c (%)</Label>
                  <Input
                    id="target_hba1c"
                    type="number"
                    step="0.1"
                    value={formData.target_hba1c}
                    onChange={(e) => handleInputChange('target_hba1c', e.target.value)}
                    placeholder="e.g., 6.5"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Additional Notes</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => handleInputChange('notes', e.target.value)}
                  placeholder="Any additional instructions, considerations, or notes..."
                  rows={3}
                />
              </div>

              <div className="flex justify-end gap-3 pt-6">
                <Button
                  type="button"
                  variant="outline"
                  onClick={onCancel}
                  disabled={loading}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={loading}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {loading ? "Saving..." : (plan ? "Update Plan" : "Create Plan")}
                </Button>
              </div>
            </form>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}