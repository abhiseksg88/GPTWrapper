
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { FileText, Loader2 } from "lucide-react";
import { format } from "date-fns";

export default function PatientPlanDownload({ patient, vitals, prescriptions, lifestylePlans, adherenceRecords, sideEffects, clinicalNotes }) {
  const [generating, setGenerating] = useState(false);

  const generateAndPrintReport = async () => {
    setGenerating(true);
    try {
      const reportContent = await generatePrintableContent();
      
      const printWindow = window.open('', '_blank');
      printWindow.document.write(reportContent);
      printWindow.document.close();
      
      printWindow.onload = () => {
        setTimeout(() => {
          printWindow.print();
          printWindow.onafterprint = () => printWindow.close();
        }, 500); // Small delay to ensure styles are loaded
      };
    } catch (error) {
      console.error('Error generating PDF report:', error);
      alert('Failed to generate PDF report. Please try again.');
    }
    setGenerating(false);
  };

  const generatePrintableContent = async () => {
    // --- Data Processing ---
    const activePrescriptions = prescriptions?.filter(p => p.status === 'Active') || [];
    const historicalPrescriptions = prescriptions?.filter(p => p.status !== 'Active').sort((a, b) => new Date(b.start_date) - new Date(a.start_date)) || [];
    
    const latestVitals = vitals?.find(v => v.weight_kg) || {};
    const latestBP = vitals?.find(v => v.systolic_bp) || {};
    const latestHbA1c = vitals?.find(v => v.hba1c) || {};
    
    const weightData = vitals?.filter(v => v.weight_kg).slice(0, 12).reverse() || [];
    const hba1cData = vitals?.filter(v => v.hba1c).slice(0, 6).reverse() || [];

    const adherenceRate = adherenceRecords?.length > 0 
        ? Math.round((adherenceRecords.filter(r => r.dose_taken).length / adherenceRecords.length) * 100) 
        : 100;

    const currentDate = format(new Date(), 'MMMM dd, yyyy');
    const patientAge = patient.date_of_birth 
      ? new Date().getFullYear() - new Date(patient.date_of_birth).getFullYear()
      : 'N/A';

    const currentBMI = (latestVitals.weight_kg && patient.height_cm) 
      ? (latestVitals.weight_kg / ((patient.height_cm/100)**2)).toFixed(1)
      : 'N/A';

    return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CarePlix Care Management Report - ${patient.first_name} ${patient.last_name}</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body { 
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; 
            line-height: 1.6; 
            color: #1e293b; 
            background: #ffffff;
            font-size: 14px;
        }
        
        .report-container { 
            max-width: 210mm; 
            margin: 0 auto; 
            background: white; 
            min-height: 297mm;
        }
        
        .report-header { 
            background: linear-gradient(135deg, #1e40af 0%, #3b82f6 50%, #60a5fa 100%); 
            color: white; 
            padding: 40px 30px; 
            text-align: center; 
            position: relative;
            margin-bottom: 0;
        }
        
        .logo-container {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .logo-image {
            width: 200px;
            height: auto;
            max-height: 60px;
            object-fit: contain;
            background: white;
            padding: 10px 15px;
            border-radius: 10px;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }
        
        .report-title { 
            font-size: 28px; 
            font-weight: 700; 
            margin-bottom: 8px; 
        }
        
        .report-subtitle { 
            font-size: 18px; 
            opacity: 0.9; 
            font-weight: 400;
        }
        
        .report-date { 
            position: absolute; 
            top: 25px; 
            right: 30px; 
            background: rgba(255, 255, 255, 0.15); 
            padding: 8px 16px; 
            border-radius: 20px; 
            font-size: 13px; 
        }
        
        .patient-summary { 
            background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%); 
            padding: 30px; 
            border-bottom: 2px solid #e2e8f0;
        }
        
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .summary-item {
            background: white;
            padding: 15px;
            border-radius: 8px;
            border-left: 4px solid #3b82f6;
        }
        
        .summary-label {
            font-size: 12px;
            color: #64748b;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .summary-value {
            font-size: 16px;
            font-weight: 600;
            color: #1e293b;
            margin-top: 4px;
        }
        
        .section { 
            padding: 30px; 
            border-bottom: 1px solid #e2e8f0;
            page-break-inside: avoid;
        }
        
        .section-title { 
            font-size: 22px; 
            font-weight: 700; 
            color: #1e293b; 
            margin-bottom: 20px; 
            display: flex; 
            align-items: center; 
            gap: 12px;
            padding-bottom: 10px;
            border-bottom: 2px solid #e2e8f0;
        }
        
        .section-icon {
            width: 32px;
            height: 32px;
            background: linear-gradient(135deg, #3b82f6, #1e40af);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 16px;
            font-weight: bold;
        }
        
        .content-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .content-card {
            background: #f8fafc;
            padding: 20px;
            border-radius: 12px;
            border: 1px solid #e2e8f0;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        
        .card-title {
            font-size: 16px;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 12px;
            padding-bottom: 8px;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .medication-item {
            background: white;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 10px;
            border-left: 4px solid #10b981;
        }
        
        .medication-name {
            font-weight: 600;
            color: #1e293b;
            font-size: 15px;
        }
        
        .medication-details {
            color: #64748b;
            font-size: 13px;
            margin-top: 4px;
        }
        
        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .status-active { background: #dcfce7; color: #166534; }
        .status-completed { background: #dbeafe; color: #1e40af; }
        .status-discontinued { background: #fee2e2; color: #dc2626; }
        
        .footer {
            background: #1e293b;
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .footer-logo {
            width: 120px;
            height: auto;
            max-height: 40px;
            object-fit: contain;
            background: white;
            padding: 8px 12px;
            border-radius: 8px;
            margin-bottom: 15px;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }
        
        @media print {
            body { font-size: 12px; }
            .report-container { margin: 0; max-width: none; }
            .section { padding: 20px; page-break-inside: avoid; }
            .report-header { page-break-after: avoid; }
            .logo-image, .footer-logo {
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
                color-adjust: exact !important;
            }
        }
        
        @page { 
            margin: 0.5in; 
            size: A4; 
        }
    </style>
</head>
<body>
    <div class="report-container">
        <div class="report-header">
            <div class="report-date">${currentDate}</div>
            <div class="logo-container">
                <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/517303104_careplix-logo784ea9f51.png" 
                     alt="CarePlix Logo" 
                     class="logo-image" />
            </div>
            <h1 class="report-title">Care Management Platform Report</h1>
            <p class="report-subtitle">Comprehensive Patient Care Summary</p>
        </div>

        <div class="patient-summary">
            <h2 style="font-size: 20px; font-weight: 600; margin-bottom: 8px; color: #1e293b;">Patient Summary</h2>
            <p style="color: #64748b; margin-bottom: 20px;">Complete clinical overview for ${patient.first_name} ${patient.last_name}</p>
            
            <div class="summary-grid">
                <div class="summary-item">
                    <div class="summary-label">Patient Information</div>
                    <div class="summary-value">${patient.first_name} ${patient.last_name}</div>
                    <div style="font-size: 13px; color: #64748b; margin-top: 4px;">ID: ${patient.patient_id} • Age: ${patientAge}</div>
                </div>
                <div class="summary-item">
                    <div class="summary-label">Primary Condition</div>
                    <div class="summary-value">${patient.primary_condition}</div>
                </div>
                <div class="summary-item">
                    <div class="summary-label">Current Weight</div>
                    <div class="summary-value">${latestVitals.weight_kg || '--'} kg</div>
                    <div style="font-size: 13px; color: #64748b; margin-top: 4px;">BMI: ${currentBMI}</div>
                </div>
                <div class="summary-item">
                    <div class="summary-label">Adherence Rate</div>
                    <div class="summary-value">${adherenceRate}%</div>
                    <div style="font-size: 13px; color: #64748b; margin-top: 4px;">Last 30 days</div>
                </div>
                <div class="summary-item">
                    <div class="summary-label">Latest HbA1c</div>
                    <div class="summary-value">${latestHbA1c.hba1c || '--'}%</div>
                </div>
                <div class="summary-item">
                    <div class="summary-label">Blood Pressure</div>
                    <div class="summary-value">${latestBP.systolic_bp && latestBP.diastolic_bp ? `${latestBP.systolic_bp}/${latestBP.diastolic_bp}` : '--'}</div>
                    <div style="font-size: 13px; color: #64748b; margin-top: 4px;">mmHg</div>
                </div>
            </div>
        </div>

        <div class="section">
            <h2 class="section-title">
                <div class="section-icon">💊</div>
                Current Medications
            </h2>
            ${activePrescriptions.length > 0 ? `
                <div class="content-grid">
                    ${activePrescriptions.map(med => `
                        <div class="medication-item">
                            <div class="medication-name">${med.medication_name}</div>
                            <div class="medication-details">${med.dosage} • ${med.frequency}</div>
                            <div style="margin-top: 8px;">
                                <span class="status-badge status-active">Active</span>
                                <span style="margin-left: 10px; font-size: 11px; color: #64748b;">
                                    ${med.refills_remaining || 0} refills remaining
                                </span>
                            </div>
                            ${med.instructions ? `<div style="margin-top: 8px; font-size: 12px; color: #64748b;">${med.instructions}</div>` : ''}
                        </div>
                    `).join('')}
                </div>
            ` : '<p style="color: #64748b; font-style: italic;">No active medications recorded.</p>'}
        </div>

        ${historicalPrescriptions.length > 0 ? `
        <div class="section">
            <h2 class="section-title">
                <div class="section-icon">📋</div>
                Medication History
            </h2>
            <div class="content-grid">
                ${historicalPrescriptions.slice(0, 6).map(med => `
                    <div class="medication-item" style="border-left-color: #64748b;">
                        <div class="medication-name">${med.medication_name}</div>
                        <div class="medication-details">${med.dosage} • ${med.frequency}</div>
                        <div style="margin-top: 8px;">
                            <span class="status-badge ${med.status === 'Completed' ? 'status-completed' : 'status-discontinued'}">
                                ${med.status}
                            </span>
                            <span style="margin-left: 10px; font-size: 11px; color: #64748b;">
                                ${format(new Date(med.start_date), 'MMM yyyy')} - ${med.end_date ? format(new Date(med.end_date), 'MMM yyyy') : 'Ongoing'}
                            </span>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>` : ''}

        <div class="section">
            <h2 class="section-title">
                <div class="section-icon">📊</div>
                Vital Signs Trends
            </h2>
            <div class="content-grid">
                <div class="content-card">
                    <div class="card-title">Weight Progress</div>
                    ${weightData.length > 0 ? `
                        <div style="margin-bottom: 15px;">
                            <div style="font-size: 24px; font-weight: 700; color: #1e293b;">${latestVitals.weight_kg} kg</div>
                            <div style="font-size: 13px; color: #64748b;">Current weight</div>
                        </div>
                        <div>
                            <strong>Recent readings:</strong><br>
                            ${weightData.slice(-5).map(v => `${format(new Date(v.recorded_date), 'MMM dd')}: ${v.weight_kg}kg`).join('<br>')}
                        </div>
                    ` : '<p style="color: #64748b; font-style: italic;">No weight data available</p>'}
                </div>
                <div class="content-card">
                    <div class="card-title">HbA1c Monitoring</div>
                    ${hba1cData.length > 0 ? `
                        <div style="margin-bottom: 15px;">
                            <div style="font-size: 24px; font-weight: 700; color: #1e293b;">${latestHbA1c.hba1c}%</div>
                            <div style="font-size: 13px; color: #64748b;">Latest HbA1c</div>
                        </div>
                        <div>
                            <strong>Historical values:</strong><br>
                            ${hba1cData.slice(-3).map(v => `${format(new Date(v.recorded_date), 'MMM yyyy')}: ${v.hba1c}%`).join('<br>')}
                        </div>
                    ` : '<p style="color: #64748b; font-style: italic;">No HbA1c data available</p>'}
                </div>
            </div>
        </div>

        ${sideEffects && sideEffects.length > 0 ? `
        <div class="section">
            <h2 class="section-title">
                <div class="section-icon">⚠️</div>
                Side Effects Log
            </h2>
            <div class="content-grid">
                ${sideEffects.slice(0, 6).map(se => `
                    <div class="content-card">
                        <div class="card-title">${se.effect_type}</div>
                        <div style="margin-bottom: 8px;">
                            <span style="font-weight: 500;">Severity:</span> ${se.severity}
                        </div>
                        <div style="margin-bottom: 8px;">
                            <span style="font-weight: 500;">Onset:</span> ${format(new Date(se.onset_date), 'MMM dd, yyyy')}
                        </div>
                        ${se.notes ? `<div style="font-size: 13px; color: #64748b;">${se.notes}</div>` : ''}
                    </div>
                `).join('')}
            </div>
        </div>` : ''}

        ${clinicalNotes && clinicalNotes.length > 0 ? `
        <div class="section">
            <h2 class="section-title">
                <div class="section-icon">📝</div>
                Recent Clinical Notes
            </h2>
            <div class="content-grid">
                ${clinicalNotes.slice(0, 4).map(note => `
                    <div class="content-card">
                        <div class="card-title">${note.note_type}</div>
                        <div style="margin-bottom: 8px; font-size: 13px; color: #64748b;">
                            ${format(new Date(note.created_date), 'MMM dd, yyyy')} • ${note.clinician}
                        </div>
                        <div style="font-size: 14px; line-height: 1.5;">
                            ${note.content.length > 200 ? note.content.substring(0, 200) + '...' : note.content}
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>` : ''}

        <div class="footer">
            <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/517303104_careplix-logo784ea9f51.png" 
                 alt="CarePlix Logo" 
                 class="footer-logo" />
            <div style="font-size: 18px; font-weight: 600; margin-bottom: 8px;">CarePlix Care Management Platform</div>
            <div style="font-size: 14px; opacity: 0.8;">Generated on ${currentDate} • Confidential Patient Information</div>
        </div>
    </div>
</body>
</html>`;
  };

  return (
    <Button 
      onClick={generateAndPrintReport}
      disabled={generating}
      variant="outline"
      className="hover:bg-green-50"
    >
      {generating ? (
        <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Generating...</>
      ) : (
        <><FileText className="w-4 h-4 mr-2" /> Download Report</>
      )}
    </Button>
  );
}
