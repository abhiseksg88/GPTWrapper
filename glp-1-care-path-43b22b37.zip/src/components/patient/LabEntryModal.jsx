import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LabResult } from "@/api/entities";
import { User } from "@/api/entities";
import { Loader2 } from "lucide-react";
import ICD10CodeSelector from '../shared/ICD10CodeSelector';

export default function LabEntryModal({ patient, onSave, onCancel }) {
  const [formData, setFormData] = useState({
    test_name: '',
    result_value: '',
    result_unit: '',
    reference_range: '',
    status: 'Completed',
    test_date: new Date().toISOString().split('T')[0],
  });
  const [icd10, setIcd10] = useState(null);
  const [loading, setLoading] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    const loadUser = async () => {
      try {
        const user = await User.me();
        setCurrentUser(user);
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();
  }, []);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSelectIcd10 = (selectedCode) => {
    setIcd10(selectedCode);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!currentUser) return;
    setLoading(true);

    const dataToSave = {
      ...formData,
      patient_id: patient.id,
      ordered_by: currentUser.email,
      icd10_code: icd10?.code,
      icd10_description: icd10?.description,
    };

    try {
      await LabResult.create(dataToSave);
      onSave();
    } catch (error) {
      console.error("Error saving lab result:", error);
    }
    setLoading(false);
  };

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>Add Lab Result</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6 mt-6 max-h-[70vh] overflow-y-auto pr-4">
          <div className="space-y-2">
            <Label htmlFor="test_name">Test Name *</Label>
            <Input
              id="test_name"
              value={formData.test_name}
              onChange={(e) => handleInputChange('test_name', e.target.value)}
              placeholder="e.g., Hemoglobin A1c"
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="icd10_code">Associated Diagnosis (ICD-10)</Label>
            <ICD10CodeSelector
              value={icd10}
              onSelect={handleSelectIcd10}
              contextualText={formData.test_name}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="result_value">Result Value *</Label>
              <Input
                id="result_value"
                value={formData.result_value}
                onChange={(e) => handleInputChange('result_value', e.target.value)}
                placeholder="e.g., 6.8"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="result_unit">Unit</Label>
              <Input
                id="result_unit"
                value={formData.result_unit}
                onChange={(e) => handleInputChange('result_unit', e.target.value)}
                placeholder="e.g., % or mg/dL"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="reference_range">Reference Range</Label>
            <Input
              id="reference_range"
              value={formData.reference_range}
              onChange={(e) => handleInputChange('reference_range', e.target.value)}
              placeholder="e.g., 4.0 - 5.6 %"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="test_date">Test Date</Label>
              <Input id="test_date" type="date" value={formData.test_date} onChange={(e) => handleInputChange('test_date', e.target.value)} />
            </div>
             <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select value={formData.status} onValueChange={(v) => handleInputChange('status', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Ordered">Ordered</SelectItem>
                  <SelectItem value="Completed">Completed</SelectItem>
                  <SelectItem value="Reviewed">Reviewed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="flex justify-end gap-3 pt-6 border-t">
            <Button type="button" variant="outline" onClick={onCancel} disabled={loading}>Cancel</Button>
            <Button type="submit" disabled={loading} className="bg-blue-600 hover:bg-blue-700">
              {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
              Save Result
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}