import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DiagnosticTest } from "@/api/entities";
import DiagnosticTestModal from "./DiagnosticTestModal";
import { FlaskConical, Plus, Calendar, Edit } from "lucide-react";
import { format } from "date-fns";

export default function DiagnosticTestPanel({ patientId }) {
  const [tests, setTests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [selectedTest, setSelectedTest] = useState(null);

  useEffect(() => {
    loadTests();
  }, [patientId]);

  const loadTests = async () => {
    setLoading(true);
    try {
      const data = await DiagnosticTest.filter({ patient_id: patientId }, "-order_date");
      setTests(data);
    } catch (error) {
      console.error("Error loading diagnostic tests:", error);
    }
    setLoading(false);
  };

  const handleOpenModal = (test = null) => {
    setSelectedTest(test);
    setShowModal(true);
  };

  const handleSave = () => {
    setShowModal(false);
    setSelectedTest(null);
    loadTests();
  };

  const getStatusColor = (status) => {
    const colors = {
      Ordered: 'bg-gray-100 text-gray-800',
      Scheduled: 'bg-blue-100 text-blue-800',
      Completed: 'bg-purple-100 text-purple-800',
      'Results Received': 'bg-yellow-100 text-yellow-800',
      Reviewed: 'bg-green-100 text-green-800',
      Cancelled: 'bg-red-100 text-red-800',
    };
    return colors[status] || 'bg-gray-100 text-gray-800';
  };

  if (loading) return <p>Loading diagnostic tests...</p>;

  return (
    <div className="space-y-6">
      <Card className="border-slate-200">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <FlaskConical className="w-5 h-5 text-blue-600" />
              Diagnostic Tests
            </CardTitle>
            <Button onClick={() => handleOpenModal()} size="sm" className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Order New Test
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {tests.length > 0 ? (
            <div className="space-y-4">
              {tests.map((test) => (
                <div key={test.id} className="p-4 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-semibold text-slate-900">{test.test_name}</h4>
                      <p className="text-sm text-slate-600">{test.category}</p>
                      <div className="flex items-center gap-2 mt-2">
                         <Badge variant="secondary" className={`${getStatusColor(test.status)} text-xs`}>{test.status}</Badge>
                         <p className="text-xs text-slate-500 flex items-center gap-1"><Calendar className="w-3 h-3" /> Ordered: {format(new Date(test.order_date), 'MMM d, yyyy')}</p>
                         {test.due_date && <p className="text-xs text-slate-500 flex items-center gap-1"><Calendar className="w-3 h-3" /> Due: {format(new Date(test.due_date), 'MMM d, yyyy')}</p>}
                      </div>
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => handleOpenModal(test)}>
                        <Edit className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="mt-3 space-y-1 text-sm">
                    <p><strong>Reason:</strong> {test.reason}</p>
                    {test.results_summary && <p><strong>Results:</strong> {test.results_summary}</p>}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <FlaskConical className="w-12 h-12 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-500">No diagnostic tests have been ordered for this patient.</p>
            </div>
          )}
        </CardContent>
      </Card>
      {showModal && (
        <DiagnosticTestModal
          patient={{id: patientId}}
          test={selectedTest}
          onSave={handleSave}
          onCancel={() => setShowModal(false)}
        />
      )}
    </div>
  );
}