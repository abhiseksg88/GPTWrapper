import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ExercisePlan } from "@/api/entities";
import { X } from "lucide-react";

export default function ExerciseModal({ patient, lifestylePlanId, onSave, onCancel }) {
  const [formData, setFormData] = useState({
    exercise_type: '',
    exercise_name: '',
    description: '',
    duration_minutes: '',
    frequency_per_week: '',
    intensity_level: 'Moderate',
    sets: '',
    reps: '',
    weight_kg: '',
    target_heart_rate: '',
    progression_notes: '',
    safety_notes: ''
  });
  const [equipment, setEquipment] = useState([]);
  const [newEquipment, setNewEquipment] = useState('');
  const [loading, setLoading] = useState(false);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const addEquipment = () => {
    if (newEquipment.trim()) {
      setEquipment(prev => [...prev, newEquipment.trim()]);
      setNewEquipment('');
    }
  };

  const removeEquipment = (index) => {
    setEquipment(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!lifestylePlanId) {
      console.error("No lifestyle plan ID provided");
      return;
    }

    setLoading(true);
    
    try {
      const exerciseData = {
        lifestyle_plan_id: lifestylePlanId,
        patient_id: patient.id,
        exercise_type: formData.exercise_type,
        exercise_name: formData.exercise_name,
        description: formData.description,
        duration_minutes: formData.duration_minutes ? parseInt(formData.duration_minutes) : null,
        frequency_per_week: formData.frequency_per_week ? parseInt(formData.frequency_per_week) : null,
        intensity_level: formData.intensity_level,
        sets: formData.sets ? parseInt(formData.sets) : null,
        reps: formData.reps ? parseInt(formData.reps) : null,
        weight_kg: formData.weight_kg ? parseFloat(formData.weight_kg) : null,
        target_heart_rate: formData.target_heart_rate ? parseInt(formData.target_heart_rate) : null,
        progression_notes: formData.progression_notes,
        safety_notes: formData.safety_notes,
        equipment_needed: equipment
      };
      
      await ExercisePlan.create(exerciseData);
      onSave();
    } catch (error) {
      console.error("Error creating exercise plan:", error);
    }
    
    setLoading(false);
  };

  const isStrengthTraining = formData.exercise_type === 'Strength Training';
  const isCardio = formData.exercise_type === 'Cardio' || formData.exercise_type === 'Walking' || formData.exercise_type === 'Cycling' || formData.exercise_type === 'Swimming';

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold text-slate-900">
            Add Exercise Plan for {patient.first_name} {patient.last_name}
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="exercise_type">Exercise Type *</Label>
              <Select
                value={formData.exercise_type}
                onValueChange={(value) => handleInputChange('exercise_type', value)}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select exercise type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Cardio">Cardio</SelectItem>
                  <SelectItem value="Strength Training">Strength Training</SelectItem>
                  <SelectItem value="Flexibility">Flexibility</SelectItem>
                  <SelectItem value="Balance">Balance</SelectItem>
                  <SelectItem value="Walking">Walking</SelectItem>
                  <SelectItem value="Swimming">Swimming</SelectItem>
                  <SelectItem value="Cycling">Cycling</SelectItem>
                  <SelectItem value="Mixed">Mixed</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="exercise_name">Exercise Name *</Label>
              <Input
                id="exercise_name"
                value={formData.exercise_name}
                onChange={(e) => handleInputChange('exercise_name', e.target.value)}
                placeholder="e.g., Brisk Walking, Push-ups, Squats"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              placeholder="Detailed exercise instructions and form cues..."
              rows={3}
            />
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label htmlFor="duration_minutes">Duration (min)</Label>
              <Input
                id="duration_minutes"
                type="number"
                value={formData.duration_minutes}
                onChange={(e) => handleInputChange('duration_minutes', e.target.value)}
                placeholder="30"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="frequency_per_week">Frequency/Week</Label>
              <Input
                id="frequency_per_week"
                type="number"
                min="1"
                max="7"
                value={formData.frequency_per_week}
                onChange={(e) => handleInputChange('frequency_per_week', e.target.value)}
                placeholder="3"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="intensity_level">Intensity</Label>
              <Select
                value={formData.intensity_level}
                onValueChange={(value) => handleInputChange('intensity_level', value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Low">Low</SelectItem>
                  <SelectItem value="Moderate">Moderate</SelectItem>
                  <SelectItem value="High">High</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {isCardio && (
              <div className="space-y-2">
                <Label htmlFor="target_heart_rate">Target HR (bpm)</Label>
                <Input
                  id="target_heart_rate"
                  type="number"
                  value={formData.target_heart_rate}
                  onChange={(e) => handleInputChange('target_heart_rate', e.target.value)}
                  placeholder="130"
                />
              </div>
            )}
          </div>

          {isStrengthTraining && (
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="sets">Sets</Label>
                <Input
                  id="sets"
                  type="number"
                  value={formData.sets}
                  onChange={(e) => handleInputChange('sets', e.target.value)}
                  placeholder="3"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="reps">Reps</Label>
                <Input
                  id="reps"
                  type="number"
                  value={formData.reps}
                  onChange={(e) => handleInputChange('reps', e.target.value)}
                  placeholder="12"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="weight_kg">Weight (kg)</Label>
                <Input
                  id="weight_kg"
                  type="number"
                  step="0.5"
                  value={formData.weight_kg}
                  onChange={(e) => handleInputChange('weight_kg', e.target.value)}
                  placeholder="10"
                />
              </div>
            </div>
          )}

          <div className="space-y-2">
            <Label>Equipment Needed</Label>
            <div className="flex gap-2">
              <Input
                value={newEquipment}
                onChange={(e) => setNewEquipment(e.target.value)}
                placeholder="Add equipment..."
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addEquipment())}
              />
              <Button type="button" onClick={addEquipment} variant="outline">
                Add
              </Button>
            </div>
            <div className="flex flex-wrap gap-2 mt-2">
              {equipment.map((item, index) => (
                <Badge key={index} variant="secondary" className="bg-blue-100 text-blue-800">
                  {item}
                  <button
                    type="button"
                    onClick={() => removeEquipment(index)}
                    className="ml-1 hover:text-blue-600"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </Badge>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="progression_notes">Progression Notes</Label>
              <Textarea
                id="progression_notes"
                value={formData.progression_notes}
                onChange={(e) => handleInputChange('progression_notes', e.target.value)}
                placeholder="How to progress this exercise over time..."
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="safety_notes">Safety Notes</Label>
              <Textarea
                id="safety_notes"
                value={formData.safety_notes}
                onChange={(e) => handleInputChange('safety_notes', e.target.value)}
                placeholder="Safety considerations and modifications..."
                rows={3}
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-6">
            <Button
              type="button"
              variant="outline"
              onClick={onCancel}
              disabled={loading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={loading || !formData.exercise_type || !formData.exercise_name}
              className="bg-orange-600 hover:bg-orange-700"
            >
              {loading ? "Creating..." : "Create Exercise Plan"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}