
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LifestylePlan, Goal, NutritionPlan, ExercisePlan } from "@/api/entities";
import { User } from "@/api/entities";
import { 
  Heart, 
  Target, 
  Apple, 
  Dumbbell, 
  Plus, 
  Calendar,
  TrendingUp,
  CheckCircle2,
  Clock,
  AlertCircle
} from "lucide-react";
import { format } from "date-fns";
import { InvokeLLM } from "@/api/integrations";

import LifestylePlanModal from "./LifestylePlanModal";
import GoalModal from "./GoalModal";
import NutritionModal from "./NutritionModal";
import ExerciseModal from "./ExerciseModal";

export default function LifestylePlanPanel({ patientId, patient }) {
  const [plans, setPlans] = useState([]);
  const [activePlan, setActivePlan] = useState(null);
  const [goals, setGoals] = useState([]);
  const [nutritionPlans, setNutritionPlans] = useState([]);
  const [exercisePlans, setExercisePlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);

  // State for AI Goal Suggestions
  const [aiGoalSuggestions, setAiGoalSuggestions] = useState({ goals: [] });
  const [isAiGoalsLoading, setIsAiGoalsLoading] = useState(false);

  // Modal states
  const [showPlanModal, setShowPlanModal] = useState(false);
  const [showGoalModal, setShowGoalModal] = useState(false);
  const [showNutritionModal, setShowNutritionModal] = useState(false);
  const [showExerciseModal, setShowExerciseModal] = useState(false);

  useEffect(() => {
    loadData();
    loadCurrentUser();
  }, [patientId]);

  const loadCurrentUser = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
    } catch (error) {
      console.error("Error loading current user:", error);
    }
  };

  const loadData = async () => {
    try {
      const [plansData, goalsData, nutritionData, exerciseData] = await Promise.all([
        LifestylePlan.filter({ patient_id: patientId }, "-created_date"),
        Goal.filter({ patient_id: patientId }, "-created_date"),
        NutritionPlan.filter({ patient_id: patientId }),
        ExercisePlan.filter({ patient_id: patientId })
      ]);

      setPlans(plansData);
      const active = plansData.find(p => p.status === 'Active') || plansData[0];
      setActivePlan(active);
      setGoals(goalsData);
      setNutritionPlans(nutritionData);
      setExercisePlans(exerciseData);
    } catch (error) {
      console.error("Error loading lifestyle data:", error);
      // Generate sample data
      generateSampleData();
    }
    setLoading(false);
  };

  const generateSampleData = () => {
    const samplePlan = {
      id: 'sample-1',
      plan_name: 'GLP-1 Weight Management Plan',
      description: 'Comprehensive lifestyle plan to support GLP-1 therapy',
      status: 'Active',
      target_weight_kg: 75,
      target_hba1c: 6.5
    };
    setPlans([samplePlan]);
    setActivePlan(samplePlan);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Active':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Achieved':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'In Progress':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Missed':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'Achieved':
        return <CheckCircle2 className="w-4 h-4" />;
      case 'In Progress':
        return <Clock className="w-4 h-4" />;
      case 'Missed':
        return <AlertCircle className="w-4 h-4" />;
      default:
        return <Target className="w-4 h-4" />;
    }
  };

  const generateAIGoalsForModal = async () => {
    if (!patient || !currentUser) return;
    
    setIsAiGoalsLoading(true);
    setAiGoalSuggestions({ goals: [] }); // Clear previous suggestions
    
    try {
      const patientInfo = `
Patient: ${patient.first_name} ${patient.last_name}
Age: ${patient.date_of_birth ? new Date().getFullYear() - new Date(patient.date_of_birth).getFullYear() : 'Unknown'}
Primary Condition: ${patient.primary_condition}
Height: ${patient.height_cm ? `${patient.height_cm}cm` : 'Not specified'}
      `.trim();

      const prompt = `
As CarePlix AI, create specific, measurable goals for this patient's lifestyle plan.

${patientInfo}

Generate 3-5 SMART goals (Specific, Measurable, Achievable, Relevant, Time-bound) that would support their GLP-1 therapy and condition management. Consider:

1. Weight management goals
2. Exercise/activity goals  
3. Nutrition goals
4. Medication adherence goals
5. Lab value improvement goals

For each goal, provide:
- Goal type (Weight Loss, Exercise, Nutrition, Medication Adherence, Lab Values, or Custom)
- Clear, specific title
- Detailed description
- Target value (numeric where applicable)
- Appropriate unit of measurement
- Realistic timeframe
- Priority level
- Tracking frequency

Make goals realistic and achievable for this patient's condition and profile.
      `;

      const response = await InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: "object",
          properties: {
            goals: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  goal_type: {
                    type: "string",
                    enum: ["Weight Loss", "Exercise", "Nutrition", "Medication Adherence", "Lab Values", "Custom"]
                  },
                  title: {
                    type: "string",
                    description: "Clear, specific goal title"
                  },
                  description: {
                    type: "string",
                    description: "Detailed goal description"
                  },
                  target_value: {
                    type: "number",
                    description: "Numeric target value"
                  },
                  target_unit: {
                    type: "string",
                    description: "Unit of measurement"
                  },
                  target_date: {
                    type: "string",
                    description: "Target completion date (weeks from now, e.g., '8 weeks', '3 months')"
                  },
                  priority: {
                    type: "string",
                    enum: ["Low", "Medium", "High"]
                  },
                  frequency: {
                    type: "string",
                    enum: ["Daily", "Weekly", "Monthly", "One-time"]
                  }
                },
                required: ["goal_type", "title", "description"]
              }
            }
          }
        }
      });

      setAiGoalSuggestions(response);
      
    } catch (error) {
      console.error("Error generating AI goals:", error);
    }
    setIsAiGoalsLoading(false);
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Loading lifestyle plans...</CardTitle>
        </CardHeader>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Active Plan Header */}
      <Card className="border-slate-200">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-blue-600 rounded-lg flex items-center justify-center">
                <Heart className="w-5 h-5 text-white" />
              </div>
              <div>
                <CardTitle className="text-xl font-semibold text-slate-900">
                  {activePlan ? activePlan.plan_name : 'No Active Plan'}
                </CardTitle>
                <p className="text-slate-600">
                  {activePlan ? activePlan.description : 'Create a lifestyle plan to get started'}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {activePlan && (
                <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                  {activePlan.status}
                </Badge>
              )}
              <Button 
                onClick={() => setShowPlanModal(true)}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                {activePlan ? 'Edit Plan' : 'Create Plan'}
              </Button>
            </div>
          </div>
        </CardHeader>

        {activePlan && (
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="p-4 bg-blue-50 rounded-lg">
                <p className="text-sm font-medium text-blue-800">Target Weight</p>
                <p className="text-2xl font-bold text-blue-900">
                  {activePlan.target_weight_kg || '--'} kg
                </p>
              </div>
              <div className="p-4 bg-purple-50 rounded-lg">
                <p className="text-sm font-medium text-purple-800">Target HbA1c</p>
                <p className="text-2xl font-bold text-purple-900">
                  {activePlan.target_hba1c || '--'}%
                </p>
              </div>
              <div className="p-4 bg-green-50 rounded-lg">
                <p className="text-sm font-medium text-green-800">Active Goals</p>
                <p className="text-2xl font-bold text-green-900">
                  {goals.filter(g => g.status === 'In Progress').length}
                </p>
              </div>
              <div className="p-4 bg-orange-50 rounded-lg">
                <p className="text-sm font-medium text-orange-800">Achieved Goals</p>
                <p className="text-2xl font-bold text-orange-900">
                  {goals.filter(g => g.status === 'Achieved').length}
                </p>
              </div>
            </div>
          </CardContent>
        )}
      </Card>

      {/* Lifestyle Plan Tabs */}
      {activePlan && (
        <Tabs defaultValue="goals" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 bg-slate-100">
            <TabsTrigger value="goals" className="data-[state=active]:bg-white">
              Goals & Targets
            </TabsTrigger>
            <TabsTrigger value="nutrition" className="data-[state=active]:bg-white">
              Nutrition Plan
            </TabsTrigger>
            <TabsTrigger value="exercise" className="data-[state=active]:bg-white">
              Exercise Plan
            </TabsTrigger>
          </TabsList>

          <TabsContent value="goals" className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-slate-900">Patient Goals</h3>
              <Button 
                onClick={() => setShowGoalModal(true)}
                size="sm"
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Goal
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {goals.length > 0 ? (
                goals.map((goal) => (
                  <Card key={goal.id} className="border-slate-200">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h4 className="font-medium text-slate-900">{goal.title}</h4>
                          <p className="text-sm text-slate-600">{goal.description}</p>
                        </div>
                        <Badge 
                          variant="outline" 
                          className={`${getStatusColor(goal.status)} border flex items-center gap-1`}
                        >
                          {getStatusIcon(goal.status)}
                          {goal.status}
                        </Badge>
                      </div>
                      
                      {goal.target_value && (
                        <div className="mb-3">
                          <div className="flex justify-between text-sm text-slate-600 mb-1">
                            <span>Progress</span>
                            <span>{goal.current_value || 0} / {goal.target_value} {goal.target_unit}</span>
                          </div>
                          <div className="w-full bg-slate-200 rounded-full h-2">
                            <div 
                              className="bg-blue-600 h-2 rounded-full"
                              style={{ 
                                width: `${Math.min(((goal.current_value || 0) / goal.target_value) * 100, 100)}%` 
                              }}
                            />
                          </div>
                        </div>
                      )}

                      <div className="flex justify-between items-center text-sm text-slate-500">
                        <Badge variant="secondary" className="text-xs">
                          {goal.goal_type}
                        </Badge>
                        {goal.target_date && (
                          <div className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {format(new Date(goal.target_date), "MMM d, yyyy")}
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="col-span-2 text-center py-8">
                  <Target className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-500">No goals set for this patient.</p>
                  <Button 
                    variant="outline" 
                    className="mt-4"
                    onClick={() => setShowGoalModal(true)}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add First Goal
                  </Button>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="nutrition" className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-slate-900">Nutrition Guidelines</h3>
              <Button 
                onClick={() => setShowNutritionModal(true)}
                size="sm"
                className="bg-green-600 hover:bg-green-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Nutrition Plan
              </Button>
            </div>

            <div className="space-y-4">
              {nutritionPlans.length > 0 ? (
                nutritionPlans.map((plan) => (
                  <Card key={plan.id} className="border-slate-200">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                            <Apple className="w-4 h-4 text-green-600" />
                          </div>
                          <div>
                            <h4 className="font-medium text-slate-900">{plan.title}</h4>
                            <Badge variant="secondary" className="text-xs mt-1">
                              {plan.meal_type}
                            </Badge>
                          </div>
                        </div>
                        {plan.calories_target && (
                          <div className="text-right">
                            <p className="text-sm font-medium text-slate-900">{plan.calories_target} cal</p>
                            {plan.protein_grams && (
                              <p className="text-xs text-slate-500">
                                P: {plan.protein_grams}g | C: {plan.carbs_grams}g | F: {plan.fat_grams}g
                              </p>
                            )}
                          </div>
                        )}
                      </div>
                      
                      <p className="text-sm text-slate-600 mb-3">{plan.description}</p>
                      
                      {plan.food_suggestions && plan.food_suggestions.length > 0 && (
                        <div className="mb-2">
                          <p className="text-xs font-medium text-slate-700 mb-1">Recommended:</p>
                          <div className="flex flex-wrap gap-1">
                            {plan.food_suggestions.slice(0, 3).map((food, index) => (
                              <Badge key={index} variant="outline" className="text-xs bg-green-50 text-green-700">
                                {food}
                              </Badge>
                            ))}
                            {plan.food_suggestions.length > 3 && (
                              <Badge variant="outline" className="text-xs">
                                +{plan.food_suggestions.length - 3} more
                              </Badge>
                            )}
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="text-center py-8">
                  <Apple className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-500">No nutrition plans created for this patient.</p>
                  <Button 
                    variant="outline" 
                    className="mt-4"
                    onClick={() => setShowNutritionModal(true)}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Create Nutrition Plan
                  </Button>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="exercise" className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-slate-900">Exercise Program</h3>
              <Button 
                onClick={() => setShowExerciseModal(true)}
                size="sm"
                className="bg-orange-600 hover:bg-orange-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Exercise
              </Button>
            </div>

            <div className="space-y-4">
              {exercisePlans.length > 0 ? (
                exercisePlans.map((exercise) => (
                  <Card key={exercise.id} className="border-slate-200">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center">
                            <Dumbbell className="w-4 h-4 text-orange-600" />
                          </div>
                          <div>
                            <h4 className="font-medium text-slate-900">{exercise.exercise_name}</h4>
                            <div className="flex items-center gap-2 mt-1">
                              <Badge variant="secondary" className="text-xs">
                                {exercise.exercise_type}
                              </Badge>
                              <Badge variant="outline" className="text-xs">
                                {exercise.intensity_level} Intensity
                              </Badge>
                            </div>
                          </div>
                        </div>
                        <div className="text-right text-sm">
                          {exercise.duration_minutes && (
                            <p className="font-medium text-slate-900">{exercise.duration_minutes} min</p>
                          )}
                          {exercise.frequency_per_week && (
                            <p className="text-slate-500">{exercise.frequency_per_week}x/week</p>
                          )}
                        </div>
                      </div>
                      
                      <p className="text-sm text-slate-600 mb-3">{exercise.description}</p>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                        {exercise.sets && (
                          <div>
                            <span className="text-slate-500">Sets:</span>
                            <span className="ml-1 font-medium">{exercise.sets}</span>
                          </div>
                        )}
                        {exercise.reps && (
                          <div>
                            <span className="text-slate-500">Reps:</span>
                            <span className="ml-1 font-medium">{exercise.reps}</span>
                          </div>
                        )}
                        {exercise.weight_kg && (
                          <div>
                            <span className="text-slate-500">Weight:</span>
                            <span className="ml-1 font-medium">{exercise.weight_kg}kg</span>
                          </div>
                        )}
                        {exercise.target_heart_rate && (
                          <div>
                            <span className="text-slate-500">Target HR:</span>
                            <span className="ml-1 font-medium">{exercise.target_heart_rate} bpm</span>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="text-center py-8">
                  <Dumbbell className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-500">No exercise plans created for this patient.</p>
                  <Button 
                    variant="outline" 
                    className="mt-4"
                    onClick={() => setShowExerciseModal(true)}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Create Exercise Plan
                  </Button>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      )}

      {/* Modals */}
      {showPlanModal && (
        <LifestylePlanModal 
          patient={patient}
          plan={activePlan}
          onSave={() => {
            setShowPlanModal(false);
            loadData();
          }}
          onCancel={() => setShowPlanModal(false)}
        />
      )}

      {showGoalModal && (
        <GoalModal 
          patient={patient}
          lifestylePlanId={activePlan?.id}
          aiSuggestions={aiGoalSuggestions}
          isGeneratingSuggestions={isAiGoalsLoading}
          onGenerateSuggestions={generateAIGoalsForModal}
          onSave={() => {
            setShowGoalModal(false);
            loadData();
          }}
          onCancel={() => setShowGoalModal(false)}
        />
      )}

      {showNutritionModal && (
        <NutritionModal 
          patient={patient}
          lifestylePlanId={activePlan?.id}
          onSave={() => {
            setShowNutritionModal(false);
            loadData();
          }}
          onCancel={() => setShowNutritionModal(false)}
        />
      )}

      {showExerciseModal && (
        <ExerciseModal 
          patient={patient}
          lifestylePlanId={activePlan?.id}
          onSave={() => {
            setShowExerciseModal(false);
            loadData();
          }}
          onCancel={() => setShowExerciseModal(false)}
        />
      )}
    </div>
  );
}
