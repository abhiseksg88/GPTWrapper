import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { VitalRecord } from "@/api/entities";

export default function VitalsChart({ patientId }) {
  const [vitalsData, setVitalsData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadVitalsData();
  }, [patientId]);

  const loadVitalsData = async () => {
    try {
      const data = await VitalRecord.filter({ patient_id: patientId }, "-recorded_date");
      setVitalsData(data);
    } catch (error) {
      console.error("Error loading vitals data:", error);
      // Generate sample data for demonstration
      const sampleData = generateSampleVitalsData();
      setVitalsData(sampleData);
    }
    setLoading(false);
  };

  const generateSampleVitalsData = () => {
    const data = [];
    for (let i = 12; i >= 0; i--) {
      const date = new Date();
      date.setMonth(date.getMonth() - i);
      data.push({
        recorded_date: date.toISOString().split('T')[0],
        weight_kg: 95 - (i * 1.2) + (Math.random() * 2 - 1),
        bmi: 32 - (i * 0.4) + (Math.random() * 0.5 - 0.25),
        systolic_bp: 140 - (i * 2) + (Math.random() * 10 - 5),
        diastolic_bp: 90 - (i * 1) + (Math.random() * 5 - 2.5)
      });
    }
    return data;
  };

  if (loading) {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Loading vitals data...</CardTitle>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-900">Weight Trend</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={vitalsData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="recorded_date" stroke="#64748b" />
              <YAxis stroke="#64748b" />
              <Tooltip 
                contentStyle={{
                  backgroundColor: '#ffffff',
                  border: '1px solid #e2e8f0',
                  borderRadius: '8px'
                }}
              />
              <Line 
                type="monotone" 
                dataKey="weight_kg" 
                stroke="#2563eb" 
                strokeWidth={2}
                dot={{ fill: '#2563eb', strokeWidth: 2, r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-900">BMI Progress</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={vitalsData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="recorded_date" stroke="#64748b" />
              <YAxis stroke="#64748b" />
              <Tooltip 
                contentStyle={{
                  backgroundColor: '#ffffff',
                  border: '1px solid #e2e8f0',
                  borderRadius: '8px'
                }}
              />
              <Line 
                type="monotone" 
                dataKey="bmi" 
                stroke="#059669" 
                strokeWidth={2}
                dot={{ fill: '#059669', strokeWidth: 2, r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card className="border-slate-200 lg:col-span-2">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-900">Blood Pressure</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={vitalsData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="recorded_date" stroke="#64748b" />
              <YAxis stroke="#64748b" />
              <Tooltip 
                contentStyle={{
                  backgroundColor: '#ffffff',
                  border: '1px solid #e2e8f0',
                  borderRadius: '8px'
                }}
              />
              <Line 
                type="monotone" 
                dataKey="systolic_bp" 
                stroke="#dc2626" 
                strokeWidth={2}
                name="Systolic"
                dot={{ fill: '#dc2626', strokeWidth: 2, r: 4 }}
              />
              <Line 
                type="monotone" 
                dataKey="diastolic_bp" 
                stroke="#7c2d12" 
                strokeWidth={2}
                name="Diastolic"
                dot={{ fill: '#7c2d12', strokeWidth: 2, r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}