import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Procedure } from "@/api/entities";
import ProcedureModal from "./ProcedureModal";
import { Stethoscope, Plus, Calendar, Edit } from "lucide-react";
import { format } from "date-fns";

export default function ProcedurePanel({ patientId }) {
  const [procedures, setProcedures] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [selectedProcedure, setSelectedProcedure] = useState(null);

  useEffect(() => {
    loadProcedures();
  }, [patientId]);

  const loadProcedures = async () => {
    setLoading(true);
    try {
      const data = await Procedure.filter({ patient_id: patientId }, "-scheduled_date");
      setProcedures(data);
    } catch (error) {
      console.error("Error loading procedures:", error);
    }
    setLoading(false);
  };

  const handleOpenModal = (procedure = null) => {
    setSelectedProcedure(procedure);
    setShowModal(true);
  };

  const handleSave = () => {
    setShowModal(false);
    setSelectedProcedure(null);
    loadProcedures();
  };

  const getStatusColor = (status) => {
    const colors = {
      Planned: 'bg-gray-100 text-gray-800',
      Scheduled: 'bg-blue-100 text-blue-800',
      Completed: 'bg-green-100 text-green-800',
      Cancelled: 'bg-red-100 text-red-800',
      Postponed: 'bg-yellow-100 text-yellow-800',
    };
    return colors[status] || 'bg-gray-100 text-gray-800';
  };

  if (loading) return <p>Loading procedures...</p>;

  return (
    <div className="space-y-6">
      <Card className="border-slate-200">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Stethoscope className="w-5 h-5 text-blue-600" />
              Procedures
            </CardTitle>
            <Button onClick={() => handleOpenModal()} size="sm" className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Schedule New Procedure
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {procedures.length > 0 ? (
            <div className="space-y-4">
              {procedures.map((proc) => (
                <div key={proc.id} className="p-4 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-semibold text-slate-900">{proc.procedure_name}</h4>
                      <p className="text-sm text-slate-600">{proc.category}</p>
                      <div className="flex items-center gap-2 mt-2">
                         <Badge variant="secondary" className={`${getStatusColor(proc.status)} text-xs`}>{proc.status}</Badge>
                         {proc.scheduled_date && <p className="text-xs text-slate-500 flex items-center gap-1"><Calendar className="w-3 h-3" /> Scheduled: {format(new Date(proc.scheduled_date), 'MMM d, yyyy')}</p>}
                      </div>
                    </div>
                     <Button variant="ghost" size="icon" onClick={() => handleOpenModal(proc)}>
                        <Edit className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="mt-3 space-y-1 text-sm">
                    <p><strong>Reason:</strong> {proc.reason}</p>
                    {proc.notes && <p><strong>Notes:</strong> {proc.notes}</p>}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Stethoscope className="w-12 h-12 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-500">No procedures have been scheduled for this patient.</p>
            </div>
          )}
        </CardContent>
      </Card>
      {showModal && (
        <ProcedureModal
          patient={{id: patientId}}
          procedure={selectedProcedure}
          onSave={handleSave}
          onCancel={() => setShowModal(false)}
        />
      )}
    </div>
  );
}