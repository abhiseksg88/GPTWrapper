import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Goal } from "@/api/entities";
import { User } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Target, Brain, Loader2, Sparkles, Copy, CheckCircle, Plus } from "lucide-react";

export default function GoalModal({ 
  patient, 
  lifestylePlanId, 
  goal, 
  onSave, 
  onCancel,
  aiSuggestions,
  isGeneratingSuggestions,
  onGenerateSuggestions
}) {
  const [activeTab, setActiveTab] = useState("manual");
  const [formData, setFormData] = useState({
    goal_type: goal?.goal_type || 'Weight Loss',
    title: goal?.title || '',
    description: goal?.description || '',
    target_value: goal?.target_value || '',
    target_unit: goal?.target_unit || '',
    target_date: goal?.target_date || '',
    current_value: goal?.current_value || '',
    status: goal?.status || 'Not Started',
    priority: goal?.priority || 'Medium',
    frequency: goal?.frequency || 'Weekly'
  });

  const [selectedGoals, setSelectedGoals] = useState(new Set());
  const [loading, setLoading] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const user = await User.me();
        setCurrentUser(user);
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();
  }, []);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleManualSubmit = async (e) => {
    e.preventDefault();
    if (!currentUser) return;

    setLoading(true);
    
    try {
      const goalData = {
        ...formData,
        patient_id: patient.id,
        lifestyle_plan_id: lifestylePlanId,
        target_value: formData.target_value ? parseFloat(formData.target_value) : undefined,
        current_value: formData.current_value ? parseFloat(formData.current_value) : undefined
      };
      
      if (goal) {
        await Goal.update(goal.id, goalData);
      } else {
        await Goal.create(goalData);
      }
      onSave();
    } catch (error) {
      console.error("Error saving goal:", error);
    }
    
    setLoading(false);
  };
  
  const handleAIGoalSelect = (index) => {
    const newSelectedGoals = new Set(selectedGoals);
    if (newSelectedGoals.has(index)) {
      newSelectedGoals.delete(index);
    } else {
      newSelectedGoals.add(index);
    }
    setSelectedGoals(newSelectedGoals);
  };

  const handleAddSelectedAIGoals = async () => {
    if (selectedGoals.size === 0) return;

    setLoading(true);
    const goalsToCreate = [];
    const createdDate = new Date();

    selectedGoals.forEach(index => {
      const aiGoal = aiSuggestions.goals[index];
      let targetDate = new Date();
      if (aiGoal.target_date) {
        const [value, unit] = aiGoal.target_date.split(' ');
        if (unit.startsWith('week')) {
          targetDate.setDate(createdDate.getDate() + parseInt(value) * 7);
        } else if (unit.startsWith('month')) {
          targetDate.setMonth(createdDate.getMonth() + parseInt(value));
        }
      }

      goalsToCreate.push({
        patient_id: patient.id,
        lifestyle_plan_id: lifestylePlanId,
        goal_type: aiGoal.goal_type,
        title: aiGoal.title,
        description: aiGoal.description,
        target_value: aiGoal.target_value,
        target_unit: aiGoal.target_unit,
        target_date: targetDate.toISOString().split('T')[0],
        status: 'In Progress',
        priority: aiGoal.priority,
        frequency: aiGoal.frequency
      });
    });

    try {
      await Goal.bulkCreate(goalsToCreate);
      onSave();
    } catch (error) {
      console.error("Error creating goals in bulk:", error);
    }

    setLoading(false);
  };

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold text-slate-900 flex items-center gap-2">
            <Target className="w-6 h-6 text-blue-600" />
            {goal ? 'Edit Goal' : 'Add New Goal'}
          </DialogTitle>
        </DialogHeader>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="manual">Manual Entry</TabsTrigger>
            <TabsTrigger value="ai_assisted">
              <Sparkles className="w-4 h-4 mr-2" />
              Assisted with CarePlix AI
            </TabsTrigger>
          </TabsList>

          <TabsContent value="manual" className="mt-6">
            <form onSubmit={handleManualSubmit} className="space-y-6">
              {/* ... The existing manual form ... */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Goal Title *</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => handleInputChange('title', e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="goal_type">Goal Type *</Label>
                  <Select
                    value={formData.goal_type}
                    onValueChange={(value) => handleInputChange('goal_type', value)}
                  >
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Weight Loss">Weight Loss</SelectItem>
                      <SelectItem value="Exercise">Exercise</SelectItem>
                      <SelectItem value="Nutrition">Nutrition</SelectItem>
                      <SelectItem value="Medication Adherence">Medication Adherence</SelectItem>
                      <SelectItem value="Lab Values">Lab Values</SelectItem>
                      <SelectItem value="Custom">Custom</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="target_value">Target Value</Label>
                  <Input
                    id="target_value"
                    type="number"
                    value={formData.target_value}
                    onChange={(e) => handleInputChange('target_value', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="target_unit">Unit</Label>
                  <Input
                    id="target_unit"
                    value={formData.target_unit}
                    onChange={(e) => handleInputChange('target_unit', e.target.value)}
                    placeholder="e.g., kg, steps, minutes"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="target_date">Target Date</Label>
                  <Input
                    id="target_date"
                    type="date"
                    value={formData.target_date}
                    onChange={(e) => handleInputChange('target_date', e.target.value)}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select
                    value={formData.status}
                    onValueChange={(value) => handleInputChange('status', value)}
                  >
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Not Started">Not Started</SelectItem>
                      <SelectItem value="In Progress">In Progress</SelectItem>
                      <SelectItem value="Achieved">Achieved</SelectItem>
                      <SelectItem value="Missed">Missed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="priority">Priority</Label>
                  <Select
                    value={formData.priority}
                    onValueChange={(value) => handleInputChange('priority', value)}
                  >
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Low">Low</SelectItem>
                      <SelectItem value="Medium">Medium</SelectItem>
                      <SelectItem value="High">High</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-6">
                <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
                <Button type="submit" disabled={loading} className="bg-blue-600 hover:bg-blue-700">
                  {loading ? 'Saving...' : 'Save Goal'}
                </Button>
              </div>
            </form>
          </TabsContent>
          
          <TabsContent value="ai_assisted" className="mt-6">
            <div className="text-center p-4 bg-blue-50 border border-blue-200 rounded-lg mb-6">
              <h3 className="text-lg font-semibold text-blue-900">AI-Powered Goal Setting</h3>
              <p className="text-sm text-blue-700">
                Let CarePlix AI suggest SMART goals tailored to this patient's profile. Review, select, and add them to the plan with one click.
              </p>
            </div>
            
            {isGeneratingSuggestions && (
              <div className="flex flex-col items-center justify-center h-64">
                <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
                <p className="mt-4 text-slate-600">CarePlix AI is generating goals...</p>
              </div>
            )}

            {!isGeneratingSuggestions && aiSuggestions.goals.length === 0 && (
              <div className="text-center h-64 flex flex-col items-center justify-center">
                <Brain className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-500 mb-4">Click below to generate personalized goals for the patient.</p>
                <Button onClick={onGenerateSuggestions} className="bg-blue-600 hover:bg-blue-700">
                  <Sparkles className="w-4 h-4 mr-2" />
                  Generate Suggestions
                </Button>
              </div>
            )}

            {!isGeneratingSuggestions && aiSuggestions.goals.length > 0 && (
              <div className="space-y-4">
                <div className="flex justify-between items-center mb-4">
                  <h4 className="text-md font-semibold text-slate-800">Select goals to add to the plan:</h4>
                  <Button onClick={onGenerateSuggestions} variant="outline" size="sm">
                    <Sparkles className="w-4 h-4 mr-2" />
                    Regenerate
                  </Button>
                </div>
                
                {aiSuggestions.goals.map((aiGoal, index) => (
                  <Card key={index} className="transition-all hover:shadow-md">
                    <CardContent className="p-4 flex items-start gap-4">
                      <Checkbox 
                        id={`goal-${index}`}
                        checked={selectedGoals.has(index)}
                        onCheckedChange={() => handleAIGoalSelect(index)}
                        className="mt-1"
                      />
                      <div className="flex-1">
                        <Label htmlFor={`goal-${index}`} className="font-semibold text-slate-900 cursor-pointer">
                          {aiGoal.title}
                        </Label>
                        <p className="text-sm text-slate-600 mt-1">{aiGoal.description}</p>
                        <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2 text-xs">
                          <Badge variant="secondary">{aiGoal.goal_type}</Badge>
                          <Badge variant="outline">Target: {aiGoal.target_value} {aiGoal.target_unit}</Badge>
                          <Badge variant="outline">Timeframe: {aiGoal.target_date}</Badge>
                          <Badge variant="outline">Priority: {aiGoal.priority}</Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}

                <div className="flex justify-end pt-6">
                  <Button 
                    onClick={handleAddSelectedAIGoals}
                    disabled={selectedGoals.size === 0 || loading}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    {loading ? (
                      <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Adding...</>
                    ) : (
                      <><Plus className="w-4 h-4 mr-2" /> Add {selectedGoals.size} Selected Goals</>
                    )}
                  </Button>
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}