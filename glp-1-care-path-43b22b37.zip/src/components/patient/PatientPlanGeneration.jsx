import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { InvokeLLM } from "@/api/integrations";
import { Brain, Loader2, FileText, Download, X, Activity, FlaskConical, Stethoscope } from 'lucide-react';
import { format } from 'date-fns';

export default function PatientPlanGeneration({ patient, patientData, patientStats, onClose }) {
  const [loading, setLoading] = useState(false);
  const [generatedPlan, setGeneratedPlan] = useState(null);
  const [customPrompt, setCustomPrompt] = useState('');
  const [error, setError] = useState(null);

  const generateComprehensivePlan = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // Prepare comprehensive patient data including diagnostics and procedures
      const comprehensiveData = {
        patient_info: {
          name: `${patient.first_name} ${patient.last_name}`,
          age: patient.date_of_birth ? new Date().getFullYear() - new Date(patient.date_of_birth).getFullYear() : 'Unknown',
          gender: patient.gender || 'Not specified',
          height: patient.height_cm ? `${patient.height_cm}cm` : 'Not recorded',
          primary_condition: patient.primary_condition,
          assigned_clinician: patient.assigned_clinician
        },
        current_stats: patientStats || {},
        clinical_data: {
          vitals: patientData.vitals?.map(v => ({
            date: v.recorded_date,
            weight: v.weight_kg ? `${v.weight_kg}kg` : null,
            bp: v.systolic_bp && v.diastolic_bp ? `${v.systolic_bp}/${v.diastolic_bp}` : null,
            bmi: v.bmi
          })) || [],
          lab_results: patientData.labResults?.map(l => ({
            date: l.test_date,
            hba1c: l.hba1c ? `${l.hba1c}%` : null,
            fasting_glucose: l.fasting_glucose ? `${l.fasting_glucose} mg/dL` : null,
            cholesterol: l.total_cholesterol ? `${l.total_cholesterol} mg/dL` : null,
            ldl: l.ldl_cholesterol ? `${l.ldl_cholesterol} mg/dL` : null,
            hdl: l.hdl_cholesterol ? `${l.hdl_cholesterol} mg/dL` : null
          })) || [],
          prescriptions: patientData.prescriptions?.map(p => ({
            medication: p.medication_name,
            dosage: p.dosage,
            frequency: p.frequency,
            status: p.status,
            start_date: p.start_date,
            instructions: p.instructions
          })) || [],
          diagnostic_tests: patientData.diagnosticTests?.map(dt => ({
            test_name: dt.test_name,
            category: dt.category,
            reason: dt.reason,
            status: dt.status,
            order_date: dt.order_date,
            completion_date: dt.completion_date,
            results_summary: dt.results_summary
          })) || [],
          procedures: patientData.procedures?.map(proc => ({
            procedure_name: proc.procedure_name,
            category: proc.category,
            reason: proc.reason,
            status: proc.status,
            scheduled_date: proc.scheduled_date,
            completion_date: proc.completion_date,
            notes: proc.notes
          })) || [],
          adherence_records: patientData.adherenceRecords?.map(ar => ({
            date: ar.dose_date,
            taken: ar.dose_taken,
            method: ar.recorded_method
          })) || [],
          side_effects: patientData.sideEffects?.map(se => ({
            type: se.effect_type,
            severity: se.severity,
            onset_date: se.onset_date,
            resolution_date: se.resolution_date,
            notes: se.notes
          })) || [],
          clinical_notes: patientData.clinicalNotes?.map(cn => ({
            type: cn.note_type,
            content: cn.content,
            date: cn.created_date,
            priority: cn.priority,
            clinician: cn.clinician
          })) || [],
          lifestyle_plans: patientData.lifestylePlans?.map(lp => ({
            plan_name: lp.plan_name,
            description: lp.description,
            status: lp.status,
            start_date: lp.start_date,
            target_weight: lp.target_weight_kg,
            target_hba1c: lp.target_hba1c
          })) || []
        }
      };

      const prompt = `
        You are an expert clinical care coordinator creating a comprehensive care management plan for a GLP-1 therapy patient.
        
        Patient Information:
        - Name: ${comprehensiveData.patient_info.name}
        - Age: ${comprehensiveData.patient_info.age}
        - Gender: ${comprehensiveData.patient_info.gender}
        - Height: ${comprehensiveData.patient_info.height}
        - Primary Condition: ${comprehensiveData.patient_info.primary_condition}
        - Assigned Clinician: ${comprehensiveData.patient_info.assigned_clinician}
        
        Current Clinical Status:
        - Current Weight: ${patientStats?.currentWeight || 'Not recorded'} kg
        - BMI: ${patientStats?.bmi || 'Not calculated'}
        - Latest HbA1c: ${patientStats?.lastHbA1c || 'Not available'}%
        - Adherence Rate: ${patientStats?.adherenceRate || 'Not tracked'}%
        - Active Prescriptions: ${patientStats?.activePrescriptions || 0}
        
        Clinical Data Summary:
        - Vitals Records: ${comprehensiveData.clinical_data.vitals.length} entries
        - Lab Results: ${comprehensiveData.clinical_data.lab_results.length} results
        - Current Medications: ${comprehensiveData.clinical_data.prescriptions.length} prescriptions
        - Diagnostic Tests: ${comprehensiveData.clinical_data.diagnostic_tests.length} tests (${comprehensiveData.clinical_data.diagnostic_tests.filter(dt => dt.status === 'Completed').length} completed)
        - Procedures: ${comprehensiveData.clinical_data.procedures.length} procedures (${comprehensiveData.clinical_data.procedures.filter(p => p.status === 'Completed').length} completed)
        - Adherence Records: ${comprehensiveData.clinical_data.adherence_records.length} records
        - Side Effects: ${comprehensiveData.clinical_data.side_effects.length} reported
        - Clinical Notes: ${comprehensiveData.clinical_data.clinical_notes.length} notes
        - Lifestyle Plans: ${comprehensiveData.clinical_data.lifestyle_plans.length} active plans
        
        Recent Diagnostic Tests:
        ${comprehensiveData.clinical_data.diagnostic_tests.slice(0, 5).map(dt => 
          `- ${dt.test_name} (${dt.category}): ${dt.status} - ${dt.reason} ${dt.results_summary ? '| Results: ' + dt.results_summary : ''}`
        ).join('\n')}
        
        Recent Procedures:
        ${comprehensiveData.clinical_data.procedures.slice(0, 5).map(proc => 
          `- ${proc.procedure_name} (${proc.category}): ${proc.status} - ${proc.reason} ${proc.notes ? '| Notes: ' + proc.notes : ''}`
        ).join('\n')}
        
        Recent Clinical Notes:
        ${comprehensiveData.clinical_data.clinical_notes.slice(0, 3).map(cn => 
          `- [${cn.type}] ${cn.content.substring(0, 200)}...`
        ).join('\n')}
        
        Side Effects History:
        ${comprehensiveData.clinical_data.side_effects.map(se => 
          `- ${se.type} (${se.severity}) - Onset: ${se.onset_date} ${se.resolution_date ? '| Resolved: ' + se.resolution_date : '| Ongoing'}`
        ).join('\n')}
        
        ${customPrompt ? `Additional Instructions: ${customPrompt}` : ''}
        
        Based on this comprehensive clinical data, create a detailed care management plan that includes:
        1. Current Health Status Assessment
        2. Treatment Progress Evaluation
        3. Medication Management Recommendations
        4. Lifestyle and Behavioral Interventions
        5. Monitoring and Follow-up Schedule
        6. Diagnostic Test Recommendations
        7. Procedure Planning (if needed)
        8. Risk Factor Management
        9. Patient Education Priorities
        10. Goals and Milestones
        
        Make the plan actionable, evidence-based, and personalized to this patient's specific clinical picture, including their diagnostic history and procedures.
      `;

      const response_json_schema = {
        type: "object",
        properties: {
          plan_title: { type: "string" },
          assessment_summary: { type: "string" },
          current_status: {
            type: "object",
            properties: {
              overall_progress: { type: "string" },
              key_achievements: { type: "array", items: { type: "string" } },
              areas_of_concern: { type: "array", items: { type: "string" } }
            }
          },
          medication_management: {
            type: "object",
            properties: {
              current_regimen_assessment: { type: "string" },
              recommendations: { type: "array", items: { type: "string" } },
              adherence_strategies: { type: "array", items: { type: "string" } }
            }
          },
          diagnostic_recommendations: {
            type: "object",
            properties: {
              upcoming_tests: { type: "array", items: { 
                type: "object",
                properties: {
                  test_name: { type: "string" },
                  reason: { type: "string" },
                  timeline: { type: "string" },
                  priority: { type: "string" }
                }
              }},
              follow_up_on_pending: { type: "array", items: { type: "string" } }
            }
          },
          procedure_planning: {
            type: "object",
            properties: {
              recommended_procedures: { type: "array", items: {
                type: "object",
                properties: {
                  procedure_name: { type: "string" },
                  reason: { type: "string" },
                  timeline: { type: "string" },
                  priority: { type: "string" }
                }
              }},
              pending_procedure_follow_up: { type: "array", items: { type: "string" } }
            }
          },
          lifestyle_interventions: {
            type: "object",
            properties: {
              nutrition_plan: { type: "string" },
              exercise_recommendations: { type: "string" },
              behavioral_strategies: { type: "array", items: { type: "string" } }
            }
          },
          monitoring_schedule: {
            type: "object",
            properties: {
              routine_visits: { type: "string" },
              lab_monitoring: { type: "string" },
              vital_signs_tracking: { type: "string" },
              self_monitoring_tasks: { type: "array", items: { type: "string" } }
            }
          },
          risk_management: {
            type: "object",
            properties: {
              identified_risks: { type: "array", items: { type: "string" } },
              mitigation_strategies: { type: "array", items: { type: "string" } },
              emergency_protocols: { type: "string" }
            }
          },
          patient_education: {
            type: "object",
            properties: {
              priority_topics: { type: "array", items: { type: "string" } },
              resources_needed: { type: "array", items: { type: "string" } }
            }
          },
          goals_and_milestones: {
            type: "object",
            properties: {
              short_term_goals: { type: "array", items: { type: "string" } },
              long_term_goals: { type: "array", items: { type: "string" } },
              success_metrics: { type: "array", items: { type: "string" } }
            }
          },
          next_steps: { type: "array", items: { type: "string" } }
        }
      };

      const result = await InvokeLLM({ prompt, response_json_schema });
      setGeneratedPlan(result);

    } catch (err) {
      console.error("Plan generation failed:", err);
      setError("Failed to generate care plan. Please try again or contact support if the issue persists.");
    }
    
    setLoading(false);
  };

  const generatePrintablePlan = () => {
    if (!generatedPlan) return;

    const currentDate = format(new Date(), 'MMMM dd, yyyy');
    
    const htmlContent = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CarePlix Patient Care Plan - ${patient.first_name} ${patient.last_name}</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body { 
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; 
            line-height: 1.6; 
            color: #1e293b; 
            background: #ffffff;
            font-size: 14px;
        }
        
        .plan-container { 
            max-width: 210mm; 
            margin: 0 auto; 
            background: white; 
            min-height: 297mm;
        }
        
        .plan-header { 
            background: linear-gradient(135deg, #1e40af 0%, #3b82f6 50%, #60a5fa 100%); 
            color: white; 
            padding: 40px 30px; 
            text-align: center; 
            position: relative;
            margin-bottom: 0;
        }
        
        .logo-container {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .logo-image {
            width: 180px;
            height: auto;
            max-height: 50px;
            object-fit: contain;
            background: white;
            padding: 8px 12px;
            border-radius: 8px;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }
        
        .plan-title { 
            font-size: 28px; 
            font-weight: 700; 
            margin-bottom: 8px; 
        }
        
        .plan-subtitle { 
            font-size: 18px; 
            opacity: 0.9; 
            font-weight: 400;
        }
        
        .plan-date { 
            position: absolute; 
            top: 25px; 
            right: 30px; 
            background: rgba(255, 255, 255, 0.15); 
            padding: 8px 16px; 
            border-radius: 20px; 
            font-size: 13px; 
        }
        
        .patient-summary { 
            background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%); 
            padding: 30px; 
            border-bottom: 2px solid #e2e8f0;
        }
        
        .section { 
            padding: 30px; 
            border-bottom: 1px solid #e2e8f0;
            page-break-inside: avoid;
        }
        
        .section-title { 
            font-size: 20px; 
            font-weight: 700; 
            color: #1e293b; 
            margin-bottom: 20px; 
            display: flex; 
            align-items: center; 
            gap: 12px;
            padding-bottom: 10px;
            border-bottom: 2px solid #e2e8f0;
        }
        
        .section-icon {
            width: 28px;
            height: 28px;
            background: linear-gradient(135deg, #3b82f6, #1e40af);
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 14px;
            font-weight: bold;
        }
        
        .content-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .content-card {
            background: #f8fafc;
            padding: 20px;
            border-radius: 12px;
            border: 1px solid #e2e8f0;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        
        .card-title {
            font-size: 16px;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 12px;
            padding-bottom: 8px;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .list-item {
            margin: 8px 0;
            padding-left: 20px;
            position: relative;
        }
        
        .list-item:before {
            content: '•';
            color: #3b82f6;
            font-weight: bold;
            position: absolute;
            left: 0;
        }
        
        .priority-high { border-left: 4px solid #dc2626; }
        .priority-medium { border-left: 4px solid #d97706; }
        .priority-low { border-left: 4px solid #059669; }
        
        .footer {
            background: #f8fafc;
            padding: 30px;
            text-align: center;
            color: #64748b;
            font-size: 12px;
            border-top: 2px solid #e2e8f0;
        }
        
        @media print {
            body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .plan-container { box-shadow: none; margin: 0; }
            .section { page-break-inside: avoid; }
        }
    </style>
</head>
<body>
    <div class="plan-container">
        <div class="plan-header">
            <div class="plan-date">${currentDate}</div>
            <div class="logo-container">
                <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/517303104_careplix-logo784ea9f51.png" alt="CarePlix Logo" class="logo-image">
            </div>
            <h1 class="plan-title">Comprehensive Care Plan</h1>
            <p class="plan-subtitle">${generatedPlan.plan_title}</p>
        </div>

        <div class="patient-summary">
            <h2 style="font-size: 24px; font-weight: 700; color: #1e293b; margin-bottom: 20px;">
                Patient: ${patient.first_name} ${patient.last_name}
            </h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;">
                <div><strong>Primary Condition:</strong> ${patient.primary_condition}</div>
                <div><strong>Age:</strong> ${patient.date_of_birth ? new Date().getFullYear() - new Date(patient.date_of_birth).getFullYear() : 'Not specified'}</div>
                <div><strong>Current Weight:</strong> ${patientStats?.currentWeight || 'Not recorded'} kg</div>
                <div><strong>BMI:</strong> ${patientStats?.bmi || 'Not calculated'}</div>
                <div><strong>Latest HbA1c:</strong> ${patientStats?.lastHbA1c || 'Not available'}%</div>
                <div><strong>Adherence Rate:</strong> ${patientStats?.adherenceRate || 'Not tracked'}%</div>
            </div>
        </div>

        <div class="section">
            <h3 class="section-title">
                <div class="section-icon">📋</div>
                Assessment Summary
            </h3>
            <p style="margin-bottom: 20px; font-size: 16px; line-height: 1.8;">${generatedPlan.assessment_summary}</p>
            
            <div class="content-grid">
                <div class="content-card">
                    <div class="card-title">Overall Progress</div>
                    <p>${generatedPlan.current_status?.overall_progress}</p>
                </div>
                <div class="content-card">
                    <div class="card-title">Key Achievements</div>
                    ${generatedPlan.current_status?.key_achievements?.map(achievement => 
                        `<div class="list-item">${achievement}</div>`
                    ).join('') || '<p>No specific achievements noted</p>'}
                </div>
                <div class="content-card">
                    <div class="card-title">Areas of Concern</div>
                    ${generatedPlan.current_status?.areas_of_concern?.map(concern => 
                        `<div class="list-item">${concern}</div>`
                    ).join('') || '<p>No major concerns identified</p>'}
                </div>
            </div>
        </div>

        <div class="section">
            <h3 class="section-title">
                <div class="section-icon">💊</div>
                Medication Management
            </h3>
            <div class="content-grid">
                <div class="content-card">
                    <div class="card-title">Current Regimen Assessment</div>
                    <p>${generatedPlan.medication_management?.current_regimen_assessment}</p>
                </div>
                <div class="content-card">
                    <div class="card-title">Recommendations</div>
                    ${generatedPlan.medication_management?.recommendations?.map(rec => 
                        `<div class="list-item">${rec}</div>`
                    ).join('') || '<p>Continue current regimen</p>'}
                </div>
                <div class="content-card">
                    <div class="card-title">Adherence Strategies</div>
                    ${generatedPlan.medication_management?.adherence_strategies?.map(strategy => 
                        `<div class="list-item">${strategy}</div>`
                    ).join('') || '<p>Standard adherence protocols</p>'}
                </div>
            </div>
        </div>

        <div class="section">
            <h3 class="section-title">
                <div class="section-icon">🔬</div>
                Diagnostic Recommendations
            </h3>
            <div class="content-grid">
                <div class="content-card">
                    <div class="card-title">Upcoming Tests</div>
                    ${generatedPlan.diagnostic_recommendations?.upcoming_tests?.map(test => 
                        `<div class="list-item priority-${test.priority?.toLowerCase() || 'medium'}">
                            <strong>${test.test_name}</strong> - ${test.reason}<br>
                            <small style="color: #64748b;">Timeline: ${test.timeline} | Priority: ${test.priority}</small>
                        </div>`
                    ).join('') || '<p>No specific tests recommended at this time</p>'}
                </div>
                <div class="content-card">
                    <div class="card-title">Pending Test Follow-up</div>
                    ${generatedPlan.diagnostic_recommendations?.follow_up_on_pending?.map(followUp => 
                        `<div class="list-item">${followUp}</div>`
                    ).join('') || '<p>No pending tests requiring follow-up</p>'}
                </div>
            </div>
        </div>

        <div class="section">
            <h3 class="section-title">
                <div class="section-icon">🏥</div>
                Procedure Planning
            </h3>
            <div class="content-grid">
                <div class="content-card">
                    <div class="card-title">Recommended Procedures</div>
                    ${generatedPlan.procedure_planning?.recommended_procedures?.map(proc => 
                        `<div class="list-item priority-${proc.priority?.toLowerCase() || 'medium'}">
                            <strong>${proc.procedure_name}</strong> - ${proc.reason}<br>
                            <small style="color: #64748b;">Timeline: ${proc.timeline} | Priority: ${proc.priority}</small>
                        </div>`
                    ).join('') || '<p>No procedures recommended at this time</p>'}
                </div>
                <div class="content-card">
                    <div class="card-title">Pending Procedure Follow-up</div>
                    ${generatedPlan.procedure_planning?.pending_procedure_follow_up?.map(followUp => 
                        `<div class="list-item">${followUp}</div>`
                    ).join('') || '<p>No pending procedures requiring follow-up</p>'}
                </div>
            </div>
        </div>

        <div class="section">
            <h3 class="section-title">
                <div class="section-icon">🎯</div>
                Lifestyle Interventions
            </h3>
            <div class="content-grid">
                <div class="content-card">
                    <div class="card-title">Nutrition Plan</div>
                    <p>${generatedPlan.lifestyle_interventions?.nutrition_plan}</p>
                </div>
                <div class="content-card">
                    <div class="card-title">Exercise Recommendations</div>
                    <p>${generatedPlan.lifestyle_interventions?.exercise_recommendations}</p>
                </div>
                <div class="content-card">
                    <div class="card-title">Behavioral Strategies</div>
                    ${generatedPlan.lifestyle_interventions?.behavioral_strategies?.map(strategy => 
                        `<div class="list-item">${strategy}</div>`
                    ).join('') || '<p>Continue current behavioral approach</p>'}
                </div>
            </div>
        </div>

        <div class="section">
            <h3 class="section-title">
                <div class="section-icon">📅</div>
                Monitoring Schedule
            </h3>
            <div class="content-grid">
                <div class="content-card">
                    <div class="card-title">Routine Visits</div>
                    <p>${generatedPlan.monitoring_schedule?.routine_visits}</p>
                </div>
                <div class="content-card">
                    <div class="card-title">Lab Monitoring</div>
                    <p>${generatedPlan.monitoring_schedule?.lab_monitoring}</p>
                </div>
                <div class="content-card">
                    <div class="card-title">Vital Signs Tracking</div>
                    <p>${generatedPlan.monitoring_schedule?.vital_signs_tracking}</p>
                </div>
                <div class="content-card">
                    <div class="card-title">Self-Monitoring Tasks</div>
                    ${generatedPlan.monitoring_schedule?.self_monitoring_tasks?.map(task => 
                        `<div class="list-item">${task}</div>`
                    ).join('') || '<p>Standard self-monitoring protocols</p>'}
                </div>
            </div>
        </div>

        <div class="section">
            <h3 class="section-title">
                <div class="section-icon">⚠️</div>
                Risk Management
            </h3>
            <div class="content-grid">
                <div class="content-card">
                    <div class="card-title">Identified Risks</div>
                    ${generatedPlan.risk_management?.identified_risks?.map(risk => 
                        `<div class="list-item">${risk}</div>`
                    ).join('') || '<p>No significant risks identified</p>'}
                </div>
                <div class="content-card">
                    <div class="card-title">Mitigation Strategies</div>
                    ${generatedPlan.risk_management?.mitigation_strategies?.map(strategy => 
                        `<div class="list-item">${strategy}</div>`
                    ).join('') || '<p>Standard risk mitigation protocols</p>'}
                </div>
                <div class="content-card">
                    <div class="card-title">Emergency Protocols</div>
                    <p>${generatedPlan.risk_management?.emergency_protocols}</p>
                </div>
            </div>
        </div>

        <div class="section">
            <h3 class="section-title">
                <div class="section-icon">🎓</div>
                Patient Education & Goals
            </h3>
            <div class="content-grid">
                <div class="content-card">
                    <div class="card-title">Priority Education Topics</div>
                    ${generatedPlan.patient_education?.priority_topics?.map(topic => 
                        `<div class="list-item">${topic}</div>`
                    ).join('') || '<p>Standard patient education materials</p>'}
                </div>
                <div class="content-card">
                    <div class="card-title">Short-term Goals</div>
                    ${generatedPlan.goals_and_milestones?.short_term_goals?.map(goal => 
                        `<div class="list-item">${goal}</div>`
                    ).join('') || '<p>Goals to be determined</p>'}
                </div>
                <div class="content-card">
                    <div class="card-title">Long-term Goals</div>
                    ${generatedPlan.goals_and_milestones?.long_term_goals?.map(goal => 
                        `<div class="list-item">${goal}</div>`
                    ).join('') || '<p>Goals to be determined</p>'}
                </div>
                <div class="content-card">
                    <div class="card-title">Success Metrics</div>
                    ${generatedPlan.goals_and_milestones?.success_metrics?.map(metric => 
                        `<div class="list-item">${metric}</div>`
                    ).join('') || '<p>Standard clinical metrics</p>'}
                </div>
            </div>
        </div>

        <div class="section">
            <h3 class="section-title">
                <div class="section-icon">✅</div>
                Next Steps
            </h3>
            <div class="content-card">
                ${generatedPlan.next_steps?.map(step => 
                    `<div class="list-item">${step}</div>`
                ).join('') || '<p>Plan to be reviewed and updated as needed</p>'}
            </div>
        </div>

        <div class="footer">
            <p><strong>CarePlix Care Management Platform</strong></p>
            <p>Generated on ${currentDate} | Plan created by AI-assisted clinical decision support</p>
            <p style="margin-top: 10px; font-style: italic;">This care plan should be reviewed by a qualified healthcare provider and customized based on individual patient needs and clinical judgment.</p>
        </div>
    </div>
</body>
</html>
    `;

    const printWindow = window.open('', '_blank');
    printWindow.document.write(htmlContent);
    printWindow.document.close();
    printWindow.print();
  };

  if (!patient || !patientData) {
    return null;
  }

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl font-semibold text-slate-900">
            <Brain className="w-6 h-6 text-blue-600" />
            AI-Powered Comprehensive Care Plan Generation
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6 mt-6">
          {/* Patient Summary */}
          <Card className="border-slate-200">
            <CardHeader>
              <CardTitle className="text-lg">Patient Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div>
                  <span className="font-medium text-slate-600">Patient:</span>
                  <p className="font-semibold">{patient.first_name} {patient.last_name}</p>
                </div>
                <div>
                  <span className="font-medium text-slate-600">Condition:</span>
                  <p>{patient.primary_condition}</p>
                </div>
                <div>
                  <span className="font-medium text-slate-600">Current Weight:</span>
                  <p>{patientStats?.currentWeight || 'Not recorded'} kg</p>
                </div>
                <div>
                  <span className="font-medium text-slate-600">Adherence:</span>
                  <p>{patientStats?.adherenceRate || 'Not tracked'}%</p>
                </div>
              </div>
              
              <div className="mt-4 grid grid-cols-2 md:grid-cols-5 gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-blue-600" />
                  <span>{patientData.vitals?.length || 0} Vitals</span>
                </div>
                <div className="flex items-center gap-2">
                  <FlaskConical className="w-4 h-4 text-green-600" />
                  <span>{patientData.diagnosticTests?.length || 0} Tests</span>
                </div>
                <div className="flex items-center gap-2">
                  <Stethoscope className="w-4 h-4 text-purple-600" />
                  <span>{patientData.procedures?.length || 0} Procedures</span>
                </div>
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-orange-600" />
                  <span>{patientData.clinicalNotes?.length || 0} Notes</span>
                </div>
                <div>
                  <Badge variant="secondary">
                    {patientData.prescriptions?.filter(p => p.status === 'Active').length || 0} Active Rx
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Custom Prompt */}
          <div className="space-y-2">
            <Label htmlFor="custom-prompt">Additional Instructions (Optional)</Label>
            <Textarea
              id="custom-prompt"
              placeholder="Add any specific instructions or focus areas for the care plan..."
              value={customPrompt}
              onChange={(e) => setCustomPrompt(e.target.value)}
              rows={3}
            />
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button
              onClick={generateComprehensivePlan}
              disabled={loading}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Generating Plan...
                </>
              ) : (
                <>
                  <Brain className="w-4 h-4 mr-2" />
                  Generate Comprehensive Plan
                </>
              )}
            </Button>
          </div>

          {/* Error Display */}
          {error && (
            <Card className="bg-red-50 border-red-200">
              <CardContent className="p-4">
                <p className="text-red-700">{error}</p>
              </CardContent>
            </Card>
          )}

          {/* Generated Plan Display */}
          {generatedPlan && (
            <Card className="border-slate-200">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="text-lg">Generated Care Plan</CardTitle>
                  <Button
                    onClick={generatePrintablePlan}
                    variant="outline"
                    className="flex items-center gap-2"
                  >
                    <Download className="w-4 h-4" />
                    Download Plan
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-xl font-semibold text-slate-900 mb-2">
                    {generatedPlan.plan_title}
                  </h3>
                  <p className="text-slate-700 leading-relaxed">
                    {generatedPlan.assessment_summary}
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-slate-900 mb-2">Key Achievements</h4>
                    <ul className="space-y-1">
                      {generatedPlan.current_status?.key_achievements?.map((achievement, index) => (
                        <li key={index} className="text-sm text-slate-700 flex items-start gap-2">
                          <span className="text-green-600 mt-1">•</span>
                          {achievement}
                        </li>
                      )) || <li className="text-sm text-slate-500">No specific achievements noted</li>}
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-slate-900 mb-2">Areas of Concern</h4>
                    <ul className="space-y-1">
                      {generatedPlan.current_status?.areas_of_concern?.map((concern, index) => (
                        <li key={index} className="text-sm text-slate-700 flex items-start gap-2">
                          <span className="text-orange-600 mt-1">•</span>
                          {concern}
                        </li>
                      )) || <li className="text-sm text-slate-500">No major concerns identified</li>}
                    </ul>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-slate-900 mb-2">Diagnostic Recommendations</h4>
                  {generatedPlan.diagnostic_recommendations?.upcoming_tests?.length > 0 ? (
                    <div className="space-y-2">
                      {generatedPlan.diagnostic_recommendations.upcoming_tests.map((test, index) => (
                        <div key={index} className="bg-slate-50 p-3 rounded-lg">
                          <div className="flex justify-between items-start">
                            <div>
                              <p className="font-medium text-slate-900">{test.test_name}</p>
                              <p className="text-sm text-slate-600">{test.reason}</p>
                            </div>
                            <div className="text-right">
                              <Badge variant={test.priority === 'High' ? 'destructive' : test.priority === 'Medium' ? 'default' : 'secondary'}>
                                {test.priority}
                              </Badge>
                              <p className="text-xs text-slate-500 mt-1">{test.timeline}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-slate-500">No specific tests recommended at this time</p>
                  )}
                </div>

                <div>
                  <h4 className="font-semibold text-slate-900 mb-2">Procedure Planning</h4>
                  {generatedPlan.procedure_planning?.recommended_procedures?.length > 0 ? (
                    <div className="space-y-2">
                      {generatedPlan.procedure_planning.recommended_procedures.map((proc, index) => (
                        <div key={index} className="bg-slate-50 p-3 rounded-lg">
                          <div className="flex justify-between items-start">
                            <div>
                              <p className="font-medium text-slate-900">{proc.procedure_name}</p>
                              <p className="text-sm text-slate-600">{proc.reason}</p>
                            </div>
                            <div className="text-right">
                              <Badge variant={proc.priority === 'High' ? 'destructive' : proc.priority === 'Medium' ? 'default' : 'secondary'}>
                                {proc.priority}
                              </Badge>
                              <p className="text-xs text-slate-500 mt-1">{proc.timeline}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-slate-500">No procedures recommended at this time</p>
                  )}
                </div>

                <div>
                  <h4 className="font-semibold text-slate-900 mb-2">Next Steps</h4>
                  <ul className="space-y-1">
                    {generatedPlan.next_steps?.map((step, index) => (
                      <li key={index} className="text-sm text-slate-700 flex items-start gap-2">
                        <span className="text-blue-600 mt-1">•</span>
                        {step}
                      </li>
                    )) || <li className="text-sm text-slate-500">Plan to be reviewed and updated as needed</li>}
                  </ul>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}