
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DiagnosticTest } from "@/api/entities";
import { User } from "@/api/entities";
import { Loader2 } from "lucide-react"; // Added Loader2 import as per outline
import ICD10CodeSelector from '../shared/ICD10CodeSelector'; // Updated import path for ICD10CodeSelector

export default function DiagnosticTestModal({ patient, test, onSave, onCancel }) {
  const [formData, setFormData] = useState({
    test_name: test?.test_name || '',
    category: test?.category || '',
    reason: test?.reason || '',
    status: test?.status || 'Ordered',
    order_date: test?.order_date || new Date().toISOString().split('T')[0],
    due_date: test?.due_date || '',
    results_summary: test?.results_summary || '',
    icd10_code: test?.icd10_code || '' // New field for ICD-10 code
  });
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(false);

  // Effect to load current user, runs once on component mount
  useEffect(() => {
    const loadUser = async () => {
      try {
        const user = await User.me();
        setCurrentUser(user);
      } catch (error) {
        console.error("Error loading current user:", error);
      }
    };
    loadUser();
  }, []); // Empty dependency array means it runs once on mount

  // Effect to re-initialize formData when the 'test' prop changes (e.g., when editing a different test)
  useEffect(() => {
    setFormData({
      test_name: test?.test_name || '',
      category: test?.category || '',
      reason: test?.reason || '',
      status: test?.status || 'Ordered',
      order_date: test?.order_date || new Date().toISOString().split('T')[0],
      due_date: test?.due_date || '',
      results_summary: test?.results_summary || '',
      icd10_code: test?.icd10_code || '' // Ensure ICD-10 code is re-initialized
    });
  }, [test]); // Re-run when 'test' prop changes

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSelectIcd10 = (selectedCode) => {
    handleInputChange('icd10_code', selectedCode);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!currentUser) return;
    setLoading(true);

    const data = {
      ...formData,
      patient_id: patient.id,
      ordered_by: currentUser.email,
    };

    try {
      if (test?.id) {
        await DiagnosticTest.update(test.id, data);
      } else {
        await DiagnosticTest.create(data);
      }
      onSave();
    } catch (error) {
      console.error("Error saving diagnostic test:", error);
    }
    setLoading(false);
  };

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="sm:max-w-xl"> {/* Changed from sm:max-w-lg to sm:max-w-xl */}
        <DialogHeader>
          <DialogTitle>{test ? 'Edit' : 'Order'} Diagnostic Test</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6 mt-6"> {/* Changed pt-4 to mt-6 */}
          <div className="space-y-2">
            <Label htmlFor="test_name">Test Name *</Label>
            <Input
              id="test_name"
              value={formData.test_name}
              onChange={(e) => handleInputChange('test_name', e.target.value)}
              required
              placeholder="e.g., Complete Blood Count"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="icd10_code">Associated Diagnosis (ICD-10)</Label>
            <ICD10CodeSelector
              value={formData.icd10_code}
              onSelect={handleSelectIcd10}
              contextualText={formData.test_name}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="category">Category *</Label>
            <Select value={formData.category} onValueChange={(v) => handleInputChange('category', v)} required>
              <SelectTrigger>
                <SelectValue placeholder="Select a category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Lab Work">Lab Work</SelectItem>
                <SelectItem value="Imaging">Imaging</SelectItem>
                <SelectItem value="Cardiology">Cardiology</SelectItem>
                <SelectItem value="Endoscopy">Endoscopy</SelectItem>
                <SelectItem value="Other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="reason">Reason for Test *</Label>
            <Textarea id="reason" value={formData.reason} onChange={(e) => handleInputChange('reason', e.target.value)} required placeholder="e.g., Annual check-up, monitor condition..." />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
                <Label htmlFor="order_date">Order Date</Label>
                <Input id="order_date" type="date" value={formData.order_date} onChange={(e) => handleInputChange('order_date', e.target.value)} required />
            </div>
            <div className="space-y-2">
                <Label htmlFor="due_date">Due Date</Label>
                <Input id="due_date" type="date" value={formData.due_date} onChange={(e) => handleInputChange('due_date', e.target.value)} />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="status">Status</Label>
             <Select value={formData.status} onValueChange={(v) => handleInputChange('status', v)}>
              <SelectTrigger>
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Ordered">Ordered</SelectItem>
                <SelectItem value="Scheduled">Scheduled</SelectItem>
                <SelectItem value="Completed">Completed</SelectItem>
                <SelectItem value="Results Received">Results Received</SelectItem>
                <SelectItem value="Reviewed">Reviewed</SelectItem>
                <SelectItem value="Cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
          </div>

          { (formData.status === 'Results Received' || formData.status === 'Reviewed') && (
            <div className="space-y-2">
                <Label htmlFor="results_summary">Results Summary</Label>
                <Textarea id="results_summary" value={formData.results_summary} onChange={(e) => handleInputChange('results_summary', e.target.value)} placeholder="Enter brief summary of results..." />
            </div>
          )}

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onCancel} disabled={loading}>Cancel</Button>
            <Button type="submit" disabled={loading} className="bg-blue-600 hover:bg-blue-700">
                {loading ? (
                    <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Saving...
                    </>
                ) : (
                    'Save Order'
                )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
