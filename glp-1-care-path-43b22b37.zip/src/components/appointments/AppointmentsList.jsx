import React, { useState } from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Skeleton } from "@/components/ui/skeleton";
import { MoreHorizontal, Edit, Trash2, Send, CheckCircle } from "lucide-react";
import { format } from "date-fns";
import { SendEmail } from "@/api/integrations";
import { Appointment } from "@/api/entities";

export default function AppointmentsList({ appointments, patientMap, onEdit, onUpdate, loading }) {
  const [sendingReminder, setSendingReminder] = useState(null);

  const getStatusColor = (status) => {
    const colors = {
      Scheduled: "bg-blue-100 text-blue-800",
      Confirmed: "bg-green-100 text-green-800",
      Completed: "bg-gray-200 text-gray-800",
      Cancelled: "bg-red-100 text-red-800",
      'No Show': "bg-yellow-100 text-yellow-800",
    };
    return colors[status] || "bg-gray-100 text-gray-800";
  };

  const handleSendReminder = async (app) => {
    setSendingReminder(app.id);
    const patient = patientMap[app.patient_id];
    if (!patient || !patient.email) {
      alert("This patient does not have an email address on file.");
      setSendingReminder(null);
      return;
    }

    try {
      const subject = `Appointment Reminder: ${app.appointment_type} on ${format(new Date(app.appointment_date), 'MMMM d, yyyy')}`;
      const body = `
        <p>Dear ${patient.first_name},</p>
        <p>This is a friendly reminder for your upcoming appointment with CarePlix.</p>
        <ul>
          <li><strong>Type:</strong> ${app.appointment_type}</li>
          <li><strong>Date:</strong> ${format(new Date(app.appointment_date), 'EEEE, MMMM d, yyyy')}</li>
          <li><strong>Time:</strong> ${app.appointment_time}</li>
        </ul>
        <p>If you need to reschedule, please contact our office.</p>
        <p>Thank you,<br/>CarePlix Team</p>
      `;

      await SendEmail({ to: patient.email, subject, body });
      await Appointment.update(app.id, { reminder_sent_date: new Date().toISOString() });
      await onUpdate();
      alert("Reminder sent successfully!");
    } catch (error) {
      console.error("Failed to send reminder:", error);
      alert("Failed to send reminder. Please try again.");
    } finally {
      setSendingReminder(null);
    }
  };
  
  const handleCancelAppointment = async (app) => {
    if (confirm("Are you sure you want to cancel this appointment?")) {
        try {
            await Appointment.update(app.id, { status: "Cancelled" });
            await onUpdate();
        } catch (error) {
            console.error("Failed to cancel appointment:", error);
            alert("Failed to cancel appointment.");
        }
    }
  }

  if (loading) {
    return (
      <div className="space-y-4">
        {Array(5).fill(0).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="bg-slate-50">
            <TableHead>Patient</TableHead>
            <TableHead>Date & Time</TableHead>
            <TableHead>Type</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Reminder Sent</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {appointments.length > 0 ? appointments.map((app) => {
            const patient = patientMap[app.patient_id];
            return (
              <TableRow key={app.id}>
                <TableCell className="font-medium">{patient ? `${patient.first_name} ${patient.last_name}` : 'Unknown Patient'}</TableCell>
                <TableCell>
                  {format(new Date(app.appointment_date), 'EEE, MMM d, yyyy')} at {app.appointment_time}
                </TableCell>
                <TableCell>{app.appointment_type}</TableCell>
                <TableCell>
                  <Badge className={getStatusColor(app.status)}>{app.status}</Badge>
                </TableCell>
                <TableCell>
                  {app.reminder_sent_date ? (
                    <div className="flex items-center gap-1 text-green-600">
                      <CheckCircle className="w-4 h-4" />
                      {format(new Date(app.reminder_sent_date), 'MMM d, h:mm a')}
                    </div>
                  ) : 'No'}
                </TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                      <DropdownMenuItem onClick={() => onEdit(app)}>
                        <Edit className="w-4 h-4 mr-2" /> Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleSendReminder(app)} disabled={sendingReminder === app.id}>
                        {sendingReminder === app.id ? (
                            <><div className="w-4 h-4 mr-2 animate-spin border-2 border-gray-400 border-t-transparent rounded-full"/> Sending...</>
                        ) : (
                            <><Send className="w-4 h-4 mr-2" /> Send Reminder</>
                        )}
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleCancelAppointment(app)} className="text-red-600">
                        <Trash2 className="w-4 h-4 mr-2" /> Cancel
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            );
          }) : (
            <TableRow>
              <TableCell colSpan={6} className="text-center py-8 text-slate-500">
                No appointments found.
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
}